using System.Collections.Generic;
using System.Text;
using Orbit.Entities;
using Orbit.Helpers;
using Orbit.Navigation;
using Orbit.Systems;
using UnityEngine;
using Random = UnityEngine.Random;

namespace Orbit.Sain;

/// <summary>
/// Rolls a squad's <see cref="Squad.MainObjectives"/> list at creation time. Player-blind — no read of
/// <c>MainPlayer.Position</c> or any other player state. Anchors come from static map data (positive-Force
/// zones for <see cref="MainObjectiveType.Kills"/>; top-quartile loot cells for <see
/// cref="MainObjectiveType.LootValue"/>;
/// <c>TriggerWithId</c> POI positions for
/// <see cref="MainObjectiveType.Quest"/>).
///
/// Only PMCs and PlayerScavs receive main objectives. Bot scavs, bosses, raiders, goons, cultists,
/// bloodhounds skip the system entirely.
/// </summary>
public static class MainObjectiveBuilder
{
    public static void Generate(Squad squad, WaypointSystem waypointSystem, ISet<int> reachableQuests = null)
    {
        if (squad?.Leader?.Bot?.Profile?.Info?.Settings == null) return;
        if (!ServerConfig.MainObjectives.Enabled)
        {
            Log.Debug($"{squad} skipping main objectives — master toggle OFF");
            return;
        }
        var role = squad.Leader.Bot.Profile.Info.Settings.Role;

        var isPmc = role.IsPMC();
        var isPlayerScav = squad.Leader.Bot.Profile.WillBeAPlayerScav();

        if (!isPmc && !isPlayerScav)
        {
            Log.Info($"{squad} skipping main objectives — role {role} is not PMC or PlayerScav");
            return;
        }
        if (isPmc && !ServerConfig.MainObjectives.EnabledForPmc)
        {
            Log.Debug($"{squad} skipping main objectives — PMC opt-out toggle");
            return;
        }
        if (isPlayerScav && !ServerConfig.PlayerScav.Enabled)
        {
            Log.Debug($"{squad} skipping main objectives — PlayerScav opt-out toggle");
            return;
        }

        // Per-squad count source. PMC with SAIN personality → already rolled into
        // squad.Personality.MainCount. Otherwise (PlayerScav or PMC with master toggle OFF) → use the global
        // F12 range.
        int count;
        if (squad.Personality != null)
        {
            count = Mathf.Max(1, squad.Personality.MainCount);
        }
        else
        {
            var rawMin = isPmc ? PersonalityFallback.PmcMainCountMin : ServerConfig.PlayerScav.MainCountMin;
            var rawMax = isPmc ? PersonalityFallback.PmcMainCountMax : ServerConfig.PlayerScav.MainCountMax;
            var minCount = Mathf.Max(1, rawMin);
            var maxCount = Mathf.Max(minCount, rawMax);
            count = Random.Range(minCount, maxCount + 1);
        }
        squad.MainObjectives = new List<MainObjective>(count);

        // Lazy pools — only compute the ones we need.
        List<Vector2Int> topLootCells = null;
        List<WaypointSystem.ZoneAnchor> killZoneAnchors = null;
        List<Waypoint> questPool = null;

        // Resolve mix weights — PMC with SAIN personality uses archetype-specific weights, PlayerScav and
        // personality-OFF PMCs fall back to the global F12 weights. Auto-normalised.
        float wQuest, wKills, wLootValue;
        if (squad.Personality != null)
        {
            wQuest = Mathf.Max(0f, squad.Personality.MainMixQuestWeight);
            wKills = Mathf.Max(0f, squad.Personality.MainMixKillsWeight);
            wLootValue = Mathf.Max(0f, squad.Personality.MainMixLootValueWeight);
        }
        else if (isPmc)
        {
            wQuest = Mathf.Max(0f, PersonalityFallback.PmcMixQuest);
            wKills = Mathf.Max(0f, PersonalityFallback.PmcMixKills);
            wLootValue = Mathf.Max(0f, PersonalityFallback.PmcMixLootValue);
        }
        else
        {
            wQuest = Mathf.Max(0f, ServerConfig.PlayerScav.MainMixQuest);
            wKills = Mathf.Max(0f, ServerConfig.PlayerScav.MainMixKills);
            wLootValue = Mathf.Max(0f, ServerConfig.PlayerScav.MainMixLootValue);
        }
        wQuest *= ServerConfig.MainObjectives.QuestWeightScale;
        wKills *= ServerConfig.MainObjectives.KillsWeightScale;
        wLootValue *= ServerConfig.MainObjectives.LootWeightScale;
        var wSum = wQuest + wKills + wLootValue;
        if (wSum < 0.0001f) { wLootValue = 1f; wSum = 1f; } // degenerate: default LootValue
        var thQuest = wQuest / wSum;
        var thKills = thQuest + wKills / wSum;

        // Per-squad cell-use tracking. Without this, two RollKills or RollLootValue calls can land on the
        // same anchor cell because the underlying pools (positive-Force zones, top-loot cells) are small. A
        // duplicate is redundant (the squad would do the same thing twice) and inflates the count toward the
        // timeout fallback. Each roll retries up to MaxRolls times against this set; if every retry collides
        // we accept the duplicate as a last resort rather than dropping the main entirely.
        var usedCells = new HashSet<string>();
        const int MaxRetriesOnDuplicate = 6;

        var ambush = ServerConfig.Ambush;
        var style = AmbushDirector.Style(squad);
        var extractChance = ambush.Allows(squad.Leader.BotCategory) && ambush.Extracts.Enabled ? style.ExtractMainChance : 0f;
        var rush = isPmc && !isPlayerScav ? waypointSystem.RollRushMain(squad) : null;
        if (rush != null) squad.MainObjectives.Add(rush);
        for (var i = rush == null ? 0 : 1; i < count; i++)
        {
            var roll = Random.value;
            MainObjectiveType type;
            // Extract camp reserves its configured percentage; the existing mix divides the remainder.
            if (roll < extractChance) type = MainObjectiveType.ExtractCamp;
            else if ((roll = (roll - extractChance) / Mathf.Max(.0001f, 1f - extractChance)) < thQuest) type = MainObjectiveType.Quest;
            else if (roll < thKills) type = MainObjectiveType.Kills;
            else type = MainObjectiveType.LootValue;

            var operationRoll = type == MainObjectiveType.LootValue
                && ServerConfig.MultiStep.Allows(squad.Leader.BotCategory)
                && Random.value < WaypointSystem.OperationStyle(squad).LootMainChance;
            MainObjective main = null;
            for (var attempt = 0; attempt < MaxRetriesOnDuplicate && main == null; attempt++)
            {
                MainObjective candidate = null;
                switch (type)
                {
                    case MainObjectiveType.LootValue:
                        if (operationRoll)
                            candidate = waypointSystem.RollOperationMain(squad);
                        break;
                    case MainObjectiveType.ExtractCamp:
                        candidate = waypointSystem.RollExtractCampMain(squad, style);
                        break;
                    case MainObjectiveType.Quest:
                        questPool ??= BuildQuestPool(waypointSystem);
                        candidate = RollQuest(questPool, waypointSystem, squad, reachableQuests);
                        break;
                    case MainObjectiveType.Kills:
                        killZoneAnchors ??= waypointSystem.GetPositiveForceZoneAnchors(squad);
                        candidate = RollKills(killZoneAnchors, waypointSystem, squad);
                        break;
                }

                // LootValue path. Used both for explicit LootValue rolls and as a fallback when Quest/Kills
                // couldn't find an anchor (questPool exhausted for this squad, or map has no PvP zones).
                // Loops here too so a duplicate LootValue cell gets retried against `usedCells`.
                if (candidate == null)
                {
                    topLootCells ??= waypointSystem.GetTopLootCells();
                    candidate = RollLootValue(topLootCells, waypointSystem, squad);
                }
                if (candidate == null) break; // pool empty, give up on this slot

                if (!usedCells.Contains(candidate.Operation?.Definition.Id ?? candidate.CellCoords + "|" + candidate.ZoneFloorId))
                    main = candidate;
                // else: collision with an existing cell within THIS squad — retry the same type. Cross-squad
                // collisions are intentional (multiple squads can target the same Quest / Kills / LootValue
                // cell, which is exactly how friction points emerge in PvP).
            }

            if (main != null)
            {
                squad.MainObjectives.Add(main);
                // One final camp can last until departure; additional camps could never be pursued.
                if (main.Type == MainObjectiveType.ExtractCamp) extractChance = 0f;
                usedCells.Add(main.Operation?.Definition.Id ?? main.CellCoords + "|" + main.ZoneFloorId);
            }
        }

        if (squad.MainObjectives.Count == 0)
        {
            squad.MainObjectives = null;
            Log.Warning($"{squad} generated zero main objectives (no eligible anchors); will behave like baseline dispatch");
            return;
        }

        for (var i = 0; i < squad.MainObjectives.Count - 1; i++)
            if (squad.MainObjectives[i].Type == MainObjectiveType.ExtractCamp)
            {
                var camp = squad.MainObjectives[i];
                squad.MainObjectives.RemoveAt(i);
                squad.MainObjectives.Add(camp);
                break;
            }

        var summary = new StringBuilder();
        for (var i = 0; i < squad.MainObjectives.Count; i++)
        {
            if (i > 0) summary.Append(", ");
            var m = squad.MainObjectives[i];
            if (m.Type == MainObjectiveType.Quest)
                summary.Append($"Quest:{m.QuestTriggerId}@{m.CellCoords}");
            else if (m.KillAmbush)
                summary.Append($"Kills(ambush)@{m.CellCoords}");
            else
                summary.Append($"{m.Type}@{m.CellCoords}");
        }
        Log.Info($"{squad} role={role} mains[{squad.MainObjectives.Count}]: {summary}");
    }

    private static MainObjective RollKills(List<WaypointSystem.ZoneAnchor> anchors, WaypointSystem waypointSystem, Squad squad)
    {
        if (anchors.Count == 0) return null;
        var anchor = anchors[Random.Range(0, anchors.Count)];
        var pos = anchor.Position;
        // Per-archetype roam-duration range if the squad has a SAIN personality; falls back to the global F12
        // range for PlayerScavs and personality-OFF PMCs.
        var roamRange = squad.Personality != null
            ? squad.Personality.KillsRoamDuration
            : PersonalityFallback.KillsRoamDuration;
        return new MainObjective
        {
            Type = MainObjectiveType.Kills,
            ZoneFloorId = anchor.FloorId,
            Position = pos,
            CellCoords = waypointSystem.WorldToCell(pos),
            KillsRoamTargetDuration = Random.Range(roamRange.x, roamRange.y),
            KillZoneRadius = anchor.Radius,
            KillZoneCenter = anchor.Center,
            KillAmbush = ServerConfig.Ambush.Allows(squad.Leader.BotCategory) && ServerConfig.Ambush.Hotspots.Enabled
                && Random.value < AmbushDirector.Style(squad).KillAmbushChance,
        };
    }

    private static MainObjective RollLootValue(List<Vector2Int> topCells, WaypointSystem waypointSystem, Squad squad)
    {
        if (topCells.Count == 0) return null;
        // Per-archetype slice of the global top-loot pool. PMC with SAIN personality restricts to the first N
        // entries (e.g. top-3 for VeryAggressive, top-10 for Cautious). PlayerScav / OFF uses the full pool.
        var slice = squad.Personality != null
            ? Mathf.Clamp(squad.Personality.TopLootCellsMax, 1, topCells.Count)
            : topCells.Count;
        var cell = topCells[Random.Range(0, slice)];
        return new MainObjective
        {
            Type = MainObjectiveType.LootValue,
            CellCoords = cell,
            Position = waypointSystem.CellToWorld(cell),
            // One-shot rouble-value compute for the raid-review viz tooltip / sidebar label. Static — the
            // cell's loot doesn't get richer over the raid.
            LootValueTotal = waypointSystem.SumCellLootValue(cell),
        };
    }

    private static MainObjective RollQuest(List<Waypoint> questPool, WaypointSystem waypointSystem, Squad squad, ISet<int> reachableQuests)
    {
        // Walk the pool in random order, pick the first trigger that is REACHABLE from the squad's spawn
        // position AND not already owned by this same squad. Cross-squad collisions are intentional: two
        // squads holding the same Quest main means they'll both route to the same trigger position — that's
        // the PvP friction the main-objective system is designed to create. The reachability check
        // (NavMesh.CalculatePath) prevents a Quest main on a navmesh fragment that's disconnected from the
        // squad's spawn — bot would otherwise roam the entire map without ever being able to touch the
        // trigger.
        if (questPool == null || questPool.Count == 0) return null;
        var startIdx = Random.Range(0, questPool.Count);
        for (var i = 0; i < questPool.Count; i++)
        {
            var loc = questPool[(startIdx + i) % questPool.Count];
            var triggerId = loc.Name;
            if (string.IsNullOrEmpty(triggerId)) continue;

            // Intra-squad dedup: don't roll the same Quest trigger twice for the same squad (cross-squad
            // reuse is fine).
            if (SquadAlreadyHasQuest(squad, triggerId)) continue;

            // Reachability gate. Uses squad.SpawnPosition (captured at squad creation) as the source. If
            // unreachable, skip and try the next pool entry.
            if (reachableQuests != null ? !reachableQuests.Contains(loc.Id)
                : squad != null && squad.SpawnPosition != Vector3.zero
                    && !waypointSystem.IsReachableFromPosition(squad.SpawnPosition, loc.Position))
            {
                Log.Info($"{squad} skipping Quest main {triggerId}@{waypointSystem.WorldToCell(loc.Position)} — NavMesh.CalculatePath from spawn {squad.SpawnPosition} returned non-Complete");
                continue;
            }

            return new MainObjective
            {
                Type = MainObjectiveType.Quest,
                Position = loc.Position,
                CellCoords = waypointSystem.WorldToCell(loc.Position),
                QuestTriggerId = triggerId,
                // Title resolution against the SPT quest DB is future work; fall back to the trigger ID for
                // now (readable enough for the raid-review tooltip).
                QuestTitle = triggerId,
            };
        }
        return null; // pool exhausted (every reachable quest already in this squad's mains)
    }

    private static bool SquadAlreadyHasQuest(Squad squad, string triggerId)
    {
        if (squad?.MainObjectives == null) return false;
        for (var i = 0; i < squad.MainObjectives.Count; i++)
        {
            var m = squad.MainObjectives[i];
            if (m.Type == MainObjectiveType.Quest && m.QuestTriggerId == triggerId) return true;
        }
        return false;
    }

    internal static bool NeedsQuestReachability(Squad squad)
    {
        if (squad?.Leader?.Bot?.Profile?.Info?.Settings == null || !ServerConfig.MainObjectives.Enabled
            || ServerConfig.MainObjectives.QuestWeightScale <= 0 || squad.SpawnPosition == Vector3.zero) return false;
        var pmc = squad.Leader.Bot.Profile.Info.Settings.Role.IsPMC();
        var scav = squad.Leader.Bot.Profile.WillBeAPlayerScav();
        if (!pmc && !scav || pmc && !ServerConfig.MainObjectives.EnabledForPmc
            || scav && !ServerConfig.PlayerScav.Enabled) return false;
        return (squad.Personality?.MainMixQuestWeight
            ?? (pmc ? PersonalityFallback.PmcMixQuest : ServerConfig.PlayerScav.MainMixQuest)) > 0;
    }

    internal static List<Waypoint> BuildQuestPool(WaypointSystem waypointSystem)
    {
        var pool = new List<Waypoint>();
        var cells = waypointSystem.Cells;
        var size = waypointSystem.GridSize;
        for (var x = 0; x < size.x; x++)
        {
            for (var y = 0; y < size.y; y++)
            {
                ref var cell = ref cells[x, y];
                if (!cell.HasWaypoints) continue;
                for (var k = 0; k < cell.Waypoints.Count; k++)
                {
                    var loc = cell.Waypoints[k];
                    if (loc.Category == WaypointCategory.Quest) pool.Add(loc);
                }
            }
        }
        return pool;
    }
}
