using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Comfort.Common;
using EFT;
using Orbit.Core;
using Orbit.Entities;
using Orbit.Helpers;
using Orbit.Looting;
using Orbit.Navigation;
using Orbit.Systems;
using Orbit.Tasks.Actions;
using UnityEngine;
using Random = UnityEngine.Random;
using Range = Orbit.Config.Range;

namespace Orbit.Tasks.Strategies;

/// <summary>
/// The squad-level dispatch loop. For every active squad it ticks main objectives (Kills roam timer,
/// LootValue cell entry / cleanup / engaged- time timeout, Quest completion), drives the combat-convergence
/// override, refreshes the per-squad unreachability cache as the leader crosses cells, scans for
/// opportunistic-corpse interrupts, then (re-)dispatches each member onto either the squad anchor, a roam
/// splinter, or a loot splinter as appropriate.
/// </summary>
public class GotoObjectiveStrategy(SquadData squadData, WaypointSystem waypointSystem, float hysteresis) : Task<Squad>(hysteresis)
{
    private readonly AmbushDirector _ambush = new(waypointSystem);
    internal void OnAirdropReleased(AmbushSite site) => _ambush.OnAirdropReleased(site, squadData.Entities.Values);
    private static Range _moveTimeout = new(400, 600);
    private Range _guardDuration = new(ServerConfig.PoiGuard.GuardDuration.x, ServerConfig.PoiGuard.GuardDuration.y);
    private Range _guardDurationCut = new(ServerConfig.PoiGuard.GuardDurationCut.x, ServerConfig.PoiGuard.GuardDurationCut.y);
    private Range _adjustedGuardDuration = new(ServerConfig.PoiGuard.SyntheticGuardDuration.x, ServerConfig.PoiGuard.SyntheticGuardDuration.y);
    // Scav-only idle pause at a Synthetic POI. The default 3-7s adjusted guard makes scavs look hyperactive,
    // chaining waypoints without ever stopping. 10s-120s gaussian (mean ~65s) gives a mix of short glances
    // and longer corner-camping pauses. During the wait the agent runs GuardAction (cover point + area sweeps
    // + watch direction rotation), so it's not a frozen stand-still.
    private readonly Range _scavSyntheticIdleDuration = new(10f, 120f);

    public override void UpdateScore(int ordinal)
    {
        var squads = squadData.Entities.Values;
        for (var i = 0; i < squads.Count; i++)
        {
            var squad = squads[i];
            squad.TaskScores[ordinal] = 0.5f;
        }
    }

    public override void Activate(Squad entity)
    {
        base.Activate(entity);

        if (entity.Objective.Location == null) return;

        // If we have an objective, reset the timer on activation.
        var timeout = entity.Objective.Status == SquadObjectiveState.Wait
            ? _guardDuration.SampleGaussian()
            : _moveTimeout.SampleGaussian();

        ResetDuration(entity.Objective, timeout);
    }

    public override void Deactivate(Entity entity)
    {
        if (entity is Squad operatingSquad)
        {
            operatingSquad.Rush?.End(operatingSquad, waypointSystem, "strategy deactivated");
            operatingSquad.Operation?.End(operatingSquad, waypointSystem, "strategy deactivated");
            operatingSquad.MainApproach.End(operatingSquad, waypointSystem);
            if (operatingSquad.MainObjectives != null)
                foreach (var main in operatingSquad.MainObjectives) main.CampApproach?.Release(operatingSquad, waypointSystem);
        }
        if (entity is Squad campingSquad) campingSquad.Camp.End(campingSquad, "strategy deactivated");
        if (entity is Squad squad) squad.CorpseEscort.End(squad, waypointSystem, "strategy deactivated");
        if (entity is Squad bossSquad) bossSquad.BossLoot.Cancel(bossSquad, waypointSystem, "strategy deactivated");
        // Return any assignments before deactivating.
        waypointSystem.Return(entity);
        base.Deactivate(entity);
    }

    public override void Update()
    {
        _ambush.Prune(squadData.Entities.Values);
        for (var i = 0; i < ActiveEntities.Count; i++)
        {
            var squad = ActiveEntities[i];
            using var timing = PerformanceJournal.Measure(TransitionPhase.StrategySquad, "strategy-squad", this, squad.Id);
            var squadObjective = squad.Objective;
            GhostNoiseInvestigation.Revalidate(squad, waypointSystem);

            if (squad.Camp.Active)
            {
                RaidTimeExtraction.Check(squad);
                if (squad.Camp.Tick(squad, waypointSystem))
                {
                    UpdateAgents(squad, out _); // Emergency extraction still takes priority for each member.
                    continue;
                }
            }

            if (squad.Camp.PendingAirdrop != null)
            {
                RaidTimeExtraction.Check(squad);
                if (_ambush.TryStartPending(squad))
                {
                    UpdateAgents(squad, out _);
                    continue;
                }
            }

            if (squad.Camp.RetryMain != null)
            {
                RaidTimeExtraction.Check(squad);
                if (_ambush.TryStart(squad))
                {
                    UpdateAgents(squad, out _);
                    continue;
                }
            }

            // Deferred SAIN personality resolution. PMC squads spawn before SAIN attaches its BotComponent
            // (1-2s delay), so SquadRegistry deferred the lookup + the main-objective roll. Retry here every
            // tick until the brain resolves or the 5 s deadline lapses (then lock to Average and generate
            // mains anyway).
            if (squad.SainResolutionPending)
            {
                Singleton<OrbitManager>.Instance?.SquadRegistry?.TryResolvePersonality(squad);
            }

            if (waypointSystem.MainObjectivesPending(squad) && !squad.ExtractRequested)
            {
                RaidTimeExtraction.Check(squad);
                continue;
            }

            // Corpse-stuck watchdog: only bites when nothing completes (unreachable corpse, hung loot, or a
            // stuck member keeps the en-route blacklist below from firing) and would otherwise pin the squad
            // on the body forever.
            {
                var corpseObj = squadObjective.Location;
                if (corpseObj != null && corpseObj.Category == WaypointCategory.Corpse)
                {
                    if (squad.CorpseWatchdogLocId != corpseObj.Id)
                    {
                        squad.CorpseWatchdogLocId = corpseObj.Id;
                        squad.CorpseWatchdogSince = Time.time;
                    }
                    else if (Time.time < squad.GhostFightUntil || squad.CorpseEscort.Active || SquadAnyMemberInCombat(squad)
                             || SquadAnyMemberPursuingCorpse(squad, corpseObj))
                    {
                        // Pause only while there is genuine progress: SAIN combat / healing, or a member
                        // actively heading to / looting the body (travel + loot time never eat the window). An
                        // anchored corpse NOBODY is pursuing must keep counting — that dead-anchor pin is
                        // exactly the stall this watchdog exists to break.
                        squad.CorpseWatchdogSince = Time.time;
                    }
                    else if (Time.time - squad.CorpseWatchdogSince > CorpseStuckTimeoutSeconds)
                    {
                        squad.CompletedPoiIds.Add(corpseObj.Id);
                        squad.PreInterruptObjectiveLocation = null; // drop any stale opportunistic resume so it can't re-pin the corpse
                        squad.CorpseWatchdogLocId = -1;
                        Log.Info($"{squad} corpse-stuck watchdog: blacklisting {corpseObj} after {CorpseStuckTimeoutSeconds:F0}s glued to it without completing — re-dispatching");
                        AssignNewObjective(squad);
                        continue;
                    }
                }
                else
                {
                    squad.CorpseWatchdogLocId = -1;
                }
            }

            MaintainDoorCarvers(squad);

            // Rolling per-squad unreachability refresh. _squadUnreachable is populated from the leader's
            // CURRENT position via NavMesh.CalculatePath; verdicts cached when the leader was
            // 500m away become wrong once they walk into the area. On
            // every cell transition we re-evaluate the 3x3 window around the leader's new cell, gated by a
            // per-cell cooldown so oscillating leaders don't thrash the cache.
            RefreshUnreachabilityAroundLeader(squad);

            // Tick main objectives (Kills timer / LootValue completion / extract trigger when all done).
            // Independent of the per-squad objective dispatch flow below — mains drive the long-term force
            // attraction, the dispatch picks tick-level secondary POIs.

            // Squad rally: the first member to engage becomes the "caller" and squad.Objective.Location is
            // swapped to a virtual Waypoint at their position so realign converges everyone there to support.
            // ORBIT only routes supporters in; SAIN's combat layer (priority 20 > ORBIT 19) preempts each as
            // it acquires an enemy. Grace keeps the override stable through brief LoS breaks.
            if (ServerConfig.General.SquadRally)
            {
                DetectAndUpdateCombatCaller(squad);
                if (squad.CombatCallerMemberIdx >= 0)
                {
                    // Reuse the rally waypoint until the caller has moved meaningfully. A fresh instance every
                    // tick broke reference alignment for every supporter, re-dispatching them all (move order +
                    // path job) each tick for the whole fight — a large sustained cost during any engagement.
                    // Recreating only on >8m caller movement re-paths supporters just enough to track them.
                    if (squad.CombatCallerWaypoint == null
                        || (squad.CombatCallerWaypoint.Position - squad.CombatCallerPosition).sqrMagnitude > 64f)
                    {
                        squad.CombatCallerWaypoint = waypointSystem.CreateVirtualWaypoint(
                            squad.CombatCallerPosition, "CombatCaller");
                        PerfMonitor.RallyWaypointsCreated++;
                    }
                    squad.Objective.Location = squad.CombatCallerWaypoint;
                    squad.Objective.Status = SquadObjectiveState.Active;
                    squad.Objective.StartTime = Time.time;
                    squad.Objective.Duration = 30f;
                    squad.Objective.DurationAdjusted = false;
                }
            }
            else if (squad.CombatCallerMemberIdx >= 0)
            {
                squad.CombatCallerMemberIdx = -1;
            }

            RaidTimeExtraction.Check(squad);

            if (waypointSystem.TickRush(squad, SquadAnyMemberInCombat(squad)))
            {
                UpdateAgents(squad, out _);
                continue;
            }
            if (waypointSystem.TickOperation(squad, SquadAnyMemberInCombat(squad)))
            {
                UpdateAgents(squad, out _);
                continue;
            }
            TickMainObjectives(squad);
            // Entering a local Kill main this tick can make a previously accepted sound irrelevant.
            GhostNoiseInvestigation.Revalidate(squad, waypointSystem);

            var escortingCorpse = squad.CorpseEscort.Maintain(squad, waypointSystem, SquadAnyMemberInCombat(squad));
            if (TryContinueLootExtractSweep(squad)) continue;

            // Extract interrupt: bee-line to the exfil the instant ExtractRequested is set, rather than letting
            // the squad finish (and wait out) its current objective first. Gated on an eligible exfil existing
            // so we don't churn a re-dispatch every tick when none is reachable.
            if (squad.ExtractRequested
                && squadObjective.Location != null
                && squadObjective.Location.Category != WaypointCategory.Exfil
                && waypointSystem.FindNearestEligibleExfil(squad) != null)
            {
                Log.Info($"{squad} ExtractRequested — interrupting {squadObjective.Location} to bee-line to the exfil now");
                squadObjective.Location = null;
                AssignNewObjective(squad);
                continue;
            }

            if (escortingCorpse)
            {
                UpdateAgents(squad, out _);
                continue; // Pause anchor completion and guard timers for the entire loot detour.
            }

            if (_ambush.TryStart(squad))
            {
                UpdateAgents(squad, out _);
                continue;
            }

            if (waypointSystem.TickExtractCampApproach(squad))
            {
                UpdateAgents(squad, out _);
                continue;
            }

            if (squad.MainApproach.Tick(squad, waypointSystem, SquadAnyMemberInCombat(squad)))
            {
                UpdateAgents(squad, out _);
                continue;
            }

            // Opportunistic corpse interrupt: any squad member who sees an unlooted corpse within
            // DetectCorpseDistance drops the current objective to investigate. Real-Tarkov behaviour — a bot
            // walking past a body always checks it. We gate the scan on:
            //   * squad is not already on a Corpse objective
            //   * squad is not already mid-interrupt
            //   * squad has not flipped ExtractRequested (extract bee-line
            // beats opportunistic loot — they've decided to leave)
            //   * pacing throttle elapsed (the raycast loop is non-trivial)
            //
            // Groups keep even their patrol anchor so the corpse escort can return everyone together.
            // Solo bots retain the existing fresh-selection behavior for synthetic patrol fillers.
            if (!squad.ExtractRequested
                && squad.CombatCallerMemberIdx < 0
                && squad.PreInterruptObjectiveLocation == null
                && (squadObjective.Location == null || squadObjective.Location.Category != WaypointCategory.Corpse)
                && Time.time >= squad.LastOpportunisticCorpseScanTime + ServerConfig.MainObjectives.OpportunisticCorpseScanIntervalSeconds)
            {
                squad.LastOpportunisticCorpseScanTime = Time.time;
                var opportunistic = waypointSystem.TryFindOpportunisticCorpse(squad);
                if (opportunistic != null)
                {
                    var previous = squadObjective.Location;
                    var preInterrupt = previous != null
                                       && (previous.Category != WaypointCategory.Synthetic || squad.Size > 1)
                                       ? previous
                                       : null;
                    squad.PreInterruptObjectiveLocation = preInterrupt;
                    squadObjective.LocationPrevious = previous;
                    squadObjective.Location = opportunistic;
                    squadObjective.Status = SquadObjectiveState.Active;
                    ShufflePickCoverPoints(squadObjective, Math.Max(squad.TargetMembersCount, squad.Size));
                    ResetDuration(squadObjective, _moveTimeout.SampleGaussian());
                    Log.Info($"{squad} opportunistic-corpse interrupt: spotted {opportunistic}, was on {previous} (resume={(preInterrupt != null ? "yes" : "no — synthetic or null")})");
                    continue; // re-enter on next tick; UpdateAgents will realign members
                }
            }

            // Ghost hearing: the sleeping squad heard a firefight and rolled "go and look" (DormancySystem).
            // Same interrupt shape as the opportunistic corpse, minus the resume: once there, the normal
            // flow takes over (a ghost contact, bodies to loot, or simply the next objective).
            if (squad.InvestigateNoisePosition.HasValue)
            {
                var noisePos = squad.InvestigateNoisePosition.Value;
                if (!squad.ExtractRequested
                    && squad.CombatCallerMemberIdx < 0
                    && squad.PreInterruptObjectiveLocation == null
                    && (squadObjective.Location == null || squadObjective.Location.Category != WaypointCategory.Corpse))
                {
                    var previous = squadObjective.Location;
                    var investigate = waypointSystem.RequestForInvestigation(squad, noisePos);
                    if (investigate == null && waypointSystem.DispatchPending(squad))
                    {
                        // Keep the same sound while the shared path budget advances the search.
                        UpdateAgents(squad, out _);
                        continue;
                    }
                    squad.InvestigateNoisePosition = null;
                    if (investigate != null)
                    {
                        squadObjective.LocationPrevious = previous;
                        squadObjective.Location = investigate;
                        squadObjective.Status = SquadObjectiveState.Active;
                        ShufflePickCoverPoints(squadObjective, Math.Max(squad.TargetMembersCount, squad.Size));
                        ResetDuration(squadObjective, _moveTimeout.SampleGaussian());
                        Log.Info($"{squad} noise investigation: heading to {investigate} near the gunfire at {noisePos}, was on {previous}");
                        continue; // re-enter on next tick; UpdateAgents will realign members
                    }
                    Log.Debug($"{squad} noise investigation: no usable waypoint around {noisePos}, staying on {previous}");
                }
                else squad.InvestigateNoisePosition = null;
            }
            // Do not re-arm Failed on a consumed loose item. Pending pickup sessions get their action
            // tick first, so their successful result and extraction checks are preserved.
            if (LooseLootRecovery.PrepareSquad(squad, waypointSystem))
                continue;

            if (squadObjective.Location == null)
            {
                // Honour an explicit post-rescue (or other) cooldown set by a patch that nulled the location:
                // if the wait window hasn't elapsed yet, don't immediately hand the squad a new POI. Without
                // this gate, the rescue-prune cooldown gets bypassed and the rescued bot is sent chasing the
                // next POI before BSG re-anchors it on the navmesh.
                if (squadObjective.Status == SquadObjectiveState.Wait
                    && Time.time < squadObjective.StartTime + squadObjective.Duration)
                {
                    continue;
                }
                AssignNewObjective(squad);
                continue;
            }

            if (squadObjective.RepickRequested)
            {
                squadObjective.RepickRequested = false;
                AssignNewObjective(squad, completedCurrent: false);
                continue;
            }

            if (waypointSystem.DispatchPending(squad))
            {
                AssignNewObjective(squad, squad.PendingDispatchCompletedCurrent);
                continue;
            }

            var finishedCount = UpdateAgents(squad, out var locallyExhaustedLootCount);

            if (TryAdvanceExhaustedLoot(squad, finishedCount, locallyExhaustedLootCount))
                continue;

            if (finishedCount == squad.Size)
            {
                if (squadObjective.Status == SquadObjectiveState.Active)
                {
                    // UpdateAgents counts a departing solo-extracter as "finished", so finishedCount can reach
                    // squad.Size with zero real path attempts. Treating that as an en-route failure would
                    // wrongly blacklist the objective — hold it instead so a rejoining member resumes it.
                    var anyMemberPursuing = false;
                    for (var m = 0; m < squad.Size; m++)
                    {
                        if (!squad.Members[m].SoloExtractRequested) { anyMemberPursuing = true; break; }
                    }
                    if (!anyMemberPursuing)
                    {
                        Log.Debug($"{squad} 'all finished' is only solo-extract departures — holding {squadObjective.Location}, not counting an en-route failure");
                        continue;
                    }

                    // Every member's path attempt came back Failed without anyone reaching the POI. After
                    // enough in a row the POI is effectively unreachable for this squad — blacklist it so the
                    // next pick goes somewhere else.
                    //
                    // Previously this branch hard-teleported the squad to the POI's navmesh sample point.
                    // That created two failure modes:
                    //  - TP dropped the bot inside locked rooms (Resort /
                    // Sanatorium navmesh interiors had a sample point even though the door was a one-way
                    // breach), bot stuck inside for the rest of the raid.
                    //  - On Kills mains anchored at config zone centers
                    // sitting in walls / cliffs / water, the navmesh sample failed → TP fall back to "normal
                    // dispatch" → en-route fail again → infinite TP attempt loop. Drop the teleport entirely.
                    // Force-unlock probability rolls on locked doors stay intact via the door- handling path
                    // in MovementSystem.
                    squad.ConsecutiveFailedDispatches++;
                    if (squad.ConsecutiveFailedDispatches >= UnreachableBlacklistThreshold
                        && squadObjective.Location != null
                        && squadObjective.Location.Category != WaypointCategory.Exfil)
                    {
                        squad.CompletedPoiIds.Add(squadObjective.Location.Id);
                        QuestObjectiveRecovery.Retire(squad, squadObjective.Location, "repeated en-route failures");
                        Log.Info($"{squad} blacklisting unreachable {squadObjective.Location} after {UnreachableBlacklistThreshold} consecutive en-route failures (squad memory size={squad.CompletedPoiIds.Count})");
                        squad.ConsecutiveFailedDispatches = 0;
                        AssignNewObjective(squad);
                        continue;
                    }
                    Log.Debug($"{squad} all members failed their objective en-route, requesting new assignment (streak={squad.ConsecutiveFailedDispatches})");
                    AssignNewObjective(squad);
                    continue;
                }

                if (!squadObjective.DurationAdjusted)
                {
                    switch (squadObjective.Location.Category)
                    {
                        case WaypointCategory.ContainerLoot:
                        case WaypointCategory.LooseLoot:
                        case WaypointCategory.Corpse:
                            // The looting pipeline already takes 6-25s per POI to simulate inspection /
                            // pickup. No need to add a guard wait on top — that just makes squads stand
                            // around at empty containers. Force the timer to expire immediately.
                            AdjustDuration(squadObjective, 0f, Time.time);
                            Log.Debug($"{squad} skipping guard wait at loot POI {squadObjective.Location} (loot action already provided its own delay)");
                            break;
                        case WaypointCategory.Quest:
                            // Quest triggers still benefit from a short guard wait (no inner delay).
                            AdjustDuration(squadObjective, squadObjective.Duration * _guardDurationCut.SampleGaussian());
                            Log.Debug($"{squad} adjusted {squadObjective.Location} wait duration to {squadObjective.Duration}");
                            break;
                        case WaypointCategory.Synthetic:
                            // Bot scavs (assault / assaultGroup, not PlayerScavs) get a much longer
                            // randomised idle pause at a Synthetic — vanilla scavs frequently stop and stand
                            // around their patrol points for a minute or more, while ours were chaining
                            // Synthetic→Synthetic with only a 3-7s pause. PMCs / raiders / bosses /
                            // PlayerScavs keep the short pause so they stay aggressive on their patrol path.
                            //
                            // PlayerScavs share WildSpawnType.assault with bot scavs so IsScav() can't
                            // distinguish them — the canonical detection is the Profile.WillBeAPlayerScav
                            // extension.
                            var leaderBotAtSynthetic = squad.Leader?.Bot;
                            var roleAtSynthetic = leaderBotAtSynthetic?.Profile?.Info?.Settings?.Role;
                            var isBotScavAtSynthetic = roleAtSynthetic.HasValue
                                && roleAtSynthetic.Value.IsScav()
                                && leaderBotAtSynthetic?.Profile != null
                                && !leaderBotAtSynthetic.Profile.WillBeAPlayerScav();
                            if (isBotScavAtSynthetic)
                            {
                                AdjustDuration(squadObjective, _scavSyntheticIdleDuration.SampleGaussian(), Time.time);
                                Log.Debug($"{squad} scav idle pause at {squadObjective.Location} for {squadObjective.Duration:F1}s");
                            }
                            else
                            {
                                AdjustDuration(squadObjective, _adjustedGuardDuration.SampleGaussian(), Time.time);
                                Log.Debug($"{squad} adjusted {squadObjective.Location} wait duration to {squadObjective.Duration}");
                            }
                            break;
                        case WaypointCategory.Exfil:
                        default:
                            break;
                    }
                }
            }

            if (Time.time < squadObjective.StartTime + squadObjective.Duration)
                continue;

            Log.Debug($"{squad} wait timer ran out, requesting new assignment");
            AssignNewObjective(squad, completedCurrent: true);
        }
    }

    // Tracks splinter waypoint ids assigned earlier in the same UpdateAgents pass so two followers in the
    // same squad don't get handed the same POI.
    private readonly HashSet<int> _splinterScratch = new(8);

    // Reusable union buffer for splinter-dispatch agent-skip filtering.
    private readonly HashSet<int> _agentSkipScratch = new(16);

    /// <summary>
    /// Combines the shared splinter scratch with the agent's personal value-skip set. Returns the base set
    /// unchanged when the agent has no skips to add.
    /// </summary>
    private HashSet<int> UnionWithAgentSkips(HashSet<int> baseSet, Agent agent)
    {
        var skips = agent?.ValueSkippedPoiIds;
        if (skips == null || skips.Count == 0) return baseSet;
        _agentSkipScratch.Clear();
        foreach (var id in baseSet) _agentSkipScratch.Add(id);
        foreach (var id in skips) _agentSkipScratch.Add(id);
        Log.Debug($"{agent} splinter dispatch: filtering +{skips.Count} agent value-skipped POIs (total exclude={_agentSkipScratch.Count})");
        return _agentSkipScratch;
    }

    private static readonly EBodyPart[] _emergencyHpParts =
    {
        EBodyPart.Head, EBodyPart.Chest, EBodyPart.Stomach,
        EBodyPart.LeftArm, EBodyPart.RightArm, EBodyPart.LeftLeg, EBodyPart.RightLeg
    };

    // HP-trend emergency-extract tuning. Triggers and cancel logic are documented on UpdateEmergencyExtract.
    private const float EmergencyDropWindowSeconds = 8f;
    private const float EmergencyMinDropFraction = 0.12f;
    private const float EmergencyRecoverFraction = 0.10f;
    private const float EmergencyFallSubWindowSeconds = 2.5f;
    private const float EmergencyFallEps = 0.01f;
    // Max gap between HP samples before the rolling buffer is dropped as stale (a SAIN-combat sampling hole
    // otherwise leaves a pre-combat full-HP sample that reads as a fresh bleed).
    private const float EmergencyMaxSampleGapSeconds = 2f;
    private const float EmergencyStagnantLowFraction = 0.50f;
    private const float EmergencyStagnantLowSeconds = 60f;
    // Bleed-stopped cancel: HP holding (no new low) this long above the danger floor rejoins the squad, even
    // when a partial heal plateaued just under the +RecoverFraction recover bar that never cancels.
    private const float EmergencyBleedStoppedSeconds = 12f;

    // Only PMCs / PlayerScavs extract via exfils in ORBIT; everyone else despawns, so a solo run is moot.
    // "Extract allowed for" gates this too — None (or a set excluding this bot) means don't peel a wounded
    // bot off its squad for a run it can't finish. PlayerScavs share WildSpawnType.assault so route to the
    // PlayerScav flag explicitly instead of collapsing onto Scav.
    private static bool CanSoloExtract(Agent agent)
    {
        var profile = agent.Bot?.Profile;
        var role = profile?.Info?.Settings?.Role;
        if (!role.HasValue) return false;
        var isPlayerScav = profile.WillBeAPlayerScav();
        if (!role.Value.IsPMC() && !isPlayerScav) return false;
        var allowed = ServerConfig.Loot.ExtractAllowedFor;
        return isPlayerScav ? (allowed & ExtractFaction.PlayerScav) != 0 : allowed.IsBotEnabled(role.Value);
    }

    private static void ClearEmergencyExtract(Agent agent, string reason)
    {
        agent.SoloExtractRequested = false;
        agent.SoloExtractIsEmergency = false;
        agent.SoloExtractReason = null;
        agent.SoloExtractTarget = null;
        agent.EmergencyLowSince = -1f;
        Log.Info($"{agent} emergency extract cancelled — {reason}, rejoining squad");
    }

    // HP-trend emergency extract, sampled per tick because the BSG Medecine/FirstAid flags didn't reliably
    // catch a bleeding, med-less bot. Two triggers: ACTIVE DECLINE (HP still falling across two consecutive
    // sub-windows — the two-window test rejects a single hit that then stabilised) and STAGNANT LOW. A bot
    // with meds heals naturally, so recovery cancels the extract and no explicit med check is needed.
    private static void UpdateEmergencyExtract(Agent agent)
    {
        if (!ServerConfig.General.EmergencyExtractEnabled) return;
        if (!CanSoloExtract(agent)) return;
        var cur = HpFraction(agent);

        if (agent.SoloExtractRequested && agent.SoloExtractIsEmergency)
        {
            // Healed: HP climbed a full RecoverFraction back above its low.
            if (cur >= agent.EmergencyHpLow + EmergencyRecoverFraction)
            {
                ClearEmergencyExtract(agent, $"HP recovered to {cur:P0}");
                return;
            }
            // Bleed stopped: HP held (no new low) above the danger floor — rejoin instead of running a solo
            // exfil on stable HP.
            if (cur > EmergencyStagnantLowFraction
                && Time.time - agent.EmergencyHpLowTime >= EmergencyBleedStoppedSeconds)
            {
                ClearEmergencyExtract(agent, $"bleed stopped, HP stable at {cur:P0}");
                return;
            }
            if (cur < agent.EmergencyHpLow - EmergencyFallEps)
            {
                agent.EmergencyHpLow = cur;
                agent.EmergencyHpLowTime = Time.time;
            }
            return;
        }

        if (cur < EmergencyStagnantLowFraction)
        {
            if (agent.EmergencyLowSince < 0f) agent.EmergencyLowSince = Time.time;
        }
        else
        {
            agent.EmergencyLowSince = -1f;
        }

        // Record this HP sample, discarding the whole buffer first if sampling stalled past the max gap, so
        // active-decline only ever reads a continuous recent run.
        var now = Time.time;
        if (agent.EmergencyHpHistCount > 0)
        {
            var prevSlot = (agent.EmergencyHpHistCount - 1) % agent.EmergencyHpHist.Length;
            if (now - agent.EmergencyHpHistTime[prevSlot] > EmergencyMaxSampleGapSeconds)
                agent.EmergencyHpHistCount = 0;
        }
        var slot = agent.EmergencyHpHistCount % agent.EmergencyHpHist.Length;
        agent.EmergencyHpHist[slot] = cur;
        agent.EmergencyHpHistTime[slot] = now;
        agent.EmergencyHpHistCount++;

        // Active decline: below the DropWindow-ago reference AND still falling across both sub-windows.
        var hpWindowAgo = HpFromAtLeastAgo(agent, now, EmergencyDropWindowSeconds);
        var hpMidAgo = HpFromAtLeastAgo(agent, now, EmergencyFallSubWindowSeconds * 2f);
        var hpRecentAgo = HpFromAtLeastAgo(agent, now, EmergencyFallSubWindowSeconds);
        var activeDecline = hpWindowAgo >= 0f && hpMidAgo >= 0f && hpRecentAgo >= 0f
                            && hpWindowAgo - cur >= EmergencyMinDropFraction   // dropped below the DropWindow-ago reference
                            && hpMidAgo - hpRecentAgo >= EmergencyFallEps      // fell during the older sub-window
                            && hpRecentAgo - cur >= EmergencyFallEps;          // and still falling in the latest one
        var stagnantLow = agent.EmergencyLowSince >= 0f
                          && Time.time - agent.EmergencyLowSince >= EmergencyStagnantLowSeconds;

        if ((agent.SoloExtractRequested && agent.LootExtractSweep == null) || (!activeDecline && !stagnantLow)) return;

        agent.SoloExtractRequested = true;
        agent.SoloExtractIsEmergency = true;
        agent.EmergencyHpLow = cur;
        agent.EmergencyHpLowTime = Time.time;
        if (activeDecline)
        {
            agent.SoloExtractReason = $"emergency (HP {cur:P0}, dropping with no recovery)";
            Log.Info($"{agent} emergency extract — HP at {cur:P0} (down from {hpWindowAgo:P0} over the last {EmergencyDropWindowSeconds:F0}s, still falling), bee-lining to exfil");
        }
        else
        {
            agent.SoloExtractReason = $"emergency (HP {cur:P0}, stuck below 50% with no recovery)";
            Log.Info($"{agent} emergency extract — HP stuck at {cur:P0} below 50% for {Time.time - agent.EmergencyLowSince:F0}s with no recovery, bee-lining to exfil");
        }
    }

    // True once a member has looted+value-skipped this corpse. Until then it's fresh (killer-only); after, a
    // lower-threshold member may clean up the leftovers, so the anti-pile null below must not fire.
    private static bool CorpseValueSkippedByAnyMember(Squad squad, int locId)
    {
        if (squad?.Members == null) return false;
        for (var i = 0; i < squad.Members.Count; i++)
        {
            var m = squad.Members[i];
            if (m != null && m.ValueSkippedPoiIds.Contains(locId)) return true;
        }
        return false;
    }

    private static void MaintainDoorCarvers(Squad squad)
    {
        if (squad.OpenCarverDoors.Count == 0) return;
        var suppressCarvers = SquadAnyMemberInCombat(squad);
        for (var d = squad.OpenCarverDoors.Count - 1; d >= 0; d--)
        {
            var door = squad.OpenCarverDoors[d];
            if (door == null || door.DoorState != EFT.Interactive.EDoorState.Locked)
            {
                squad.OpenCarverDoors.RemoveAt(d); // Native navigation owns an unlocked door.
                continue;
            }
            if (!NeedsLockedDoor(squad, door))
            {
                DoorNavMesh.CloseCarver(door);
                squad.OpenCarverDoors.RemoveAt(d);
            }
            else if (suppressCarvers)
            {
                // Keep the grant tracked while combat pauses a target, so resuming that same target
                // restores its route without another assignment or probability roll.
                DoorNavMesh.CloseCarver(door);
            }
            else if (!DoorNavMesh.IsCarverOpened(door.GetInstanceID()))
            {
                DoorNavMesh.OpenCarver(door);
            }
        }
    }

    private static bool NeedsLockedDoor(Squad squad, EFT.Interactive.Door door)
    {
        if (squad.Objective.Location?.LockedDoorsOnPath?.Contains(door) == true) return true;
        foreach (var member in squad.Members)
        {
            if (member?.Player?.HealthController is not { IsAlive: true }) continue;
            var objective = member.Objective;
            if (objective.Status is ObjectiveStatus.Finished or ObjectiveStatus.Failed) continue;
            if (objective.Location?.LockedDoorsOnPath?.Contains(door) == true) return true;
        }
        return false;
    }

    // True if any alive member is outside ORBIT control (IsActive=false, SAIN combat / healing has the bot).
    private static bool SquadAnyMemberInCombat(Squad squad)
    {
        if (squad?.Members == null) return false;
        for (var i = 0; i < squad.Members.Count; i++)
        {
            var m = squad.Members[i];
            if (m != null && !m.IsActive && m.Player?.HealthController is { IsAlive: true }) return true;
        }
        return false;
    }

    // Most recent HP sample aged between `ago` and `ago` + one sampling gap, or -1 if none. The upper bound
    // (floor) rejects a stale pre-gap sample from a SAIN-combat hole being read as the "ago" reference.
    private static float HpFromAtLeastAgo(Agent agent, float now, float ago)
    {
        var target = now - ago;
        var floor = target - EmergencyMaxSampleGapSeconds;
        var best = -1f;
        var bestTime = -1f;
        var n = Mathf.Min(agent.EmergencyHpHistCount, agent.EmergencyHpHist.Length);
        for (var i = 0; i < n; i++)
        {
            var t = agent.EmergencyHpHistTime[i];
            if (t <= target && t >= floor && t > bestTime)
            {
                bestTime = t;
                best = agent.EmergencyHpHist[i];
            }
        }
        return best;
    }

    private static float HpFraction(Agent agent)
    {
        var hc = agent.Player?.HealthController;
        if (hc == null || !hc.IsAlive) return 1f;
        float cur = 0f, max = 0f;
        for (var i = 0; i < _emergencyHpParts.Length; i++)
        {
            var h = hc.GetBodyPartHealth(_emergencyHpParts[i]);
            cur += h.Current;
            max += h.Maximum;
        }
        return max > 0f ? cur / max : 1f;
    }

    private bool TryContinueLootExtractSweep(Squad squad)
    {
        if (squad.LootExtractSweep?.Maintain(waypointSystem) != true) return false;
        UpdateAgents(squad, out _);
        return true;
    }

    private int UpdateAgents(Squad squad, out int locallyExhaustedLootCount)
    {
        using var timing = PerformanceJournal.Measure(TransitionPhase.StrategyDispatch, "strategy-operation", "UpdateAgents", squad.Id);
        var squadObjective = squad.Objective;
        var finishedCount = 0;
        locallyExhaustedLootCount = 0;
        _splinterScratch.Clear();

        // Independent-dispatch mode: each member picks their own roam splinter (extended radius + category
        // mask) instead of all converging on the squad anchor. Triggered during Kills roam and LootValue
        // active phases, but disabled when a combat caller is set (everyone converges on the caller instead),
        // AND disabled once the squad has decided to extract — letting members pick splinter loot on the way
        // to the exfil delays the whole extract chain indefinitely.
        var useRoam = ShouldUseIndependentDispatch(squad)
                      && squad.CombatCallerMemberIdx < 0
                      && !squad.ExtractRequested;
        // Anchor for the roam splinter search: the active main's Position (Kills zone centre / LootValue cell
        // centre). Without this, the splinter radius would be centred on each bot's drifting current position
        // and they'd wander out of the zone over a few re-picks.
        var activeMain = useRoam ? ActiveIndependentMain(squad) : null;
        var activeType = activeMain?.Type;
        // Per-type category mask. Kills roam = wide net (loot + corpse + synthetic) so members "look for
        // action"; LootValue = loot + corpse only.
        var roamLooseLoot = useRoam;
        var roamContainerLoot = useRoam;
        var roamCorpse = useRoam;
        var roamSynthetic = useRoam && activeType == MainObjectiveType.Kills;
        var trackLootExhaustion = useRoam && activeType == MainObjectiveType.LootValue
                                 && activeMain.LootValueEnteredAt > 0f
                                 && squadObjective.Location != null
                                 && (IsLootPoi(squadObjective.Location.Category)
                                     || squadObjective.Location.Category == WaypointCategory.Synthetic);

        for (var i = 0; i < squad.Size; i++)
        {
            var agent = squad.Members[i];
            var agentObjective = agent.Objective;

            // Skip every member who is themselves engaged. The caller's objective is a virtual waypoint at his
            // own feet (realigning would "reach" it instantly then reassign forever), and any other in-combat
            // member has a live SAIN sequence we'd queue a stale destination behind. Only non-combat members
            // are eligible supporters.
            if (squad.CombatCallerMemberIdx == i) continue;
            var memberBot = agent.Bot;
            if (squad.CombatCallerMemberIdx >= 0
                && memberBot?.Memory != null
                && (memberBot.Memory.HaveEnemy || memberBot.Memory.IsUnderFire))
            {
                continue;
            }

            // Solo / emergency extract: a wounded member peels off to its own exfil, skipping squad alignment +
            // splinter logic so the rest keep playing. The arrival handler flips it to Extracting from there.
            UpdateEmergencyExtract(agent);
            if (agent.LootExtractSweep?.Maintain(waypointSystem) == true)
            {
                if (agent.SoloExtractRequested) finishedCount++;
                continue;
            }
            if (agent.SoloExtractRequested)
            {
                if (agent.SoloExtractTarget != null && squad.CompletedPoiIds.Contains(agent.SoloExtractTarget.Id))
                    ExfilArrival.Abandon(agent, agent.SoloExtractTarget);
                if (agent.IsActive && agent.SoloExtractTarget?.Target is EFT.Interactive.ExfiltrationPoint soloExfil
                    && ExfilArrival.IsSharedTimer(soloExfil) && ExfilArrival.IsUnavailable(soloExfil))
                {
                    Log.Info($"{agent} solo V-Ex {soloExfil.name} unavailable, selecting another exfil");
                    ExfilArrival.Abandon(agent, agent.SoloExtractTarget);
                }
                if (agent.SoloExtractTarget == null)
                    agent.SoloExtractTarget = waypointSystem.FindNearestEligibleExfil(squad, agent);
                if (agent.SoloExtractTarget != null)
                {
                    // Re-arm the move order rather than issuing it once: a SAIN-combat detour drops the
                    // destination and an arrival stall flips it to Failed, either of which strands the bot near
                    // the exfil with no way back into the arrival->Extracting handler. None is not stalled: it is
                    // the armed state itself, waiting for GotoObjectiveAction, which cannot run while SAIN holds
                    // the bot. An emergency extract usually fires mid-fight, and counting None re-armed the same
                    // order every tick for the whole fight (257 "lost its move order" lines in two raids).
                    var firstDispatch = agentObjective.Location != agent.SoloExtractTarget;
                    var stalled = !firstDispatch
                                  && agentObjective.Status != ObjectiveStatus.None
                                  && agentObjective.Status != ObjectiveStatus.Moving
                                  && agentObjective.Status != ObjectiveStatus.Extracting;
                    if (firstDispatch || stalled)
                    {
                        var prevStatus = agentObjective.Status;
                        agentObjective.Location = agent.SoloExtractTarget;
                        agentObjective.SplinterParent = null;
                        agentObjective.Status = ObjectiveStatus.None;
                        agentObjective.DispatchTime = Time.time;
                        if (firstDispatch)
                            Log.Info($"{agent} solo extract ({agent.SoloExtractReason}) → bee-lining to {agent.SoloExtractTarget}");
                        else
                            Log.Debug($"{agent} solo extract re-arming bee-line to {agent.SoloExtractTarget} (was {prevStatus} — lost its move order)");
                    }
                    // Count the departing member as "finished" so the squad keeps advancing, not stalling.
                    finishedCount++;
                    continue;
                }
                if (waypointSystem.ExfilSearchPending(squad, agent)) { finishedCount++; continue; }
                // No eligible exfil, so drop the solo extract and rejoin the squad.
                agent.SoloExtractRequested = false;
                agent.SoloExtractReason = null;
            }

            if (squad.CorpseEscort.UpdateMember(squad, agent, i, waypointSystem)) continue;
            if (squad.BossLoot.Owns(agent)) continue;
            if (squad.Camp.PendingAirdrop != null || squad.Camp.RetryMain != null || squad.Camp.Owns(agent)) continue;
            if (squad.Operation?.Owns(agent) == true || squad.Rush?.Owns(agent) == true
                || squad.MainApproach.Owns(agent) || ExtractCampApproach.Owns(squad, agent)) continue;

            // An agent is "aligned" with the squad if their location IS the squad's main objective, OR if
            // they're working a splinter that was picked around the squad's current main objective. Without
            // the SplinterParent check, followers on a splinter would look misaligned every tick and get
            // re-dispatched in a loop.
            //
            // Exception: an agent whose splinter is already done (loot succeeded → Finished, or arrival kept
            // failing → Failed) is treated as misaligned so UpdateAgents picks a FRESH splinter. Without
            // this, the agent freezes on the completed splinter and the squad anchor's surrounding POIs never
            // get worked through.
            var splinterAlreadyDone = agentObjective.SplinterParent != null
                                      && (agentObjective.Status == ObjectiveStatus.Finished
                                          || agentObjective.Status == ObjectiveStatus.Failed);
            // Roam continuation: anchor-first parks the leader on the squad anchor, and
            // "Location == squad objective" keeps them aligned forever once Finished — the leader stood
            // guarding beside his completed patrol point for a minute while followers walked out their
            // splinters (observed during Kills roam). During roam, a leader who has
            // FINISHED the anchor is treated as misaligned so he falls into the splinter branches.
            // Kill roam also releases followers who fell back to that exhausted anchor.
            var finishedAnchorInRoam = (i == 0 || activeType == MainObjectiveType.Kills) && useRoam
                                             && agentObjective.SplinterParent == null
                                             && agentObjective.Location != null
                                             && agentObjective.Location == squadObjective.Location
                                             && agentObjective.Status == ObjectiveStatus.Finished;
            // Cross-anchor sticky: when the squad anchor flips (current main completed, leader switched
            // targets, etc.), keep every member on their CURRENT splinter until they physically reach it or it
            // gets blacklisted. The previous radius gate (only sticky if the splinter sits within
            // SplinterSearchRadius of the new anchor) was too aggressive — it ripped members off live loot
            // routes mid-run as soon as the leader moved on, producing the rapid "switch without reaching"
            // pattern. Each agent now runs their own splinter pipeline independently: arrive → finish → pick
            // next; squadmates don't synchronise on the leader's progress.
            var splinterStickyAcrossAnchor = !splinterAlreadyDone
                                             && agentObjective.SplinterParent != null
                                             && agentObjective.Location != null
                                             && squadObjective.Location != null
                                             && agentObjective.SplinterParent != squadObjective.Location
                                             && !squad.CompletedPoiIds.Contains(agentObjective.Location.Id);
            // Fix A: an agent still owed its own kill's corpse must not stay stuck on a lower-priority loot
            // splinter (or any non-corpse objective). Resolve the re-route here so the alignment check treats it
            // as misaligned and the dispatch block below routes it to its body. Computed once, reused there.
            // A new corpse must never cancel an in-flight search/transfer on the current body.
            if (agentObjective.Status == ObjectiveStatus.Looting || agent.LootHandler?.LootTaskRunning == true)
                continue;
            var ownKillReroute = waypointSystem.TryGetNextOwnKillCorpseForAgent(squad, agent);
            var visibleAirdrop = ownKillReroute == null ? waypointSystem.TryFindOpportunisticAirdrop(agent) : null;
            var hasPendingAccess = waypointSystem.TryResumeMemberWaypoint(agent, out var pendingPick, out var pendingParent);
            var aligned = !splinterAlreadyDone && !finishedAnchorInRoam
                          && !hasPendingAccess
                          && visibleAirdrop == null
                          && (ownKillReroute == null || agentObjective.Location == ownKillReroute)
                          && (agentObjective.Location == squadObjective.Location
                              || (agentObjective.SplinterParent != null
                                  && agentObjective.SplinterParent == squadObjective.Location)
                              || splinterStickyAcrossAnchor);
            if (finishedAnchorInRoam)
            {
                if (agentObjective.Location.Category == WaypointCategory.Synthetic)
                    squad.RecentlyVisitedPoiCooldowns[agentObjective.Location.Id] =
                        Time.time + ServerConfig.MainObjectives.SyntheticVisitCooldownSeconds;
                Log.Debug($"{agent} roam continuation: finished anchor {agentObjective.Location}, picking a splinter instead of guarding");
            }

            if (aligned && agentObjective.Location != null)
            {
                // Track existing splinters so we don't hand the same POI to another follower below.
                if (agentObjective.SplinterParent != null)
                    _splinterScratch.Add(agentObjective.Location.Id);
                // Rebase SplinterParent to the squad's current anchor so the next tick aligns via the
                // standard path.
                if (splinterStickyAcrossAnchor)
                {
                    Log.Debug($"{agent} splinter sticky across anchor flip: kept {agentObjective.Location}, rebased parent {agentObjective.SplinterParent} → {squadObjective.Location}");
                    agentObjective.SplinterParent = squadObjective.Location;
                }
                // Reset Failed back to None so Goto picks the agent back up and re-submits a move order.
                // Without this, an Exfil dispatch that stops short (partial nav-path 400m+ off an exfil)
                // leaves the agent pinned at Status=Failed forever: ExtractRequested keeps re-confirming the
                // SAME exfil reference each tick, alignment stays true, and no per-agent re-assignment fires
                // to clear the failed flag. Agent never tries to move again.
                if (agentObjective.Status == ObjectiveStatus.Failed)
                    agentObjective.Status = ObjectiveStatus.None;
            }

            if (!aligned)
            {
                // Dispatch priority:
                //   1. Own-kill direct: the specific agent who landed the
                // corpse kill goes to its oldest eligible pending body, not a random splinter.
                //   2. Anchor-first for the leader (i=0): exactly one
                // member works the anchor itself, others get splinters. Solo squads naturally end up here
                // too, so the bot loots the anchor before its splinters. Falls through to the splinter branch
                // once the anchor is in CompletedPoiIds.
                //   3. Roam splinter (members on Kills/LootValue in
                // progress, non-killer non-leader).
                //   4. Loot splinter (non-roam followers).
                //   5. Fallback to squad anchor (no splinter found).
                Waypoint targetLoc;
                Waypoint splinterParent;
                var locallyExhausted = false;
                var tookOwnKillCorpse = false;
                var anchorReservedForOwnKill = squadObjective.Location != null
                                               && AnyMemberDesignatedForCorpse(squad, squadObjective.Location.Id);
                // Persistent own-kill re-route (highest priority): resolved above, where it also broke this
                // agent's sticky-splinter alignment so we reach here. A killer pulled off its body by combat /
                // heal / solo-extract is routed straight back to it.
                if (ownKillReroute != null)
                {
                    targetLoc = ownKillReroute;
                    splinterParent = squadObjective.Location;
                    tookOwnKillCorpse = true;
                    Log.Debug($"{agent} own-kill re-route to its corpse {targetLoc} (reactivated after a combat / heal / extract detour)");
                }
                else if (visibleAirdrop != null)
                {
                    targetLoc = visibleAirdrop;
                    splinterParent = squadObjective.Location;
                    _splinterScratch.Add(targetLoc.Id);
                    Log.Info($"AIRDROP LOOT: {agent} spotted {targetLoc} at {targetLoc.Position}");
                }
                else if (hasPendingAccess)
                {
                    targetLoc = pendingPick;
                    splinterParent = pendingParent;
                    _splinterScratch.Add(targetLoc.Id);
                }
                else if (i == 0
                         && !anchorReservedForOwnKill
                         && squadObjective.Location != null
                         && !(finishedAnchorInRoam
                              && squadObjective.Location.Category == WaypointCategory.Synthetic)
                         && !squad.CompletedPoiIds.Contains(squadObjective.Location.Id)
                         && !agent.ValueSkippedPoiIds.Contains(squadObjective.Location.Id)
                         // A synthetic anchor still under its visit cooldown was just patrolled (by this
                         // leader, typically — the roam-continuation path lands here right after his
                         // Finished). Re-taking it would ping-pong anchor ↔ splinter every other pick;
                         // roam a splinter instead until the cooldown lapses.
                         && !(squadObjective.Location.Category == WaypointCategory.Synthetic
                              && squad.RecentlyVisitedPoiCooldowns.TryGetValue(squadObjective.Location.Id, out var anchorVisitExpiry)
                              && Time.time < anchorVisitExpiry))
                {
                    // Leader takes the anchor itself. Falls through to the splinter branches when the anchor
                    // is squad-blacklisted or in the leader's personal value-skip set.
                    targetLoc = squadObjective.Location;
                    splinterParent = null;
                }
                else if (useRoam)
                {
                    // Drift-libre by default: search centred on the bot's current position so they can
                    // naturally wander up to ~50m at each re-pick. Leash: if the bot has drifted further than
                    // the search radius from the active Main's anchor (e.g. chased an enemy out of a Kills
                    // zone), swap the search centre to the anchor so the next pick snaps them back.
                    var roamRadius = ServerConfig.MainObjectives.RoamSplinterRadius;
                    var searchCenter = agent.Position;
                    if (activeMain != null
                        && WaypointSystem.XzDistanceSqr(agent.Position, activeMain.Position) > roamRadius * roamRadius)
                    {
                        // XZ-only: activeMain.Position.Y is 0 for LootValue mains (CellToWorld) and
                        // custom-zone Kills mains, so 3D distance would inflate by the vertical mismatch with
                        // the agent's real Y.
                        searchCenter = activeMain.Position;
                    }
                    var excludeForRoam = UnionWithAgentSkips(_splinterScratch, agent);
                    var roamSplinter = waypointSystem.FindRoamSplinterForMember(
                        agent.Position, searchCenter, squad, excludeForRoam, roamRadius,
                        roamLooseLoot, roamContainerLoot, roamCorpse, roamSynthetic);
                    var localKillRoam = roamSplinter == null && waypointSystem.IsLocalKillRoam(agent, activeMain);
                    if (localKillRoam)
                    {
                        roamSplinter = waypointSystem.FindKillPatrolForMember(agent, activeMain, out var patrolPending);
                        if (patrolPending) continue;
                    }
                    if (roamSplinter != null)
                    {
                        targetLoc = roamSplinter;
                        splinterParent = squadObjective.Location;
                        _splinterScratch.Add(roamSplinter.Id);
                    }
                    else if (localKillRoam || squadObjective.Location != null
                             && (finishedAnchorInRoam
                                 || (squadObjective.Location.Position - agent.Position).sqrMagnitude <= squadObjective.Location.RadiusSqr))
                    {
                        // This search, rather than an arbitrary null objective, proves local exhaustion.
                        // Once all members settle, re-evaluate the wider cell instead of waiting at this POI.
                        targetLoc = null;
                        splinterParent = null;
                        locallyExhausted = localKillRoam;
                        if (trackLootExhaustion)
                        {
                            locallyExhausted = true;
                            locallyExhaustedLootCount++;
                        }
                    }
                    else
                    {
                        targetLoc = squadObjective.Location;
                        splinterParent = null;
                    }
                }
                else if (squadObjective.Location == null)
                {
                    targetLoc = null;
                    splinterParent = null;
                }
                else
                {
                    var excludeForLoot = UnionWithAgentSkips(_splinterScratch, agent);
                    var splinter = waypointSystem.FindLootSplinterForFollower(
                        squadObjective.Location, squad, excludeForLoot,
                        squad.Personality != null
                            ? squad.Personality.SplinterSearchRadius
                            : Orbit.Sain.PersonalityFallback.SplinterSearchRadius);
                    if (splinter != null)
                    {
                        targetLoc = splinter;
                        splinterParent = squadObjective.Location;
                        _splinterScratch.Add(splinter.Id);
                    }
                    else
                    {
                        targetLoc = squadObjective.Location;
                        splinterParent = null;
                    }
                }

                // Single-claim a fresh squad-anchor corpse to the own-kill killer (routed above); any other
                // member would just pile on and fail the claim. Once the body's been value-skipped it's
                // leftovers and a lower-threshold member may return — don't block that.
                if (!tookOwnKillCorpse && targetLoc != null
                    && targetLoc.Category == WaypointCategory.Corpse
                    && squadObjective.Location != null && targetLoc.Id == squadObjective.Location.Id
                    && !CorpseValueSkippedByAnyMember(squad, targetLoc.Id))
                {
                    if (i == 0 && !AnyMemberDesignatedForCorpse(squad, targetLoc.Id))
                    {
                        // No eligible killer is currently coming for this body. The leader may take it
                        // rather than parking the whole squad around an unreachable follower's queue.
                    }
                    else
                    {
                        // Not this member's body to take, but don't freeze in place either: patrol / loot around
                        // the anchor while the killer works the corpse.
                        var aroundAnchor = waypointSystem.FindRoamSplinterForMember(
                            agent.Position, squadObjective.Location.Position, squad,
                            UnionWithAgentSkips(_splinterScratch, agent),
                            ServerConfig.MainObjectives.RoamSplinterRadius,
                            allowLooseLoot: true, allowContainerLoot: true, allowCorpse: false, allowSynthetic: true);
                        if (aroundAnchor != null)
                        {
                            targetLoc = aroundAnchor;
                            splinterParent = squadObjective.Location;
                            _splinterScratch.Add(aroundAnchor.Id);
                        }
                        else
                        {
                            targetLoc = null;
                            splinterParent = null;
                        }
                    }
                }

                // Splinters do not pass through the shared waypoint's assignment gate. Authorize the
                // selected target's doors before either moving or taking the already-in-radius shortcut.
                if (targetLoc != null && !waypointSystem.TryPrepareMemberWaypoint(agent, targetLoc, splinterParent, out var accessPending))
                {
                    if (accessPending) continue;
                    Log.Debug($"{agent} member waypoint access rejected: {targetLoc}; selecting another target");
                    targetLoc = null;
                    splinterParent = null;
                }

                // Keep searching on later ticks (claims can be released and corpses can appear), but do not
                // repeatedly reset/log the same empty assignment while another member is still looting.
                if (locallyExhausted && agentObjective.Location == null
                    && agentObjective.SplinterParent == null && agentObjective.Status == ObjectiveStatus.None)
                    continue;

                agentObjective.Location = targetLoc;
                agentObjective.SplinterParent = splinterParent;
                agentObjective.DispatchTime = Time.time;

                // Distance check / already-in-radius short-circuit is per- AGENT (against their splinter or
                // the squad anchor — whichever they got), not per-squad. Without this followers with a
                // splinter would inherit the squad- anchor distance check and deadlock.
                if (targetLoc?.Category == WaypointCategory.Exfil)
                {
                    // Being above a bunker is inside its loose radius, not an extraction arrival.
                    // Goto owns the real trigger check and the existing local fallback timeout.
                    agentObjective.Status = ObjectiveStatus.None;
                    agentObjective.ExfilOutsideTriggerSince = -1f;
                }
                else if (targetLoc != null)
                {
                    var distSqr = (targetLoc.Position - agent.Position).sqrMagnitude;
                    if (distSqr <= targetLoc.RadiusSqr)
                    {
                        if (GotoObjectiveAction.IsLootableForAgent(agent, targetLoc)
                            && waypointSystem.TryClaim(targetLoc.Id, agent.Id))
                        {
                            agentObjective.Status = ObjectiveStatus.Looting;
                            Log.Debug($"{agent} new objective {targetLoc} already in radius, claim OK → Looting (skipped Goto)");
                        }
                        else
                        {
                            agentObjective.Status = ObjectiveStatus.Finished;
                            Log.Debug($"{agent} new objective {targetLoc} already in radius → Finished (skipped Goto)");
                        }
                    }
                    else
                    {
                        agentObjective.Status = ObjectiveStatus.None;
                    }
                }
                else
                {
                    agentObjective.Status = ObjectiveStatus.None;
                }

                // Cover points are computed around the squad anchor — followers on a splinter still rally
                // back here once they're done.
                if (squadObjective.Location != null && squadObjective.CoverPoints.Count > 0)
                {
                    var coverPointIdx = i % squadObjective.CoverPoints.Count;
                    agent.Guard.CoverPoint = squadObjective.CoverPoints[coverPointIdx];
                }
                else
                {
                    // Anchors without cover points (runtime corpse / combat-caller waypoints): clear the
                    // slot so Guard can't reuse a cover point picked for a previous objective and travel
                    // back to it.
                    agent.Guard.CoverPoint = null;
                }

                Log.Debug($"{agent} assigned objective {targetLoc}{(splinterParent != null ? $" (splinter of {splinterParent})" : "")}");
            }

            if (agentObjective.Location == null)
                continue;

            switch (agent.Objective.Status)
            {
                case ObjectiveStatus.Failed:
                    finishedCount++;
                    break;
                case ObjectiveStatus.Finished:
                {
                    finishedCount++;

                    if (squadObjective.Status == SquadObjectiveState.Wait)
                        break;

                    // A member actually reached — clear the en-route failure streak so a future bad run
                    // starts at zero.
                    squad.ConsecutiveFailedDispatches = 0;

                    // First squad member to reach the objective. If it was a Quest, mark the POI as
                    // permanently consumed for this squad — doing the same quest trigger twice doesn't make
                    // sense. Loot and Synthetic have their own mechanisms (Loot via the loot routine;
                    // Synthetic via the cooldown set up in AssignNewObjective below).
                    if (squadObjective.Location != null
                        && squadObjective.Location.Category == WaypointCategory.Quest)
                    {
                        squad.CompletedPoiIds.Add(squadObjective.Location.Id);
                        Log.Debug($"{squad} completed Quest {squadObjective.Location} — permanent squad blacklist");

                        // Mark the matching Quest main objective Completed. PickFromCell's owner-only gate
                        // guarantees only the squad whose main owns this trigger ID could have picked the POI
                        // — so finding a matching main here is expected.
                        if (squad.MainObjectives != null)
                        {
                            var triggerId = squadObjective.Location.Name;
                            for (var m = 0; m < squad.MainObjectives.Count; m++)
                            {
                                var main = squad.MainObjectives[m];
                                if (main.Type != MainObjectiveType.Quest) continue;
                                if (main.QuestTriggerId != triggerId) continue;
                                if (main.Completed) continue;
                                main.Completed = true;
                                Log.Info($"{squad} Quest main '{triggerId}' completed (arrived at trigger)");
                                break;
                            }
                        }
                    }

                    // (Opportunistic-corpse interrupt resume lives in the loot routine's completion path — it
                    // must fire when the looter actually finishes the corpse, not when the first follower
                    // hits Finished after claim failure. Triggering here would swap squad.Objective away from
                    // the corpse mid-loot, realign the looter off-target and abort the loot animation.)

                    Log.Debug($"{agent} reached squad objective {squadObjective.Location}");
                    var waitDuration = _guardDuration.SampleGaussian();
                    squadObjective.Status = SquadObjectiveState.Wait;
                    ResetDuration(squadObjective, waitDuration);
                    Log.Debug($"{squad} engaging wait mode for {waitDuration} seconds");
                    break;
                }
                case ObjectiveStatus.None:
                case ObjectiveStatus.Moving:
                default:
                    break;
            }
        }

        return finishedCount;
    }

    private bool TryAdvanceExhaustedLoot(Squad squad, int finishedCount, int locallyExhaustedCount)
    {
        // UpdateAgents reports exhaustion only after a LootValue local search found no eligible target
        // after reaching a loot or patrol anchor. Unknown nulls and failed travel do not qualify.
        if (locallyExhaustedCount == 0 || finishedCount + locallyExhaustedCount != squad.Size
            || squad.ExtractRequested || squad.CombatCallerMemberIdx >= 0
            || squad.PreInterruptObjectiveLocation != null || Time.time < squad.GhostFightUntil
            || waypointSystem.IsClaimed(squad.Objective.Location.Id))
            return false;

        for (var i = 0; i < squad.Size; i++)
        {
            var member = squad.Members[i];
            if (!member.IsActive || member.SoloExtractRequested
                || member.Bot?.Memory is { HaveEnemy: true } or { IsUnderFire: true }
                || member.LootHandler is { LootTaskRunning: true }
                || (member.Objective.Location != null && waypointSystem.IsClaimed(member.Objective.Location.Id))
                || member.Objective.Status == ObjectiveStatus.Failed)
                return false;
        }

        var objective = squad.Objective;
        // A null/unchanged result still uses the cooldown. Do not fall through to the expired generic
        // wait timer and bypass it. Active members continue through the normal dispatch path above.
        if (Time.time < objective.NextLootExhaustionRecheckAt) return true;
        objective.NextLootExhaustionRecheckAt = Time.time + 2f;
        Log.Debug($"{squad} local loot exhausted: {locallyExhaustedCount} without a target, {finishedCount} finished; re-evaluating {objective.Location}");
        // RequestNear applies the normal claims, floor and reachability checks. Exhausting a local
        // radius alone never marks the main cell clean or increments an en-route failure streak.
        AssignNewObjective(squad, completedCurrent: true);
        return true;
    }

    // ── Main objectives: tick + completion + extract trigger ────────
    //
    // Walks the squad's pending main objectives each tick. Per type: Kills: enter roam phase when any member
    // is in the anchor cell; complete when the rolled duration elapses (timer runs continuously, doesn't
    // reset if members wander out — the constant force pulls them back). LootValue: complete when all loot
    // POIs in the anchor cell are looted globally or blacklisted by the squad, OR all members have full
    // inventory, OR the timeout fires. Quest: completion is handled by the arrival path in UpdateAgents.
    //
    // When ALL mains are Completed (or the list is null/empty for boss / raider squads), flips
    // ExtractRequested so the next dispatch bee- lines to the nearest eligible exfil.
    private void TickMainObjectives(Squad squad)
    {
        using var timing = PerformanceJournal.Measure(TransitionPhase.StrategyObjectives, "strategy-operation", "TickMainObjectives", squad.Id);
        if (squad.MainObjectives == null || squad.MainObjectives.Count == 0) return;
        var allDone = true;
        var now = Time.time;
        for (var i = 0; i < squad.MainObjectives.Count; i++)
        {
            var main = squad.MainObjectives[i];
            if (main.Completed) continue;
            allDone = false;
            if (!main.CanPursue(squad.MainObjectives)) continue;
            CheckMainCompletion(squad, main, now);
            // Bump the revision so raid-review re-snapshots immediately rather than at its next periodic poll.
            if (main.Completed) Orbit.Api.OrbitTelemetry.MainObjectivesRevision++;
        }
        if (allDone && !squad.BossLoot.Pending && !squad.ExtractRequested && ServerConfig.MainObjectives.ExtractOnAllCompleted)
        {
            squad.ExtractRequested = true;
            squad.ExtractRequestedReason = "all mains done";
            Log.Info($"{squad} all main objectives completed — flipping ExtractRequested");
        }
    }

    private void CheckMainCompletion(Squad squad, MainObjective main, float now)
    {
        using var timing = PerformanceJournal.Measure(TransitionPhase.StrategyObjectives, "strategy-operation", "CheckMainCompletion", squad.Id);
        switch (main.Type)
        {
            case MainObjectiveType.ExtractCamp:
                if (!ServerConfig.Ambush.Allows(squad.Leader?.BotCategory) || !ServerConfig.Ambush.Extracts.Enabled
                    || !waypointSystem.IsAmbushSiteAvailable(main.CampSite, squad.Leader?.BotCategory))
                {
                    main.Completed = true;
                    Log.Info($"AMBUSH: {squad} extract main skipped: disabled or exit unavailable");
                }
                break;
            case MainObjectiveType.Kills:
                // An ambush Kill main completes through time actually spent holding its cover.
                if (main.KillAmbush && ServerConfig.Ambush.Allows(squad.Leader?.BotCategory)
                    && ServerConfig.Ambush.Hotspots.Enabled) break;
                // Phase 1: roam starts as soon as ANY member is in the anchor cell. Same semantic as
                // LootValue cell entry — every cell guarantees at least one reachable POI, so the bot has
                // something to roam onto immediately.
                if (main.KillsRoamStartedAt <= 0f)
                {
                    for (var i = 0; i < squad.Size; i++)
                    {
                        if (waypointSystem.WorldToCell(squad.Members[i].Position) == main.CellCoords
                            && !squad.Members[i].Bot.IsDead
                            && waypointSystem.MatchesZoneFloorAtTarget(main.ZoneFloorId, main.Position, squad.Members[i].Position))
                        {
                            main.KillsRoamStartedAt = now;
                            Log.Info($"{squad} Kills main at {main.CellCoords} entered roam phase (member {i} in cell, {main.KillsRoamTargetDuration:F0}s)");
                            break;
                        }
                    }
                }
                // Scoped mains count time spent on their actual floor. Legacy mains keep their timer.
                var elapsed = now - main.KillsRoamStartedAt;
                if (!string.IsNullOrEmpty(main.ZoneFloorId))
                {
                    var onFloor = false;
                    for (var i = 0; i < squad.Size; i++)
                        if (!squad.Members[i].Bot.IsDead
                            && waypointSystem.MatchesZoneFloorAtTarget(main.ZoneFloorId, main.Position, squad.Members[i].Position))
                            onFloor = true;
                    if (main.KillsRoamStartedAt > 0f && onFloor)
                    {
                        if (main.KillsFloorLastTick > 0f) main.KillsFloorElapsed += now - main.KillsFloorLastTick;
                        main.KillsFloorLastTick = now;
                    }
                    else main.KillsFloorLastTick = 0f;
                    elapsed = main.KillsFloorElapsed;
                }
                // Phase 2: timer-based completion
                if (main.KillsRoamStartedAt > 0f
                    && elapsed >= main.KillsRoamTargetDuration)
                {
                    main.Completed = true;
                    Log.Info($"{squad} Kills main at {main.CellCoords} completed after {elapsed:F0}s roam");
                }
                break;

            case MainObjectiveType.LootValue:
                // Unified cell-entry detection. Both LootValueStartedAt (arms the timeout) and
                // LootValueEnteredAt (gates cell- clean completion + raid-review "in progress" visual) flip
                // together when ANY member enters the main's cell.
                //
                // Any member (not just leader) counts.
                if (main.LootValueStartedAt <= 0f)
                {
                    for (var i = 0; i < squad.Size; i++)
                    {
                        if (waypointSystem.WorldToCell(squad.Members[i].Position) == main.CellCoords)
                        {
                            main.LootValueStartedAt = now;
                            main.LootValueEnteredAt = now;
                            Log.Info($"{squad} LootValue main at {main.CellCoords} cell entered (member {i}) — {ServerConfig.MainObjectives.LootValueTimeoutSeconds:F0}s timeout armed, cleanup engaged");
                            // Apply the per-POI coverage roll exactly once, on cell entry.
                            waypointSystem.ApplyLootCoverageRollForCell(squad, main.CellCoords);
                            LootMainEntry.Begin(squad, main, waypointSystem);
                            break;
                        }
                    }
                }
                // Engaged-time accounting. "Engaged" = at least one member in the anchor cell AND the squad
                // isn't in combat. The timeout ticks down ONLY during engaged time — a firefight mid-loot
                // pauses the counter and resumes when SAIN hands the bot back over, simulating a player who
                // gets interrupted, fights, then returns to looting.
                if (main.LootValueStartedAt > 0f)
                {
                    LootMainEntry.RefreshLocalReachability(squad, main, waypointSystem);
                    var anyMemberInCell = false;
                    for (var i = 0; i < squad.Size; i++)
                    {
                        if (waypointSystem.WorldToCell(squad.Members[i].Position) == main.CellCoords)
                        {
                            anyMemberInCell = true;
                            break;
                        }
                    }
                    var engaged = anyMemberInCell && squad.CombatCallerMemberIdx < 0;
                    if (engaged)
                    {
                        if (main.LootValueLastEngagedAt > 0f)
                            main.LootValueElapsedEngaged += now - main.LootValueLastEngagedAt;
                        main.LootValueLastEngagedAt = now;
                        if (main.LootValueInterrupted)
                        {
                            main.LootValueInterrupted = false;
                            Log.Info($"{squad} LootValue main at {main.CellCoords} resumed (engaged-time so far {main.LootValueElapsedEngaged:F0}s / {ServerConfig.MainObjectives.LootValueTimeoutSeconds:F0}s)");
                        }
                    }
                    else
                    {
                        main.LootValueLastEngagedAt = 0f;
                        if (!main.LootValueInterrupted && main.LootValueEnteredAt > 0f)
                        {
                            main.LootValueInterrupted = true;
                            var cause = !anyMemberInCell ? "out of cell" : "in combat (SAIN took over)";
                            Log.Info($"{squad} LootValue main at {main.CellCoords} interrupted — {cause} (engaged-time so far {main.LootValueElapsedEngaged:F0}s)");
                        }
                    }

                    if (main.LootValueElapsedEngaged >= ServerConfig.MainObjectives.LootValueTimeoutSeconds)
                    {
                        main.Completed = true;
                        Log.Info($"{squad} LootValue main at {main.CellCoords} completed by engaged-time timeout ({main.LootValueElapsedEngaged:F0}s of in-cell non-combat looting)");
                        return;
                    }
                }
                // Cell-clean: all loot POIs in the anchor cell are either looted globally (removed) or
                // blacklisted by this squad. GATED on the squad having actually entered the cell — without
                // this gate a Main loot can complete "by cell- clean" even when no member ever set foot in
                // the cell.
                if (main.LootValueEnteredAt > 0f && main.LootValueLocalValidation
                    && IsLootCellCleaned(squad, main.CellCoords))
                {
                    main.Completed = true;
                    Log.Info($"{squad} LootValue main at {main.CellCoords} completed by cell-clean");
                    return;
                }
                break;

            case MainObjectiveType.Quest:
                // Completion is handled exclusively in UpdateAgents when a squad member reaches the Quest
                // trigger POI. No timeout fallback here — quests are binary: reached or not. The
                // generation-time reachability gate already filters out quests on disconnected navmesh
                // fragments. If the squad genuinely can't reach the trigger mid- raid,
                // CheckTimeExtractTrigger takes over.
                break;
        }
    }

    private bool IsLootCellCleaned(Squad squad, Vector2Int cellCoords)
    {
        // Deferred path queries must finish before their candidates can be ruled out.
        if (waypointSystem.DispatchPending(squad)) return false;
        foreach (var member in squad.Members)
            if (waypointSystem.DispatchPending(member)) return false;
        if (cellCoords.x < 0 || cellCoords.x >= waypointSystem.GridSize.x
            || cellCoords.y < 0 || cellCoords.y >= waypointSystem.GridSize.y) return true;
        ref var cell = ref waypointSystem.Cells[cellCoords.x, cellCoords.y];
        if (!cell.HasWaypoints) return true;
        for (var i = 0; i < cell.Waypoints.Count; i++)
        {
            var loc = cell.Waypoints[i];
            if (loc.Category != WaypointCategory.ContainerLoot
                && loc.Category != WaypointCategory.LooseLoot
                && loc.Category != WaypointCategory.Corpse) continue;
            // "Done" = blacklisted, known-unreachable, or value-skipped by every alive member. Counting only
            // CompletedPoiIds would park the squad in the cell until the full LootValue timeout.
            if (!squad.CompletedPoiIds.Contains(loc.Id)
                && !waypointSystem.IsSquadKnownUnreachable(squad, loc.Id)
                && !WaypointSystem.AllAliveMembersValueSkipped(squad, loc.Id))
                return false;
        }
        return true;
    }

    // Minimum interval between two refreshes of the same cell for the same squad. Set high enough that a
    // leader oscillating between two adjacent cells doesn't keep re-running NavMesh.CalculatePath on the
    // shared 6 neighbours on every transition.
    private const float UnreachabilityRefreshCooldownSeconds = 300f;

    private void RefreshUnreachabilityAroundLeader(Squad squad)
    {
        using var timing = PerformanceJournal.Measure(TransitionPhase.StrategyReachability, "strategy-operation", "RefreshUnreachabilityAroundLeader", squad.Id);
        var leader = squad.Leader?.Bot;
        if (leader == null) return;

        var currentCell = waypointSystem.WorldToCell(leader.Position);
        if (squad.LastKnownCell.HasValue && squad.LastKnownCell.Value == currentCell) return;

        // Leader just entered a new cell — re-evaluate stale unreachability verdicts for the 3x3
        // neighbourhood. Cells we already refreshed within the cooldown are skipped.
        var now = Time.time;
        for (var dx = -1; dx <= 1; dx++)
        {
            for (var dy = -1; dy <= 1; dy++)
            {
                var c = currentCell + new Vector2Int(dx, dy);
                if (squad.RecentlyRefreshedCells.TryGetValue(c, out var lastRefresh)
                    && now - lastRefresh < UnreachabilityRefreshCooldownSeconds)
                {
                    continue;
                }
                waypointSystem.ClearSquadUnreachabilityForCell(squad, c);
                squad.RecentlyRefreshedCells[c] = now;
            }
        }
        squad.LastKnownCell = currentCell;
    }

    private bool ShouldUseIndependentDispatch(Squad squad)
    {
        if (squad?.MainObjectives == null) return false;
        var leader = squad.Leader?.Bot;
        if (leader == null) return false;
        for (var i = 0; i < squad.MainObjectives.Count; i++)
        {
            var main = squad.MainObjectives[i];
            if (main.Completed) continue;
            if (main.Type == MainObjectiveType.Kills && !main.KillAmbush && main.KillsRoamStartedAt > 0f) return true;
            if (main.Type == MainObjectiveType.LootValue)
            {
                for (var k = 0; k < squad.Size; k++)
                {
                    var mCell = waypointSystem.WorldToCell(squad.Members[k].Position);
                    if (mCell == main.CellCoords) return true;
                }
            }
        }
        return false;
    }

    /// <summary>
    /// The squad's currently "active" main objective in the independent- dispatch sense — Kills main in roam
    /// phase OR LootValue main with at least one member in the cell. Kills wins if both are active. Used as
    /// the ANCHOR for roam splinter searches so the bot oscillates around the main's anchor position, not
    /// around its own drifting current position.
    /// </summary>
    private MainObjective ActiveIndependentMain(Squad squad)
    {
        if (squad?.MainObjectives == null) return null;
        MainObjective lootValueActive = null;
        for (var i = 0; i < squad.MainObjectives.Count; i++)
        {
            var main = squad.MainObjectives[i];
            if (main.Completed) continue;
            if (main.Type == MainObjectiveType.Kills && !main.KillAmbush && main.KillsRoamStartedAt > 0f)
                return main;
            if (main.Type == MainObjectiveType.LootValue && lootValueActive == null)
            {
                for (var k = 0; k < squad.Size; k++)
                {
                    var mCell = waypointSystem.WorldToCell(squad.Members[k].Position);
                    if (mCell == main.CellCoords) { lootValueActive = main; break; }
                }
            }
        }
        return lootValueActive;
    }

    private void DetectAndUpdateCombatCaller(Squad squad)
    {
        // Solo squads can't rally. Without this gate a lone bot whose Memory.HaveEnemy stays stuck true (SAIN
        // holds the flag for a window after losing LoS) self-registers as caller every tick, pinning the
        // objective to a waypoint at its own feet and resetting StartTime so the wait timer never fires —
        // stranding the bot once SAIN's mover stops producing motion.
        if (squad.Size <= 1)
        {
            if (squad.CombatCallerMemberIdx >= 0)
            {
                Log.Info($"{squad} combat caller cleared (squad is solo — nobody to rally)");
                squad.CombatCallerMemberIdx = -1;
            }
            return;
        }

        var now = Time.time;
        var anyInCombat = false;
        var callerIdx = squad.CombatCallerMemberIdx;
        for (var i = 0; i < squad.Size; i++)
        {
            var member = squad.Members[i];
            var bot = member?.Bot;
            if (bot?.Memory == null) continue;
            if (bot.Memory.HaveEnemy || bot.Memory.IsUnderFire)
            {
                anyInCombat = true;
                callerIdx = i;
                squad.CombatCallerPosition = member.Position;
                squad.CombatCallerLastSeenAt = now;
                break;
            }
        }
        if (anyInCombat)
        {
            if (squad.CombatCallerMemberIdx != callerIdx)
            {
                Log.Info($"{squad} combat caller = {squad.Members[callerIdx]} at {squad.CombatCallerPosition}");
                squad.CombatCallerMemberIdx = callerIdx;
            }
        }
        else if (squad.CombatCallerMemberIdx >= 0
                 && now - squad.CombatCallerLastSeenAt > ServerConfig.MainObjectives.CombatCallerGraceSeconds)
        {
            Log.Info($"{squad} combat caller cleared (grace elapsed)");
            squad.CombatCallerMemberIdx = -1;
        }
    }

    // After this many consecutive "all members failed en-route" branches on the same objective the squad
    // gives up on that POI and adds it to CompletedPoiIds. Previously the same threshold triggered a
    // teleport-rescue snapping every member onto the POI's navmesh sample point; removed because it dropped
    // bots into locked rooms and caused infinite TP attempt loops on mains whose anchor was off-navmesh.
    private const int UnreachableBlacklistThreshold = 5;

    // Looting a full kit with the simulated search delays is slow, so this is measured from when a member
    // actually reaches the body (not from the squad anchoring on it). Only past this is the loot genuinely
    // hung, so force-blacklist and re-dispatch.
    private const float CorpseStuckTimeoutSeconds = 180f;

    // A pending corpse is reserved for its killer while that agent remains in the squad.
    private bool AnyMemberDesignatedForCorpse(Squad squad, int locId)
    {
        if (squad?.Members == null) return false;
        for (var i = 0; i < squad.Members.Count; i++)
        {
            var m = squad.Members[i];
            if (m == null) continue;
            if (m.OwnKillCorpseIds.Contains(locId) && !m.ValueSkippedPoiIds.Contains(locId)
                && (waypointSystem.IsClaimed(locId)
                    || waypointSystem.TryGetOwnKillCorpseForAgent(squad, m, locId) != null)) return true;
        }
        return false;
    }

    // "Progress" for the corpse-stuck watchdog: a member whose current objective IS the corpse and who is
    // still working it (dispatched / travelling / looting). Finished and Failed don't count — if everyone has
    // dropped or failed the body, the anchor is dead and the timeout must run.
    private static bool SquadAnyMemberPursuingCorpse(Squad squad, Waypoint corpse)
    {
        if (squad?.Members == null || corpse == null) return false;
        for (var i = 0; i < squad.Members.Count; i++)
        {
            var m = squad.Members[i];
            if (m?.Objective?.Location == null || m.Objective.Location != corpse) continue;
            var s = m.Objective.Status;
            if (s == ObjectiveStatus.None || s == ObjectiveStatus.Moving || s == ObjectiveStatus.Looting) return true;
        }
        return false;
    }

    /// <summary>
    /// Anchor position of the first in-progress main objective on the squad's list, or <see langword="null"/>
    /// if no main is engaged. "In progress" = LootValue cell entered or Kills roam phase started. Used by
    /// <see cref="AssignNewObjective"/> to pin the nearest-POI search to the main's cell instead of drifting
    /// to the leader's current position.
    /// </summary>
    private static Vector3? GetInProgressMainAnchor(Squad squad)
    {
        if (squad?.MainObjectives == null) return null;
        for (var i = 0; i < squad.MainObjectives.Count; i++)
        {
            var m = squad.MainObjectives[i];
            if (m.Completed) continue;
            if (m.Type == MainObjectiveType.LootValue && m.LootValueEnteredAt > 0f) return m.Position;
            if (m.Type == MainObjectiveType.Kills && !m.KillAmbush && m.KillsRoamStartedAt > 0f) return m.Position;
        }
        return null;
    }

    private void AssignNewObjective(Squad squad, bool completedCurrent = false)
    {
        if (waypointSystem.DispatchPending(squad)) completedCurrent |= squad.PendingDispatchCompletedCurrent;
        using var timing = PerformanceJournal.Measure(TransitionPhase.StrategySelection, "strategy-operation", "AssignNewObjective", squad.Id);
        // A null result must not rescan every cell on every strategy tick. Real movement or a new
        // extraction request can bypass the short backoff; an unchanged failure cannot.
        if (Time.time < squad.NextDispatchAttemptAt
            && squad.ExtractRequested == squad.FailedDispatchWasExtract
            && (squad.Leader.Bot.Position - squad.FailedDispatchPosition).sqrMagnitude < 9f) return;
        var objective = squad.Objective;

        // Synthetic POIs get a short-term visit cooldown so the squad doesn't ping-pong on the same
        // patrol-filler coordinate between wait timers. Quest is handled separately (permanent squad
        // blacklist via CompletedPoiIds). Loot POIs already have their own mechanisms.
        if (objective.Location != null
            && objective.Location.Category == WaypointCategory.Synthetic)
        {
            squad.RecentlyVisitedPoiCooldowns[objective.Location.Id] =
                Time.time + ServerConfig.MainObjectives.SyntheticVisitCooldownSeconds;
        }

        Waypoint newLocation;
        // Loot-value extract: a squad that's hit its threshold ignores normal cell dispatch and bee-lines to
        // the nearest eligible exfil. ALWAYS re-route to the exfil while ExtractRequested is set. Re-picking
        // the same exfil is a no-op alignment-wise (UpdateAgents sees the same reference and skips
        // reassignment), and any agent already in Status=Extracting keeps its own action running — wait-timer
        // reset doesn't affect ExtractAction's countdown.
        if (squad.ExtractRequested)
        {
            newLocation = waypointSystem.FindNearestEligibleExfil(squad);
            if (newLocation == null && waypointSystem.ExfilSearchPending(squad)) return;
            if (newLocation != null)
            {
                Log.Debug($"{squad} ExtractRequested → routing to nearest eligible exfil {newLocation}");
            }
            else
            {
                // No eligible exfil left on the map. Fall back to normal dispatch so the squad doesn't stall
                // forever.
                Log.Warning($"{squad} ExtractRequested but no eligible exfil found, falling back to normal dispatch");
                newLocation = waypointSystem.RequestNear(squad, squad.Leader.Bot.Position, objective.LocationPrevious);
            }
        }
        else
        {
            // Leash dispatch to the in-progress main's anchor only when the leader has drifted outside the
            // roam radius. Inside the leash the leader's current position drives RequestNear so the squad
            // keeps drifting freely on splinter loot / nearby POIs. Outside the leash, bias the next dispatch
            // toward the main's anchor so the squad doesn't permanently wander off.
            var leaderPos = squad.Leader.Bot.Position;
            var pinAnchor = GetInProgressMainAnchor(squad);
            Vector3 requestPos;
            if (pinAnchor.HasValue)
            {
                var leash = ServerConfig.MainObjectives.RoamSplinterRadius;
                // XZ-only — anchor.Y is 0 by construction (cell centre / custom zone), so 3D Euclidean would
                // wrongly snap the leader back the moment a height mismatch crosses the leash threshold (a
                // bot looting in a Resort basement is "50m away" from the cell anchor at Y=0 in 3D, but 0m
                // horizontally).
                var distSqr = WaypointSystem.XzDistanceSqr(leaderPos, pinAnchor.Value);
                requestPos = distSqr > leash * leash ? pinAnchor.Value : leaderPos;
            }
            else
            {
                requestPos = leaderPos;
            }
            newLocation = waypointSystem.RequestNear(squad, requestPos, objective.LocationPrevious);

            // A completed-wait re-pick landing back on the loot POI the squad just finished means the local
            // pool has collapsed to a single exhausted candidate (value-skips are per-agent, so the POI
            // never enters CompletedPoiIds on its own, and loot waits are zero-duration — nothing else
            // breaks the cycle). Squad-complete it and re-pick once; en-route failures keep their own
            // 3-strike blacklist path via completedCurrent=false. Corpses are completed by loot outcomes,
            // never by timer expiry or by selecting the same still-unlooted body again.
            if (completedCurrent && newLocation != null && objective.Location != null
                && newLocation.Id == objective.Location.Id
                && newLocation.Category != WaypointCategory.Corpse
                && IsLootPoi(newLocation.Category))
            {
                squad.CompletedPoiIds.Add(newLocation.Id);
                Log.Info($"{squad} re-pick returned just-visited {newLocation} — squad-completed it (memory size={squad.CompletedPoiIds.Count}), re-picking");
                newLocation = waypointSystem.RequestNear(squad, requestPos, objective.Location);
            }
        }

        if (newLocation == null)
        {
            if (waypointSystem.DispatchPending(squad))
            {
                squad.PendingDispatchCompletedCurrent = completedCurrent;
                return;
            }
            squad.PendingDispatchCompletedCurrent = false;
            squad.ConsecutiveDispatchFailures++;
            var delay = squad.ConsecutiveDispatchFailures == 1 ? .5f
                : squad.ConsecutiveDispatchFailures == 2 ? 1f
                : squad.ConsecutiveDispatchFailures == 3 ? 2f : 5f;
            squad.NextDispatchAttemptAt = Time.time + delay;
            squad.FailedDispatchWasExtract = squad.ExtractRequested;
            squad.FailedDispatchPosition = squad.Leader.Bot.Position;
            Log.Debug($"{squad} dispatch backoff: no eligible objective, retry in {delay:F1}s");
            Log.Debug($"{squad} received null objective location (consecutive failures: {squad.ConsecutiveDispatchFailures})");
            return;
        }

        // Successful dispatch — reset the islanded counter so we don't pin a squad to its cell forever after
        // one good streak of failures.
        squad.ConsecutiveDispatchFailures = 0;
        squad.PendingDispatchCompletedCurrent = false;
        squad.NextDispatchAttemptAt = 0f;

        objective.LocationPrevious = objective.Location;
        objective.Location = newLocation;
        objective.Status = SquadObjectiveState.Active;

        ShufflePickCoverPoints(objective, Math.Max(squad.TargetMembersCount, squad.Size));

        ResetDuration(objective, _moveTimeout.SampleGaussian());

        Log.Debug($"{squad} assigned objective {objective.Location}");
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    private static bool IsLootPoi(WaypointCategory category)
    {
        return category == WaypointCategory.LooseLoot
               || category == WaypointCategory.ContainerLoot
               || category == WaypointCategory.Corpse;
    }

    private static void ShufflePickCoverPoints(SquadObjective objective, int count)
    {
        var location = objective.Location;

        objective.CoverPoints.Clear();

        // Runtime Corpse waypoints (corpse-registration patch) ship with an empty cover-points list because
        // we don't run the cover sampler mid-raid. Without this guard the Random.Range / indexer / modulo
        // below all explode and AssignNewObjective throws.
        if (location.CoverPoints.Count == 0) return;

        var randIdx = Random.Range(0, location.CoverPoints.Count);

        for (var i = 0; i < count; i++)
        {
            objective.CoverPoints.Add(location.CoverPoints[randIdx]);
            randIdx = (randIdx + 1) % location.CoverPoints.Count;
            Log.Debug($"Getting cover point at {randIdx}/{location.CoverPoints.Count}");
        }
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    private static void ResetDuration(SquadObjective objective, float duration)
    {
        objective.StartTime = Time.time;
        objective.Duration = duration;
        objective.DurationAdjusted = false;
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    private static void AdjustDuration(SquadObjective objective, float duration)
    {
        objective.Duration = duration;
        objective.DurationAdjusted = true;
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    private static void AdjustDuration(SquadObjective objective, float duration, float startTime)
    {
        objective.StartTime = startTime;
        objective.Duration = duration;
        objective.DurationAdjusted = true;
    }
}
