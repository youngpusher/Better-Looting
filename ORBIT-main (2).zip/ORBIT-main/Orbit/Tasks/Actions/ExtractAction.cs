using System.Collections.Generic;
using Comfort.Common;
using EFT.Interactive;
using Orbit.Core;
using Orbit.Entities;
using Orbit.Navigation;
using UnityEngine;

namespace Orbit.Tasks.Actions;

/// <summary>
/// Final stage of an exfil dispatch. The squad has arrived at the Exfil POI and GotoObjectiveAction
/// transitioned us to
/// <see cref="ObjectiveStatus.Extracting"/>. This action holds the bot in
/// place for a short countdown (mirrors the real player exfil animation), then calls BSG's
/// <c>BotLeaveData.RemoveFromMap</c> to despawn the bot.
///
/// Two-mode behaviour: • Standard (foot) exfils — per-agent 5s kneel then despawn. Members extract as they
/// arrive; no synchronisation. • V-Ex / SharedTimer (car) exfils — the squad waits at the exfil for all
/// currently-alive members to arrive (capped at VExWaitTimeout), then a single 60s countdown ticks for the
/// whole squad. At the end every member at the V-Ex despawns simultaneously and the exfil is flipped to
/// NotPresent so the human player can't use it after the car has "left". A real player extract triggers the
/// car to leave for good, so we match that.
/// </summary>
public class ExtractAction(AgentData dataset, float hysteresis) : Task<Agent>(hysteresis)
{
    // Beats LootContainerAction's 0.75 — once we're extracting, nothing else (loot, guard, goto) should
    // preempt.
    private const float UtilityScore = 0.9f;

    // Time a foot-exfil bot kneels at the exfil before being removed. Real player exfils are 7-10s; we keep
    // it short so squads don't pile up at the same point waiting (visually ugly).
    private const float FootExtractStandTime = 5f;

    // V-Ex car countdown — once all squad members have arrived at the SharedTimer exfil (or VExWaitTimeout
    // elapsed), this many seconds tick down before the simultaneous despawn. Matches BSG's typical V-Ex
    // countdown.
    private const float VExCountdownSeconds = 60f;

    // Max time the squad will wait at a V-Ex for the LAST member to arrive before starting the countdown
    // anyway. Without this cap a single straggler (stuck on geometry, killed mid-route without us noticing
    // yet) blocks the rest of the squad's extract.
    private const float VExWaitTimeout = 90f;

    // Per-agent kneel-start timestamp for foot exfils. V-Ex uses a per- squad shared timer instead (VExState
    // below).
    private readonly Dictionary<int, float> _footExtractStartTime = new();

    // Per-squad shared timer for V-Ex extracts.
    private sealed class VExState
    {
        public ExfiltrationPoint Exfil;
        public float FirstArrivalTime;     // when the FIRST member reached the V-Ex
        public Entity Owner;              // IDs are recycled; never inherit another party's countdown
        public float CountdownStartTime = -1f;
        public float DepartureTime = -1f;
        public readonly List<Agent> Departing = new();
        public System.Action<ExfiltrationPoint, EExfiltrationStatus> OnDeparture;

        public void Unsubscribe()
        {
            if (OnDeparture != null) Exfil.OnStatusChanged -= OnDeparture;
            OnDeparture = null;
        }
    }
    private readonly Dictionary<int, VExState> _vexSquadStates = new();
    private readonly Dictionary<int, VExState> _vexSoloStates = new();

    public override void UpdateScore(int ordinal)
    {
        var agents = dataset.Entities.Values;
        for (var i = 0; i < agents.Count; i++)
        {
            var agent = agents[i];
            agent.TaskScores[ordinal] = agent.Objective.Status == ObjectiveStatus.Extracting ? UtilityScore : 0f;
        }
    }

    public override void Update()
    {
        for (var i = 0; i < ActiveEntities.Count; i++)
            UpdateAgent(ActiveEntities[i]);
    }

    private void UpdateAgent(Agent agent)
    {
        if (!agent.IsActive || agent.Objective.Status != ObjectiveStatus.Extracting) return;
        if (RejectFlareExit(agent))
        {
            _footExtractStartTime.Remove(agent.Id);
            return;
        }
        var loc = agent.Objective.Location;
        if (loc == null || loc.Category != WaypointCategory.Exfil
            || loc.Target is not ExfiltrationPoint exfil)
        {
            // Defensive: agent in Extracting state without a valid exfil POI. Should not happen; fall back to
            // the foot-extract path so we don't strand the bot.
            UpdateFootExtract(agent);
            return;
        }

        if (NoBackpackExfil.RequiresDrop(exfil))
        {
            var preparation = NoBackpackExfil.Prepare(agent, loc);
            if (preparation == NoBackpackExfil.Preparation.Rejected)
            { _footExtractStartTime.Remove(agent.Id); ExfilArrival.Abandon(agent, loc); return; }
            if (TryRecoverNoBackpack(agent)) return;
            if (preparation != NoBackpackExfil.Preparation.Ready || !NoBackpackExfil.CanFinish(agent, loc))
            {
                _footExtractStartTime.Remove(agent.Id);
                // Stay committed while native backpack bookkeeping catches up. If displaced,
                // resume the same approach instead of releasing the exit to normal dispatch.
                if (!ExfilArrival.IsInside(agent, loc))
                {
                    agent.Objective.Status = ObjectiveStatus.None;
                    agent.Objective.DispatchTime = Time.time;
                }
                return;
            }
        }

        if (exfil.Settings != null
            && exfil.Settings.ExfiltrationType == EExfiltrationType.SharedTimer)
        {
            UpdateVExExtract(agent, exfil);
            return;
        }

        if (Orbit.Systems.MultiStepAccess.IsConditional(exfil)
            && (!Orbit.Systems.MultiStepAccess.ExitActive(exfil, agent) || !ExfilArrival.IsInside(agent, loc)))
        {
            _footExtractStartTime.Remove(agent.Id);
            agent.Objective.Status = ObjectiveStatus.None;
            agent.Objective.DispatchTime = Time.time;
            return;
        }

        UpdateFootExtract(agent);
    }

    private void UpdateFootExtract(Agent agent)
    {
        var now = Time.time;
        if (!_footExtractStartTime.TryGetValue(agent.Id, out var startedAt))
        {
            _footExtractStartTime[agent.Id] = now;
            try { agent.Bot.SetPose(0.25f); } catch { /* some boss followers don't expose pose */ }
            Log.Info($"{agent} ExtractAction: stand at {agent.Position} for {FootExtractStandTime}s before despawn");
            return;
        }

        var seconds = agent.Objective.Location?.Target is ExfiltrationPoint point
                      && Orbit.Systems.MultiStepAccess.IsConditional(point)
            ? Mathf.Max(FootExtractStandTime, point.Settings.ExfiltrationTime) : FootExtractStandTime;
        if (now - startedAt < seconds) return;

        _footExtractStartTime.Remove(agent.Id);
        DespawnAgent(agent);
    }

    private void UpdateVExExtract(Agent agent, ExfiltrationPoint exfil)
    {
        var squad = agent.Squad;
        var solo = agent.SoloExtractRequested || squad == null;
        Entity owner = solo ? agent : squad;
        var states = solo ? _vexSoloStates : _vexSquadStates;
        var location = agent.Objective.Location;

        states.TryGetValue(owner.Id, out var state);
        if (state != null && (!ReferenceEquals(state.Owner, owner) || state.Exfil != exfil))
        {
            state.Unsubscribe();
            states.Remove(owner.Id);
            state = null;
        }
        if (ExfilArrival.IsUnavailable(exfil))
        {
            var departed = state != null && FinishNativeDeparture(state, exfil);
            state?.Unsubscribe();
            states.Remove(owner.Id);
            if (departed && state.Departing.Contains(agent)) return;
            Log.Info($"{agent} ExtractAction: V-Ex {exfil.name} unavailable, selecting another exfil");
            ExfilArrival.Abandon(agent, location);
            return;
        }
        var now = Time.time;
        if (state != null && state.CountdownStartTime >= 0f
            && now - state.CountdownStartTime >= VExCountdownSeconds)
        {
            state.Unsubscribe();
            // A combat interruption does not pause the countdown, but only bots still at the car can leave.
            if (solo)
            {
                FinishCarParticipant(agent, exfil);
                DepartCar(exfil);
            }
            else
                DespawnSquadAtVEx(squad, exfil);
            states.Remove(owner.Id);
            return;
        }

        if (!ExfilArrival.IsInside(agent, location))
        {
            agent.Objective.Status = ObjectiveStatus.None;
            agent.Objective.ArrivalPath = null;
            agent.Objective.ExfilOutsideTriggerSince = -1f;
            agent.Objective.DispatchTime = now;
            Log.Info($"{agent} ExtractAction: outside V-Ex {exfil.name}, returning to trigger ({Vector3.Distance(agent.Position, location.Position):F1}m from anchor)");
            return;
        }

        if (state == null)
        {
            // First member of this squad to land on this V-Ex (or squad's exfil target changed). Initialise
            // state, kneel the bot, and start the wait window.
            state = new VExState
            {
                Exfil = exfil,
                Owner = owner,
                FirstArrivalTime = now,
                CountdownStartTime = solo ? now : -1f,
            };
            states[owner.Id] = state;
            var pending = state;
            pending.OnDeparture = (point, previous) => CaptureNativeDeparture(pending, point, previous);
            exfil.OnStatusChanged += pending.OnDeparture;
            if (solo)
                Log.Info($"{agent} ExtractAction: solo V-Ex {exfil.name} countdown started ({VExCountdownSeconds:F0}s), no squad wait");
            else
                Log.Info($"{squad}: first member {agent} arrived at V-Ex {exfil.name}, waiting up to {VExWaitTimeout:F0}s for the rest of the squad");
        }

        try { agent.Bot.SetPose(0.25f); } catch { /* pose hook missing on some specialisations */ }

        if (state.CountdownStartTime >= 0f) return;

        // Pre-countdown: are we ready to start the timer?
        var allReady = IsAllSquadAtVEx(squad, exfil);
        var waitedTooLong = now - state.FirstArrivalTime >= VExWaitTimeout;
        if (allReady || waitedTooLong)
        {
            state.CountdownStartTime = now;
            Log.Info($"{squad}: V-Ex {exfil.name} countdown started ({VExCountdownSeconds:F0}s) — reason: {(allReady ? "all squad members arrived" : "wait timeout reached, leaving stragglers behind")}");
        }
    }

    private static bool IsAllSquadAtVEx(Squad squad, ExfiltrationPoint exfil)
    {
        for (var i = 0; i < squad.Size; i++)
        {
            var member = squad.Members[i];
            if (member == null) continue;
            if (member.Objective.Status != ObjectiveStatus.Extracting) return false;
            if (member.Objective.Location?.Target != exfil) return false;
            if (!member.IsActive || member.SoloExtractRequested
                || !ExfilArrival.IsInside(member, member.Objective.Location)) return false;
        }
        return true;
    }

    private void DespawnSquadAtVEx(Squad squad, ExfiltrationPoint exfil)
    {
        Log.Info($"{squad}: V-Ex {exfil.name} countdown ended, checking members at the exfil and marking the car departed");
        // Snapshot the member list — DespawnAgent mutates Squad.Members through OrbitManager.RemoveAgent;
        // iterating in-place would skip entries.
        var snapshot = new List<Agent>(squad.Size);
        for (var i = 0; i < squad.Size; i++) snapshot.Add(squad.Members[i]);
        for (var i = 0; i < snapshot.Count; i++)
        {
            var member = snapshot[i];
            if (member == null || !member.IsActive || member.SoloExtractRequested) continue;
            if (member.Objective.Location?.Target != exfil) continue;
            FinishCarParticipant(member, exfil);
        }
        // NotPresent disables the trigger in BSG, so complete presence checks before changing its status.
        DepartCar(exfil);
    }

    private static void CaptureNativeDeparture(VExState state, ExfiltrationPoint exfil, EExfiltrationStatus previous)
    {
        if (previous != EExfiltrationStatus.Countdown || exfil.Status != EExfiltrationStatus.NotPresent) return;
        state.DepartureTime = Time.time;
        state.Unsubscribe();
        // The car has actually left. Capture waiting participants at its last live
        // bounds regardless of ORBIT's countdown or the squad's gathering timer.
        // BSG disables the trigger before this event; complete removal on the next
        // action update so we do not mutate bot collections inside BSG's callback.
        if (state.Owner is Agent solo) Capture(solo);
        else if (state.Owner is Squad squad)
            for (var i = 0; i < squad.Size; i++)
                if (squad.Members[i] is { SoloExtractRequested: false } member) Capture(member);

        void Capture(Agent member)
        {
            if (member?.IsActive == true && member.Objective.Status == ObjectiveStatus.Extracting
                && member.Objective.Location?.Target == exfil
                && ExfilArrival.IsInsideDepartingCar(member, member.Objective.Location))
                state.Departing.Add(member);
        }
    }

    private static bool FinishNativeDeparture(VExState state, ExfiltrationPoint exfil)
    {
        // Only the bots captured at the actual departure may leave. Resuming combat or
        // reaching this location later must not redeem a car that has already gone.
        if (exfil.Status != EExfiltrationStatus.NotPresent || state.DepartureTime < 0f
            || Time.time - state.DepartureTime > Mathf.Max(1f, Time.deltaTime * 2f)) return false;
        for (var i = state.Departing.Count - 1; i >= 0; i--)
        {
            var member = state.Departing[i];
            if (!member.IsActive || member.Objective.Status != ObjectiveStatus.Extracting
                || member.Objective.Location?.Target != exfil
                || !ExfilArrival.IsInsideDepartingCar(member, member.Objective.Location))
            {
                state.Departing.RemoveAt(i);
                continue;
            }
            Log.Info($"{member} ExtractAction: V-Ex {exfil.name} native departure confirmed at trigger");
            DespawnAgent(member);
        }
        return state.Departing.Count > 0;
    }

    private void FinishCarParticipant(Agent agent, ExfiltrationPoint exfil)
    {
        if (agent.Objective.Status == ObjectiveStatus.Extracting
            && ExfilArrival.IsInside(agent, agent.Objective.Location))
        {
            _footExtractStartTime.Remove(agent.Id);
            DespawnAgent(agent);
            return;
        }
        Log.Info($"{agent} ExtractAction: missed V-Ex {exfil.name} departure, selecting another exfil");
        ExfilArrival.Abandon(agent, agent.Objective.Location);
    }

    private static void DepartCar(ExfiltrationPoint exfil)
    {
        // Mark the car as departed so the human player can't pile in after the squad has left. NotPresent is
        // BSG's natural V-Ex post-departure state — broadcasts to clients so the UI hides the exfil from the
        // player.
        try
        {
            exfil.SetStatusLogged(EExfiltrationStatus.NotPresent, "Orbit-VEx-Departed");
        }
        catch (System.Exception e)
        {
            Log.Warning($"V-Ex {exfil.name} SetStatusLogged(NotPresent) failed: {e.Message}");
        }
    }

    internal static bool TryRecoverNoBackpack(Agent agent)
    {
        if (!NoBackpackExfil.RecoveryDue(agent, agent.Objective.Location)) return false;
        Log.Warning($"{agent} NO-BACKPACK: recovery despawn at {agent.Objective.Location} after confirmed drop and local wait");
        NoBackpackExfil.PauseRecovery(agent);
        agent.Objective.Status = ObjectiveStatus.Extracting;
        DespawnAgent(agent, recoverNoBackpack: true);
        return true;
    }

    private static bool DespawnAgent(Agent agent, bool recoverNoBackpack = false, bool preserveApproach = false)
    {
        // Also protect stale targets and every arrival/watchdog fallback.
        if (RejectFlareExit(agent)) return false;
        // Also protects emergency watchdog and arrival-fallback callers from bypassing backpack requirements.
        if (!(recoverNoBackpack ? NoBackpackExfil.CanRecover(agent, agent.Objective.Location)
                : NoBackpackExfil.CanFinish(agent, agent.Objective.Location)))
        {
            if (!preserveApproach)
            {
                agent.Objective.Status = ObjectiveStatus.None;
                agent.Objective.DispatchTime = Time.time;
            }
            return false;
        }
        // BotOwner already torn down on BSG's side (died / despawned / left while we were counting down):
        // there is nothing left to remove from the map — drop our agent instead of NRE-retrying every cycle
        // until raid end.
        if (agent.Bot?.LeaveData == null)
        {
            Log.Warning($"{agent} ExtractAction: BotOwner/LeaveData already gone — dropping agent without RemoveFromMap");
            Singleton<OrbitManager>.Instance?.RemoveAgent(agent);
            return true;
        }

        try
        {
            var loc = agent.Objective.Location;
            Log.Info($"{agent} ExtractAction: extracting via {loc} (LeaveData.RemoveFromMap)");
            using (Orbit.Helpers.NativeExtractionDiagnostics.Begin(agent.Player?.ProfileId))
                agent.Bot.LeaveData.RemoveFromMap();
        }
        catch (System.Exception e)
        {
            Log.Error($"{agent} ExtractAction.RemoveFromMap failed: {e}");
            if (!preserveApproach)
                agent.Objective.Status = NoBackpackExfil.RetainAfterDrop(agent, agent.Objective.Location)
                    ? ObjectiveStatus.Extracting : ObjectiveStatus.Failed;
            return false;
        }

        var manager = Singleton<OrbitManager>.Instance;
        manager?.RemoveAgent(agent);
        return true;
    }

    private static bool RejectFlareExit(Agent agent)
    {
        var location = agent.Objective.Location;
        if (location?.Target is not ExfiltrationPoint exit || !FlareExfil.RequiresSignal(exit)) return false;
        Log.Info($"EXFIL BLOCKED: {agent} exit={location.Name} reason=requires signal flare; selecting another exit");
        ExfilArrival.Abandon(agent, location);
        return true;
    }

    // A stalled extraction can be completed without the normal action ticking,
    // but the final removal still rejects unsupported exits.
    internal static bool ForceDespawn(Agent agent)
    {
        if (agent.Objective.Location?.Target is not ExfiltrationPoint exit
            || ExfilArrival.IsSharedTimer(exit) || ExfilArrival.IsUnavailable(exit)) return false;
        if (Orbit.Systems.MultiStepAccess.IsConditional(exit)
            && (!Orbit.Systems.MultiStepAccess.ExitActive(exit, agent)
                || !ExfilArrival.IsInside(agent, agent.Objective.Location))) return false;
        // A refused watchdog attempt must not invalidate the path still taking us to
        // the trigger or the entrance where a backpack can actually be dropped.
        return DespawnAgent(agent, preserveApproach: true);
    }

    protected override void Deactivate(Agent entity)
    {
        NoBackpackExfil.PauseRecovery(entity);
        // Combat takeover or external state change mid-extract — drop the per-agent foot tracker. The V-Ex
        // squad timer is intentionally NOT cleared here: if a member temporarily exits Extracting (combat,
        // takeover), the squad-wide countdown keeps ticking so the rest of the squad isn't stranded.
        if (_footExtractStartTime.Remove(entity.Id))
            Log.Debug($"{entity} ExtractAction.Deactivate: foot-extract timer cancelled");
    }
}
