using Orbit.Helpers;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using BepInEx;
using BepInEx.Bootstrap;
using BepInEx.Configuration;
using BepInEx.Logging;
using Comfort.Common;
using DrakiaXYZ.BigBrain.Brains;
using EFT;
using Orbit.Brain;
using Orbit.Config;
using Orbit.Core;
using Orbit.Interop;
using Orbit.Looting;
using Orbit.Patches;
using Orbit.Systems;
using SPT.Reflection.Patching;
using UnityEngine;

namespace Orbit;

/// <summary>
/// BepInEx entry point. The F12 surface now only holds client-side logging knobs plus a button
/// to the server web UI; every behaviour tunable lives in the ORBIT server mod's config, fetched
/// via Helpers.ServerConfig. <see cref="LogSource"/> exposes the BepInEx ManualLogSource consumed by
/// <see cref="Log"/> — named <c>LogSource</c> rather than
/// <c>Log</c> so the static <see cref="Orbit.Log"/> helper class doesn't
/// collide.
/// </summary>
[BepInPlugin(PluginGuid, PluginName, OrbitVersion)]
[BepInDependency("xyz.drakia.bigbrain")]
[BepInDependency("xyz.drakia.waypoints")]
[BepInDependency("me.sol.sain")]
[SuppressMessage("ReSharper", "MemberCanBePrivate.Global")]
public class Plugin : BaseUnityPlugin
{
    public const string PluginGuid = "com.chazut.orbit";
    public const string PluginName = "ORBIT";
    public const string OrbitVersion = "3.1.0";
    public const string ReleaseVersion = "3.1.0";

    public static ManualLogSource LogSource;

    // ╔══════════════════════════════════════════════════════════════╗
    // ║ F12 ConfigEntries                                              ║
    // ╚══════════════════════════════════════════════════════════════╝

    // Client-side knobs only. Everything that drives bot behaviour lives in the ORBIT server
    // mod's config (web UI at /orbit), fetched through Helpers.ServerConfig at boot + raid start.
    public static ConfigEntry<bool> QuietLogging;
    public static ConfigEntry<OrbitLogLevel> LogLevels;
    public static ConfigEntry<bool> PerfLogging;
    public static ConfigEntry<bool> DoorCaptureEnabled;
    public static ConfigEntry<KeyboardShortcut> DoorCaptureKey;

    // Faction-mod plugin GUIDs — same Chainloader detection raid-review uses.
    private const string UntarPluginGuid = "com.untargh.tacticaltoaster";
    private const string RuafPluginGuid = "com.ruafcomehome.tacticaltoaster";
    private const string BlackDivPluginGuid = "com.blackdiv.tacticaltoaster";
    // ISB's BepInEx entry is ISBNotify.dll ("ISB SOF Notifier") — the spawn-patch + role-detection
    // core, present whenever ISB bots are. The companion ISBSpecialForcesPlugin.dll is a plain library
    // (no BepInPlugin), so this is the GUID to detect. Matched as a substring (see
    // ApplyFactionTakeoverToggle) so a future com.-prefixed variant ("com.samc137.ISBinfo") still registers.
    private const string IsbPluginGuid = "samc137.ISBinfo";
    private const string CombineSoldiersPluginGuid = "com.manimal.combinesoldiers";

    private void Update()
    {
        Log.Refresh();
        PerformanceJournal.RefreshWriter();
        DebugExport.Refresh();
        DoorCaptureTool.Update();
    }

    private void OnGUI() => DoorCaptureTool.DrawStatus();

    private void OnApplicationQuit() { DebugExport.Shutdown(); Log.Shutdown(); }
    private void OnDestroy() { DebugExport.Shutdown(); Log.Shutdown(); }

    private void Awake()
    {
        LogSource = Logger;
        Log.Initialize();

        StartCoroutine(DelayedLoad());
    }

    private IEnumerator DelayedLoad()
    {
        // Wait for the user's other 500 mods to settle before binding config and registering patches —
        // early-boot races against handlers other mods install in Awake are otherwise too easy to lose.
        yield return new WaitForSeconds(5);

        try
        {
            SetupConfig();
            Log.ReportSettings("startup");
            QuietLogging.SettingChanged += (_, _) => Log.ReportSettings("quiet-changed");
            LogLevels.SettingChanged += (_, _) => Log.ReportSettings("levels-changed");
            PerfLogging.SettingChanged += (_, _) => Log.ReportSettings("performance-changed");
        }
        catch (Exception ex)
        {
            // Config binding errors must not crash boot — they'd block the entire plugin from registering.
            // Log and continue with defaults.
            Log.Error($"ORBIT config bind failed (sub-systems will degrade to defaults): {ex}");
        }

        // Item pricing: ItemPriceLookup prefers EFT's Singleton<EFT.HandBook.Handbook> when present, else the
        // server-fetched price cache below. EFT.HandBook.Handbook is built by the main-menu/profile flow, which a
        // FIKA headless client skips, so we can't depend on it (issue #5).
        StartCoroutine(WaitForHandbook());

        Log.Always($"ORBIT {ReleaseVersion} initialised");
        PipDisablerCompat.Initialize();

        // Patches — wrap each in EnableSafe so one bad patch (wrong Harmony parameter name, missing target
        // method after a game update) can't collapse the rest of init. Without the guard a single failure
        // skips every subsequent .Enable() AND the BrainManager.AddCustomLayer call, leaving bots stranded on
        // BSG's vanilla brain.
        EnableSafe(new OrbitInitPatch());
        EnableSafe(new OrbitTickPatch());
        EnableSafe(new OrbitDisposePatch());

        EnableSafe(new DoorCarverShrinkPatch());
        EnableSafe(new DoorUnlockTracePatch());

        EnableSafe(new SoftTeleportTracePatch());
        EnableSafe(new OrbitMoverHandoffFallbackPatch());
        EnableSafe(new OrbitMoverHandoffLinkedPatch());
        EnableSafe(new HardTeleportTracePatch());
        EnableSafe(new MovementContextHumanizePatch());
        EnableSafe(new BotVaultingPatch());
        EnableSafe(new ManualFixedUpdateSkipPatch());
        EnableSafe(new OrbitMoverMotionPatch());

        // Ghost Mode: awake bots must not raycast dormant (deactivated) ones. Inert while the limiter is
        // OFF — the dormant set stays empty and the prefix falls through.
        EnableSafe(new DormantVisionPatch());
        EnableSafe(new GhostWeaponParentPatch());
        EnableSafe(new GhostWeaponPoolPatch());
        EnableSafe(new GhostSpawnRegistrationPatch());
        EnableSafe(new GhostSpawnActivationPatch());
        EnableSafe(new GhostSpawnContactPatch());
        EnableSafe(new GhostSpawnFirstSightPatch());
        EnableSafe(new GhostSpawnSainContactPatch());
        EnableSafe(new DormantBrainThrottlePatch());
        EnableSafe(new NativeGhostDecisionPatch());
        EnableSafe(new NativeGhostSainCleanupPatch());
        EnableSafe(new NativeGhostSainStopPatch());
        EnableSafe(new NativeGhostMoveOrderPatch());
        EnableSafe(new NativeGhostPointOrderPatch());
        EnableSafe(new NativeGhostWayOrderPatch());
        EnableSafe(new NativeGhostZigzagGoalPatch());
        EnableSafe(new NativeGhostReachDistancePatch());
        EnableSafe(new NativePatrolArrivalDiagnosticPatch());
        EnableSafe(new NativeFollowerArrivalDiagnosticPatch());
        EnableSafe(new NativeGlukharChoiceDiagnosticPatch());
        NativeGhostBodyPatches.Enable();
        BotHealingFixesCompat.Enable();
        SanitarPatrolMedicinePatch.Enable();
        SniperSainDecisionPatch.Enable();
        EnableSafe(new SniperContactRangePatch());
        LootPatrolResumePatch.Enable();
        EnableSafe(new DormantDamageProbePatch());
        EnableSafe(new DormantGroundCollisionPatch());
        EnableSafe(new DormantAvoidDangerBypassPatch());
        EnableSafe(new DormantBoarAvoidDangerBypassPatch());

        // Inventory subsystem patches
        EnableSafe(new AirdropLandedPatch());
        EnableSafe(new AirdropReleasedPatch());
        EnableSafe(new InventoryChangePatch());
        EnableSafe(new LootItemKilledPatch());
        EnableSafe(new CorpseRegistrationPatch());
        GhostDeathDiagnostics.Enable();
        new SpawnDeathPatch().Enable();
        NativeExtractionDiagnostics.Enable();
        GhostWakeActivationDiagnostics.Enable();
        EnableSafe(new RescueInterceptPatch());

        // BSG layer bypasses
        EnableSafe(new AssaultEnemyFarBypassPatch());  // takes over scavs at long range
        EnableSafe(new ExfilLayerBypassPatch());       // high-priority layer (79) that strands bots near exfils
        EnableSafe(new PtrlBirdEyeBypassPatch());      // splits Bird Eye away from the Goons

        // Faction behaviour now lives server-side (ORBIT server mod, web UI at /orbit) so it applies
        // wherever the bots run — headless included. One synchronous fetch at boot, defaults on failure.
        ServerConfig.Fetch();

        // Faction-mod takeover toggles. OrbitBrainLayer always registers against the standard PMC / Scav /
        // Goon brain names, so mods like UNTAR / RUAF / BlackDiv whose bots use BaseBrain="PMC" are hijacked
        // by default. When a toggle is OFF we publish the mod's WildSpawnType-name substring to
        // OrbitBrainLayer's exclusion list, and the layer stays inert for matching bots so their own custom
        // layers (GoToCheckpoint / HuntTarget / …) win instead.
        ApplyFactionTakeoverToggle(UntarPluginGuid,    "UNTAR",         ServerConfig.Factions.TakeOverUntar,        "untar");
        // RUAF Come Home ships two factions: the base RUAF roles (ruaf*) and the RUAF Hardcore "Remnant"
        // roles (remnant*). Both belong to the same mod, so the toggle must exclude both substrings.
        ApplyFactionTakeoverToggle(RuafPluginGuid,     "RUAF",          ServerConfig.Factions.TakeOverRuaf,         "ruaf", "remnant");
        ApplyFactionTakeoverToggle(BlackDivPluginGuid, "BlackDivision", ServerConfig.Factions.TakeOverBlackDivision, "blackDiv");
        // ISB's WildSpawnType members all begin with "ISB" (ISBSpecialForces, ISBTeamLeader,
        // ISBFirefly*, …), so the single substring covers the whole faction (match is case-insensitive
        // and no vanilla role name contains "isb").
        ApplyFactionTakeoverToggle(IsbPluginGuid,      "ISB",           ServerConfig.Factions.TakeOverIsb,           "ISB");
        ApplyFactionTakeoverToggle(CombineSoldiersPluginGuid, "CombineSoldiers", ServerConfig.Factions.TakeOverCombineSoldiers, "Combine");

        OrbitBrainLayer.SetVanillaScavExclusion(ServerConfig.Factions.VanillaScavs);
        OrbitBrainLayer.SetVanillaGoonExclusion(ServerConfig.Factions.VanillaGoons);
        OrbitBrainLayer.SetVanillaCultistExclusion(ServerConfig.Factions.VanillaCultists);
        OrbitBrainLayer.SetVanillaRaiderExclusion(ServerConfig.Factions.VanillaRaiders);
        OrbitBrainLayer.SetVanillaRogueExclusion(ServerConfig.Factions.VanillaRogues);
        OrbitBrainLayer.SetVanillaBloodhoundExclusion(ServerConfig.Factions.VanillaBloodhounds);
        if (ServerConfig.Factions.VanillaScavs) Logger.LogInfo("Disable ORBIT on scavs ON — bot scavs running on BSG's vanilla brain (PlayerScavs unaffected).");
        if (ServerConfig.Factions.VanillaGoons) Logger.LogInfo("Disable ORBIT on goons ON — Goons (Knight / Big Pipe / Bird Eye) running on BSG's vanilla brain.");
        if (ServerConfig.Factions.VanillaCultists) Logger.LogInfo("Disable ORBIT on cultists ON — Cultists (Priest / Warriors / cursed scavs) running on BSG's vanilla brain.");
        Logger.LogInfo($"FACTION CONTROL: raiders={(ServerConfig.Factions.VanillaRaiders ? "native" : "ORBIT")} rogues={(ServerConfig.Factions.VanillaRogues ? "native" : "ORBIT")}");
        if (ServerConfig.Factions.VanillaBloodhounds) Logger.LogInfo("Disable ORBIT on bloodhounds ON — Bloodhounds (Smugglers / arena spawns) running on BSG's vanilla brain.");

        var brains = new List<string>
        {
            nameof(BsgBrain.PMC),
            nameof(BsgBrain.PmcUsec),
            nameof(BsgBrain.PmcBear),
            nameof(BsgBrain.Assault),
            nameof(BsgBrain.Knight),
            nameof(BsgBrain.BigPipe),
            nameof(BsgBrain.BirdEye),
            nameof(BsgBrain.SectantPriest),
            nameof(BsgBrain.SectantWarrior)
        };

        // BSG's native LootPatrol layer (priority 3) steals control from OrbitBrainLayer whenever we briefly go
        // inactive post-combat, stranding bots in vanilla loot wandering. Strip it only for the brains ORBIT
        // fully owns, not the borrowed brains added below whose shared vanilla bots must stay 100% vanilla.
        // Pass a COPY: BigBrain keeps the list reference, so the brains.Add(...) below for the borrowed
        // brains would silently extend the LootPatrol strip to them too.
        BrainManager.RemoveLayer("LootPatrol", new List<string>(brains));

        // Custom factions borrow these brains. Rogues use their own opt-out; Gluhar and his scouts
        // remain excluded by role. Keep native LootPatrol on these shared brains for excluded bots.
        brains.Add(nameof(BsgBrain.ExUsec));
        brains.Add(nameof(BsgBrain.BossGluhar));
        brains.Add(nameof(BsgBrain.FollowerGluharScout));
        BrainManager.AddCustomLayer(typeof(OrbitBrainLayer), brains, 19);

        Log.Always($"ORBIT {ReleaseVersion} fully loaded, BrainManager wired");
    }

    private IEnumerator WaitForHandbook()
    {
        // Populate the server-backed price cache up front so headless clients (where EFT.HandBook.Handbook never
        // appears) still have loot values. The SPT HTTP backend is up well before any raid; if the fetch
        // somehow fails it falls back to the on-disk handbook.json (see HandbookPriceCache).
        Looting.HandbookPriceCache.Init();

        // Normal clients also get Singleton<EFT.HandBook.Handbook> once the menu builds it; ItemPriceLookup uses it
        // directly when present. This is just a log — pricing already works via the cache either way, so we
        // don't block on it forever like before (headless would never satisfy the old loop).
        var attempts = 0;
        while (Singleton<EFT.HandBook.Handbook>.Instance == null && attempts < 60)
        {
            attempts++;
            yield return new WaitForSeconds(1f);
        }
        Log.Info(Singleton<EFT.HandBook.Handbook>.Instance != null
            ? $"EFT.HandBook.Handbook ready after {attempts}s — ItemPriceLookup using it directly"
            : "EFT.HandBook.Handbook absent (headless client?) — ItemPriceLookup using the server price cache");
    }

    /// <summary>
    /// Detects a faction-mod by BepInEx plugin GUID. When OFF AND the mod is present, the role-name substring
    /// is registered with OrbitBrainLayer's exclusion list so matching bots stay on their mod's behaviour
    /// layers.
    /// </summary>
    private static void ApplyFactionTakeoverToggle(string pluginGuid, string label, bool takeoverOn, params string[] roleSubstrings)
    {
        // Exact GUID match first, then a case-insensitive substring fallback so a faction whose
        // plugin GUID gains/loses a prefix (e.g. a "com." on ISB's notifier) is still detected.
        var detected = Chainloader.PluginInfos.ContainsKey(pluginGuid);
        if (!detected)
        {
            foreach (var key in Chainloader.PluginInfos.Keys)
            {
                if (key.IndexOf(pluginGuid, StringComparison.OrdinalIgnoreCase) >= 0) { detected = true; break; }
            }
        }
        if (!detected)
        {
            LogSource.LogDebug($"{label}: plugin '{pluginGuid}' not present — toggle inert");
            return;
        }
        if (pluginGuid == UntarPluginGuid) OrbitBrainLayer.LegacyUntarHunts = true;
        if (takeoverOn)
        {
            LogSource.LogInfo($"{label}: detected and takeover ON — ORBIT will run its bots");
        }
        else
        {
            foreach (var sub in roleSubstrings)
                OrbitBrainLayer.AddExcludedRoleSubstring(sub);
            LogSource.LogInfo($"{label}: detected and takeover OFF — bots with role containing [{string.Join(", ", roleSubstrings)}] will skip ORBIT");
        }
    }

    private static void EnableSafe(ModulePatch patch)
    {
        try
        {
            patch.Enable();
            if (patch is NativeGhostDecisionPatch) NativeGhostSystem.DecisionGuardReady = true;
            if (patch is DormantBrainThrottlePatch) NativeGhostSystem.BrainBridgeReady = true;
            if (patch is NativeGhostSainCleanupPatch) NativeGhostSystem.SainCleanupScopeReady = true;
            if (patch is NativeGhostSainStopPatch) NativeGhostSystem.SainStopGuardReady = true;
            if (patch is NativeGhostMoveOrderPatch) NativeGhostSystem.MoveOrderReady = true;
            if (patch is NativeGhostPointOrderPatch) NativeGhostSystem.PointOrderReady = true;
            if (patch is NativeGhostWayOrderPatch) NativeGhostSystem.WayOrderReady = true;
            if (patch is NativeGhostZigzagGoalPatch) NativeGhostSystem.GoalOrderReady = true;
            if (patch is NativeGhostReachDistancePatch) NativeGhostSystem.ReachOrderReady = true;
        }
        catch (Exception ex)
        {
            LogSource.LogError($"Patch {patch.GetType().Name} failed to enable: {ex.Message} — ORBIT will continue without it");
        }
    }

    private void SetupConfig()
    {
        // Cfg-FILE section (kept so existing values persist); the F12 DISPLAY category is
        // blanked via Category="" — with a single section the header was pure noise.
        const string essentials = "01. Essentials";

        Config.Bind(essentials, "Server config", string.Empty, new ConfigDescription(
            "Every behaviour setting (factions, looting, extraction, Ghost Mode...) lives in the ORBIT server web UI.",
            null, new ConfigurationManagerAttributes { Category = "", Order = 2, HideDefaultButton = true, CustomDrawer = DrawWebConfigButton }));

        QuietLogging = Config.Bind(essentials, "Quiet logging", true, new ConfigDescription(
            "ON (default): clean log - only warnings & errors, regardless of the Log levels below. Turn it OFF to use the Log levels (e.g. tick Debug there before sending a bug report).",
            null, new ConfigurationManagerAttributes { Category = "", Order = 1 }));
        LogLevels = Config.Bind(essentials, "Log levels", OrbitLogLevel.Info | OrbitLogLevel.Warning | OrbitLogLevel.Error, new ConfigDescription(
            "Which message levels ORBIT writes when Quiet logging is OFF. Info and Debug are queued for background writing; warnings and errors remain immediate. Debug works in Release builds. Full logging still has a CPU cost; sustained overload reports dropped verbose messages.",
            null, new ConfigurationManagerAttributes { Category = "", Order = 0 }));
        PerfLogging = Config.Bind(essentials, "Performance logging", false, new ConfigDescription(
            "ON: records every frame over the 60 FPS budget (16.67 ms), slow bot decisions and Ghost transitions, even with Quiet logging. Automatically saves a performance journal in BepInEx/ORBIT/diagnostics during the raid and a final summary when it ends. Larger stalls also save a detailed JSON capture.",
            null, new ConfigurationManagerAttributes { Category = "", Order = -1 }));
        Config.Bind(essentials, "Debug report", string.Empty, new ConfigDescription(
            "Creates a ZIP with this client's log and the selected raid's diagnostics/replay. On Fika clients, requests matching host/headless files through your SPT server only when clicked. Keep the host running for the first collection. Completed snapshots are cached on the server for 24 hours. Transfers run in the background, limited to 1 MiB/s per direction. Saved in BepInEx/ORBIT/debug.",
            null, new ConfigurationManagerAttributes { Category = "", Order = -2, HideDefaultButton = true, CustomDrawer = DrawDebugExportButton }));

        const string authoring = "02. Authoring tools";
        DoorCaptureEnabled = Config.Bind(authoring, "Capture Marked Rush doors", false, new ConfigDescription(
            "Enable the in-raid door capture shortcut. Facing a door copies its scene ID and saves a prefilled Marked Rush point in the active server preset. Protected presets become a personal copy. Uncertain room placement is saved disabled for review. Applies next raid.",
            null, new ConfigurationManagerAttributes { Order = 2, DispName = "Capture Rush door" }));
        DoorCaptureKey = Config.Bind(authoring, "Capture door shortcut", new KeyboardShortcut(KeyCode.F8, KeyCode.LeftControl), new ConfigDescription(
            "Close menus and face a door until its interaction prompt appears, then press this shortcut. Requires the matching ORBIT server mod. Existing doors keep their settings; save or discard web editor changes before capturing.",
            null, new ConfigurationManagerAttributes { Order = 1 }));
        Config.Bind(authoring, "Last door capture", string.Empty, new ConfigDescription("Result of the last capture.",
            null, new ConfigurationManagerAttributes { Order = 0, HideDefaultButton = true,
                CustomDrawer = _ => GUILayout.Label(DoorCaptureTool.Status, new GUIStyle(GUI.skin.label) { wordWrap = true }) }));
    }

    private static void DrawDebugExportButton(ConfigEntryBase entry)
    {
        GUILayout.BeginVertical();
        var enabled = GUI.enabled;
        try
        {
            GUI.enabled = enabled && !DebugExport.Busy;
            if (GUILayout.Button(DebugExport.Busy ? "Creating debug ZIP..." : "Create debug ZIP", GUILayout.ExpandWidth(true)))
                DebugExport.Start();
        }
        finally { GUI.enabled = enabled; }
        if (DebugExport.Busy)
        {
            var progress = DebugExport.Progress;
            if (progress != null && progress.Fraction >= 0)
            {
                var track = GUILayoutUtility.GetRect(1f, 18f, GUILayout.ExpandWidth(true));
                GUI.Box(track, GUIContent.none);
                var fill = new Rect(track.x + 2, track.y + 2, (track.width - 4) * progress.Fraction, track.height - 4);
                var oldColor = GUI.color;
                GUI.color = new Color(0.35f, 0.65f, 0.9f, 1f);
                GUI.DrawTexture(fill, Texture2D.whiteTexture);
                GUI.color = oldColor;
            }
            if (DebugExport.CanCancelHost && GUILayout.Button("Cancel host transfer (keep local ZIP)", GUILayout.ExpandWidth(true))) DebugExport.Cancel();
        }
        GUILayout.Label(DebugExport.Status, new GUIStyle(GUI.skin.label) { wordWrap = true });
        if (DebugExport.LastPath != null && GUILayout.Button("Open debug folder", GUILayout.ExpandWidth(true)))
            Application.OpenURL(new Uri(DebugExport.Folder + System.IO.Path.DirectorySeparatorChar).AbsoluteUri);
        GUILayout.EndVertical();
    }

    // F12 helper: a real button that opens the server web UI in the default browser. The drawer
    // replaces the value field entirely (the entry's string value is never used).
    private static void DrawWebConfigButton(ConfigEntryBase entry)
    {
        if (!GUILayout.Button("Open web config UI", GUILayout.ExpandWidth(true))) return;
        var host = "https://127.0.0.1:6969";
        try
        {
            if (!string.IsNullOrEmpty(SPT.Common.Http.RequestHandler.Host))
                host = SPT.Common.Http.RequestHandler.Host;
        }
        catch
        {
            // spt-common quirk — fall back to the default SPT address.
        }
        Application.OpenURL(host + "/orbit");
    }

}
