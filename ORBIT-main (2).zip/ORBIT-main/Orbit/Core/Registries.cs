using System.Collections.Generic;
using System.Runtime.CompilerServices;
using EFT;
using Orbit.Entities;
using Orbit.Sain;
using Orbit.Systems;
using Orbit.Tasks.Actions;
using Orbit.Helpers;

namespace Orbit.Core;

// ╔══════════════════════════════════════════════════════════════════╗
// ║ Registries — bidirectional maps between BSG runtime entities and  ║
// ║ our own. SquadRegistry groups bots into squads based on BSG's     ║
// ║ BotsGroup id; BotRoster maps BSG bot id back to our Agent via a   ║
// ║ growable array (faster than a dictionary for the small-int keys). ║
// ╚══════════════════════════════════════════════════════════════════╝

/// <summary>
/// BSG-bot-id → Agent lookup. Bot ids are dense small integers, so a growable List with null padding
/// outperforms a Dictionary at the access pattern we have (hot path: per-frame patch hooks checking "is this
/// bot one of ours?").
/// </summary>
public class BotRoster
{
    private readonly List<Agent> _agents = [];

    public void AddAgent(Agent agent)
    {
        var bsgId = agent.Bot.Id;

        if (bsgId >= _agents.Count)
        {
            var padding = bsgId - _agents.Count + 1;
            for (var i = 0; i < padding; i++)
                _agents.Add(null);
        }

        _agents[bsgId] = agent;
    }

    public void RemoveAgent(Agent agent)
    {
        var bsgId = agent.Bot.Id;

        if (bsgId >= _agents.Count)
            return;

        _agents[bsgId] = null;
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public bool IsOrbitActive(BotOwner bot)
    {
        var bsgId = bot.Id;

        if (bot.Id >= _agents.Count)
            return false;

        var agent = _agents[bsgId];

        return agent != null && agent.IsActive;
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public Agent GetAgent(BotOwner bot)
    {
        if (bot == null) return null;
        var bsgId = bot.Id;
        if (bsgId < 0 || bsgId >= _agents.Count) return null;
        return _agents[bsgId];
    }
}

/// <summary>
/// Groups agents into squads based on BSG's BotsGroup id, with special handling for vanilla scavs (always
/// solo, never grouped) and PMC squads (deferred SAIN personality resolution before main-objective
/// generation).
/// </summary>
public class SquadRegistry(SquadData squadData, StrategyManager strategyManager, WaypointSystem waypointSystem)
{
    // Keyed by the BotsGroup INSTANCE, not its int Id: BSG recycles group ids across the raid (observed with
    // wave-spawned PMCs, e.g. ABPS PMC waves — a fresh wave can reuse the id of an earlier group). Keying by
    // id made those new bots JOIN the earlier squad and inherit its state (canonical symptom: a
    // freshly-spawned PMC bee-lining across walls to a corpse the old squad killed, bypassing the corpse-LoS
    // gate). A new wave is always a new BotsGroup object, so reference identity can never collide.
    private readonly Dictionary<BotsGroup, int> _squadIdMap = new(16);

    public void AddAgent(Agent agent)
    {
        var bsgGroup = agent.Bot.BotsGroup;

        Squad squad;

        var role = agent.Bot.Profile.Info.Settings.Role;

        // Vanilla scavs (assault / assaultGroup) always get their own 1-member squad — never grouped. The old
        // 'Brown Tide' toggle that let scavs share squads (and congeal into map-spanning waves) has been
        // removed; the settled preference is solo-scav behaviour. Goons, raiders, bosses, PMCs etc still
        // group via BSG BotsGroup id.
        if (role is WildSpawnType.assault or WildSpawnType.assaultGroup)
        {
            squad = AddNewSquad(agent);
        }
        else
        {
            if (_squadIdMap.TryGetValue(bsgGroup, out var squadId))
            {
                squad = squadData.Entities[squadId];
            }
            else
            {
                squad = AddNewSquad(agent);
                _squadIdMap.Add(bsgGroup, squad.Id);
            }
        }

        squad.AddAgent(agent);
        agent.Squad = squad;
        Log.Debug($"Added {agent} to {squad} with {squad.Size} members");
    }

    public void RemoveAgent(Agent agent)
    {
        var squad = agent.Squad;
        squad.RemoveAgent(agent);
        Log.Debug($"Removed {agent} from {squad} with {squad.Size} members remaining");

        // If the squad had committed to extracting and the death wiped enough loot to fall below the
        // new sum-of-survivors threshold, cancel the extract — the surviving members no longer have a
        // reason to bee-line for the exfil. Re-eval BEFORE the leader-reassign / empty-squad cleanup so
        // we don't compute against a half-deconstructed squad. Pass the dead agent so the re-eval can
        // also arm a dead-member-loot-recovery dispatch (survivors bee-line to the corpse).
        LootContainerAction.ReevaluateExtractOnDeath(squad, agent);

        if (squad.Size > 0)
        {
            // Reassign leader if we just removed it.
            if (agent != squad.Leader) return;

            squad.Leader = squad.Members[^1];
            squad.Leader.IsLeader = true;
            Log.Debug($"{squad} assigned new leader {squad.Leader}");
            return;
        }

        Log.Debug($"Removing empty {squad}");
        // Squad ids get recycled when a new BotsGroup joins later — drop every per-squad cache entry
        // keyed by this id so the next squad doesn't inherit stale state (canonical case: corpse-kill
        // credits transferring to a brand-new squad that never killed anyone, bypassing the LoS gate).
        waypointSystem?.ClearSquadCorpseCredits(squad.Id);
        waypointSystem?.CancelMainGeneration(squad);
        if (agent.Bot?.BotsGroup != null) _squadIdMap.Remove(agent.Bot.BotsGroup);
        squadData.Entities.Remove(squad);
        strategyManager.RemoveEntity(squad);
    }

    private Squad AddNewSquad(Agent agent)
    {
        // BSG quirk: BotsGroup.TargetMembersCount is off-by-one (always 0 for scavs, etc.). Bump by 1 to get
        // the real count.
        var targetMembersCount = agent.Bot.BotsGroup.TargetMembersCount + 1;
        var squad = squadData.AddEntity(strategyManager.Tasks.Length, targetMembersCount);
        Log.Debug($"Registered new {squad} with {targetMembersCount} target members");
        squad.Leader = agent;
        squad.Leader.IsLeader = true;
        // Capture leader's spawn world position — used by the waypoint system to derive an Infiltration name
        // when Profile.Info.EntryPoint is empty (mod-spawned PMCs, special-spawn bots).
        squad.SpawnPosition = agent.Bot.GetPlayer != null ? agent.Bot.GetPlayer.Position : agent.Bot.Position;
        Log.Debug($"{squad} assigned new leader {squad.Leader} (spawn pos captured: {squad.SpawnPosition})");

        // Personality resolution is DEFERRED for PMC squads. SAIN attaches its BotComponent asynchronously
        // after spawn (1-2s typical) so calling SainPersonality.GetBrainName at squad creation almost always
        // returns null. Flag the squad as "pending" and let the strategy retry the lookup at every tick until
        // it resolves or the 5 s deadline elapses. Main objectives are NOT generated here for PMCs — they're
        // rolled once the personality is locked, so the mix weights match the resolved archetype.
        //
        // Non-PMC (scavs, PlayerScavs, bosses): no personality, no deferral. Generate mains immediately using
        // the global weights.
        var roleLeader = agent.Bot.Profile?.Info?.Settings?.Role;
        var isPmc = roleLeader.HasValue && IsPmcRole(roleLeader.Value);
        squad.Archetype = PersonalityArchetype.Average;
        squad.Personality = null;
        squad.SainResolutionPending = false;
        if (isPmc && (ServerConfig.Personalities.Enabled))
        {
            squad.SainResolutionPending = true;
            squad.SainResolveDeadline = UnityEngine.Time.time + SainResolveTimeoutSeconds;
            Log.Info($"{squad} PMC personality resolution deferred — strategy retries every tick, {SainResolveTimeoutSeconds:F0}s from first member activation before locking to Average");
            return squad; // skip MainObjectiveBuilder until resolved (see TryResolvePersonality)
        }

        // Roll the squad's main objectives at creation. Builder is player-blind and self-contained — skips
        // boss/raider/goon roles internally, picks anchors from static map data.
        waypointSystem.QueueMainObjectives(squad);

        return squad;
    }

    /// <summary>
    /// How long SAIN gets to attach its BotComponent and answer the brain lookup before the squad locks
    /// to Average. Counted from the first member's ACTIVATION, not from squad registration — squads
    /// register during the load/warm-up phase, and SAIN only starts attaching once the bot is live in
    /// the world (its own component gates on EBotState.Active). Shoreline's warm-up burned the old 5 s
    /// before any bot was even active and all six PMC squads locked '(none)' → Average on the same tick.
    /// </summary>
    private const float SainResolveTimeoutSeconds = 30f;

    /// <summary>
    /// Strategy-tick callback for PMC squads with deferred personality resolution. Retries the SAIN brain
    /// lookup; once resolved (or the deadline elapses, locking to Average), rolls the PersonalityProfile
    /// and generates the squad's main objectives using the resolved archetype's mix weights. Safe to call
    /// every tick — early-returns if the squad isn't pending. The deadline slides while no member is
    /// active yet, so it only ever measures "SAIN had a live bot for N seconds", never loading time.
    /// </summary>
    public void TryResolvePersonality(Squad squad)
    {
        if (squad == null || !squad.SainResolutionPending) return;

        var brainName = SainPersonality.GetBrainName(squad.Leader.Bot);
        var resolved = !string.IsNullOrEmpty(brainName);
        if (!resolved && !AnyMemberActive(squad))
        {
            squad.SainResolveDeadline = UnityEngine.Time.time + SainResolveTimeoutSeconds;
            return;
        }
        var timedOut = UnityEngine.Time.time >= squad.SainResolveDeadline;
        if (!resolved && !timedOut) return; // still waiting for SAIN

        squad.Archetype = SainPersonality.MapBrainToArchetype(brainName);
        squad.Personality = PersonalityProfile.Roll(squad.Archetype);
        squad.SainResolutionPending = false;
        var reason = resolved ? "SAIN resolved" : "timeout, lock to Average";
        Log.Info($"{squad} PMC personality locked: brain='{brainName ?? "(none)"}' → {squad.Archetype} ({reason}) | extract={squad.Personality.ExtractLootThreshold:N0}₽ coverage={squad.Personality.LootCoverage:P0} mains={squad.Personality.MainCount} sprint={squad.Personality.SprintPropensity:F1}");

        // Now that the archetype is known, generate the main objectives using the locked mix weights.
        waypointSystem.QueueMainObjectives(squad);
    }

    private static bool AnyMemberActive(Squad squad)
    {
        for (var i = 0; i < squad.Size; i++)
        {
            var bot = squad.Members[i]?.Bot;
            if (bot != null && bot.BotState == EBotState.Active) return true;
        }
        return false;
    }

    // Inlined PMC check — full BotTypeUtils helper lands in Phase 5.
    private static bool IsPmcRole(WildSpawnType role)
        => role == WildSpawnType.pmcBEAR || role == WildSpawnType.pmcUSEC;
}
