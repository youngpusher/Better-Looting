using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Orbit.Debugging;

namespace Orbit.Helpers;

// File work runs on one background queue. Records are detached on the caller thread;
// no Unity object, config entry or live diagnostic collection is read by the worker.
internal sealed class DebugArchive
{
    internal sealed class RaidRecord
    {
        public string Id, Map, Version;
        public DateTime StartedUtc;
        public DateTime? EndedUtc;
        public RaidReviewDebug.Context RaidReview;
        public DebugRaidLink Fika;
        public string ContextWarning;
        public string LoggingAtStart, LoggingAtEnd;
        public string[] Diagnostics = Array.Empty<string>();
    }

    private readonly string _root, _folder, _recordPath, _version;
    private readonly List<string> _diagnostics = new();
    private RaidRecord _current;
    private Task _queue = Task.CompletedTask;
    private string _backgroundError;
    private readonly RaidReviewDebug _raidReview;

    internal DebugArchive(string bepinexRoot, string version, HttpClient raidReviewClient = null, Action<string> log = null)
    {
        _root = Path.GetFullPath(bepinexRoot); _version = version;
        _folder = Path.Combine(_root, "ORBIT", "debug");
        _recordPath = Path.Combine(_folder, "last-raid.json");
        _raidReview = new RaidReviewDebug(_folder, raidReviewClient, log);
    }

    internal void BeginRaid(string map, RaidReviewDebug.Context raidReview = null, string logging = null)
    {
        _diagnostics.Clear();
        _current = new RaidRecord { Id = Guid.NewGuid().ToString("N"), Map = map,
            Version = _version, StartedUtc = DateTime.UtcNow, RaidReview = raidReview, LoggingAtStart = logging };
        Checkpoint();
    }

    internal void RegisterDiagnostic(string path)
    {
        if (_current == null) return;
        var name = Path.GetFileName(path);
        if (_diagnostics.Contains(name)) return;
        _diagnostics.Add(name);
        Checkpoint();
    }

    internal RaidRecord Snapshot() => _current == null ? null : new RaidRecord {
        Id = _current.Id, Map = _current.Map, Version = _current.Version,
        StartedUtc = _current.StartedUtc, EndedUtc = _current.EndedUtc,
        RaidReview = _current.RaidReview, Fika = _current.Fika, ContextWarning = _current.ContextWarning,
        LoggingAtStart = _current.LoggingAtStart, LoggingAtEnd = _current.LoggingAtEnd,
        Diagnostics = _diagnostics.ToArray() };

    internal void SetFika(DebugRaidLink link, string warning = null)
    {
        if (_current == null) return;
        _current.Fika = link;
        _current.ContextWarning = warning;
        Checkpoint();
    }

    internal Task<RaidRecord> LoadLastRaid() => Task.Run(() =>
        File.Exists(_recordPath) ? JsonConvert.DeserializeObject<RaidRecord>(File.ReadAllText(_recordPath)) : null);

    private void Checkpoint()
    {
        var record = Snapshot();
        Queue(async () => { await Task.CompletedTask; Persist(record); });
    }

    internal void FinishRaid(Task diagnosticsReady, Func<string> flushLogs, string logging = null)
    {
        if (_current == null || _current.EndedUtc.HasValue) return;
        _current.EndedUtc = DateTime.UtcNow;
        _current.LoggingAtEnd = logging;
        var record = Snapshot();
        Queue(async () => {
            await diagnosticsReady.ConfigureAwait(false);
            flushLogs();
            SaveLog(record);
            Persist(record);
            // Fika replay collection can cross machines and is deferred until an explicit export.
            if (record.Fika == null) await _raidReview.Capture(record).ConfigureAwait(false);
            PruneRaidReview(record);
        });
    }

    // Capture the record before dispatch so a new raid cannot change an in-progress export.
    internal Task<string> Create(Task diagnosticsReady, Func<string> flushLogs, RaidReviewDebug.Context raidReview = null,
        string expectedRaid = null, string logging = null)
    {
        var record = Snapshot();
        var result = new TaskCompletionSource<string>(TaskCreationOptions.RunContinuationsAsynchronously);
        Queue(async () => {
            try
            {
                await diagnosticsReady.ConfigureAwait(false);
                var warnings = new List<string>();
                var flushWarning = flushLogs();
                if (flushWarning != null) warnings.Add(flushWarning);
                if (_backgroundError != null) warnings.Add(_backgroundError);
                var sameSession = record != null;
                if (record == null && File.Exists(_recordPath))
                {
                    try { record = JsonConvert.DeserializeObject<RaidRecord>(File.ReadAllText(_recordPath)); }
                    catch (Exception error) { warnings.Add("Last raid metadata unavailable: " + error.Message); }
                }
                if (record != null && !SafeId(record.Id))
                    throw new InvalidDataException("Invalid last raid identifier.");
                if (record?.ContextWarning != null) warnings.Add(record.ContextWarning);
                if (expectedRaid != null && record?.Id != expectedRaid)
                    throw new InvalidDataException("The requested raid snapshot is no longer available on this host.");
                if (sameSession)
                {
                    try { SaveLog(record); }
                    catch (Exception error) when (error is IOException || error is UnauthorizedAccessException)
                    { warnings.Add("Could not refresh the raid log snapshot: " + error.Message); }
                    Persist(record);
                }
                var rr = await _raidReview.Capture(record, raidReview, includeArchive: true).ConfigureAwait(false);
                if (sameSession)
                {
                    // Include this export's failures in the log as well as report.json.
                    try { flushLogs(); SaveLog(record); }
                    catch (Exception error) { warnings.Add("Could not refresh export log: " + error.Message); }
                }
                result.SetResult(WriteZip(record, warnings, rr, logging));
            }
            catch (Exception error) { result.SetException(error); }
        });
        return result.Task;
    }

    private void Queue(Func<Task> work)
    {
        var previous = _queue;
        _queue = Task.Run(async () => {
            await previous.ConfigureAwait(false);
            try { await work().ConfigureAwait(false); }
            catch (Exception error) { _backgroundError = "Raid debug snapshot failed: " + error.Message; }
        });
    }

    private static bool SafeId(string id) => Guid.TryParseExact(id, "N", out _);
    private string LogPath(RaidRecord record) => Path.Combine(_folder, "last-raid", record.Id + ".log");

    private void Persist(RaidRecord record)
    {
        Directory.CreateDirectory(_folder);
        var temporary = _recordPath + ".tmp";
        File.WriteAllText(temporary, JsonConvert.SerializeObject(record, Formatting.Indented));
        if (File.Exists(_recordPath)) File.Replace(temporary, _recordPath, null);
        else File.Move(temporary, _recordPath);
    }

    private void SaveLog(RaidRecord record)
    {
        var source = Path.Combine(_root, "LogOutput.log");
        if (!File.Exists(source)) return;
        var destination = LogPath(record);
        Directory.CreateDirectory(Path.GetDirectoryName(destination));
        var temporary = destination + ".tmp";
        using (var input = OpenShared(source))
        using (var output = File.Create(temporary)) CopySnapshot(input, output);
        if (File.Exists(destination)) File.Replace(temporary, destination, null);
        else File.Move(temporary, destination);
        // Retain one session log, not an ever-growing duplicate of every raid.
        foreach (var old in Directory.GetFiles(Path.GetDirectoryName(destination), "*.log"))
            if (!string.Equals(old, destination, StringComparison.OrdinalIgnoreCase)) File.Delete(old);
    }

    private void PruneRaidReview(RaidRecord record)
    {
        var folder = Path.Combine(_folder, "last-raid");
        if (!Directory.Exists(folder)) return;
        foreach (var old in Directory.GetDirectories(folder, "*-rr"))
        {
            var name = Path.GetFileName(old);
            if (name.Length == 35 && SafeId(name.Substring(0, 32)) && name != record.Id + "-rr")
                Directory.Delete(old, true);
        }
    }

    private string WriteZip(RaidRecord record, List<string> warnings, RaidReviewDebug.Snapshot raidReview, string logging)
    {
        Directory.CreateDirectory(_folder);
        var path = Path.Combine(_folder, "ORBIT-debug-" + DateTime.UtcNow.ToString("yyyyMMdd-HHmmss-fff")
            + "-" + Guid.NewGuid().ToString("N").Substring(0, 8) + ".zip");
        var temporary = path + ".tmp";
        try
        {
            using (var file = File.Create(temporary))
            using (var zip = new ZipArchive(file, ZipArchiveMode.Create))
            {
                var log = record == null ? Path.Combine(_root, "LogOutput.log") : LogPath(record);
                var logIncluded = AddFile(zip, log, "BepInEx/LogOutput.log", warnings);
                if (record == null) warnings.Add("No recorded raid metadata. Only the current BepInEx session log is available.");
                if (record != null && !logIncluded)
                {
                    warnings.Add("The last raid log was not preserved (for example, the client stopped before raid teardown).");
                    AddFile(zip, Path.Combine(_root, "LogOutput.log"), "BepInEx/current-session-LogOutput.log", warnings);
                }
                var count = 0;
                var included = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                foreach (var name in record?.Diagnostics ?? Array.Empty<string>())
                {
                    if (name == null || name != Path.GetFileName(name) || name.Contains("\\") || name.Contains("/")
                        || !((name.StartsWith("performance-", StringComparison.Ordinal) && name.EndsWith(".jsonl", StringComparison.Ordinal))
                            || (name.StartsWith("capture-", StringComparison.Ordinal) && name.EndsWith(".json", StringComparison.Ordinal))))
                    { warnings.Add("Ignored invalid diagnostic filename."); continue; }
                    if (included.Add(name) && AddFile(zip, Path.Combine(_root, "ORBIT", "diagnostics", name),
                        "ORBIT/diagnostics/" + name, warnings)) count++;
                }
                if (count == 0) warnings.Add("No performance diagnostics for this raid. Performance logging may have been disabled.");
                var rrFiles = new List<string>();
                foreach (var name in raidReview.Files)
                    if (record != null && RaidReviewDebug.IsExportFile(name)
                        && AddFile(zip, _raidReview.FilePath(record.Id, name), "RaidReview/" + name, warnings)) rrFiles.Add(name);
                if (rrFiles.Count != raidReview.Files.Length) raidReview.Status = "Partial";
                if (raidReview.Files.Contains(RaidReviewDebug.ArchiveName) && !rrFiles.Contains(RaidReviewDebug.ArchiveName))
                    raidReview.Archive = "Missing";
                raidReview.Files = rrFiles.ToArray();
                WriteText(zip, "report.json", JsonConvert.SerializeObject(new {
                    CreatedUtc = DateTime.UtcNow, ExporterVersion = _version, Raid = record,
                    DiagnosticFiles = count, RaidReview = raidReview, Warnings = warnings, ExportLogging = logging,
                    LogScope = "BepInEx session log, including startup and any earlier raids in that session. Diagnostics belong only to the selected raid."
                }, Formatting.Indented));
                WriteText(zip, "README.txt", "ORBIT debug report\nAttach this ZIP to your bug report and describe what happened.\n"
                    + "The BepInEx log contains messages from installed mods and may include player names and local paths.\n"
                    + "RaidReview/ contains JSON replay data for this raid when available: players, positions, inventories, loot, combat and objectives.\n"
                    + "When RR supports raid sharing and the raid is finished, RaidReview/raid-export.zip can be extracted and opened with RR's Import raid button.\n"
                    + "RaidReview.Archive reports whether that optional ZIP was included, cached, unsupported or unavailable. The outer ORBIT debug ZIP is not an RR import file.\n"
                    + "RR is read through its configured server. Cached end-of-raid data can be used if that server is offline.\n"
                    + "report.json identifies the selected raid, lists missing files and records RR transfer attempts (phase, bytes, elapsed time and error).\n"
                    + "RaidReview.Positions states Included, Cached or Missing. Cached data may omit the end of a raid.\n"
                    + "Raid.LoggingAtStart/LoggingAtEnd and ExportLogging distinguish the recording and export settings; older recordings may have no saved settings.\n"
                    + "For Fika, clicking Create debug ZIP can request this raid's host files through your SPT server.\n"
                    + "Host/ contains the host/headless snapshot when available; HostDebug in report.json describes the transfer.\n");
            }
            File.Move(temporary, path);
            return path;
        }
        catch { if (File.Exists(temporary)) File.Delete(temporary); throw; }
    }

    private static FileStream OpenShared(string path)
        => new(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
    private static void CopySnapshot(FileStream input, Stream output)
    {
        var remaining = input.Length;
        var buffer = new byte[81920];
        while (remaining > 0)
        {
            var read = input.Read(buffer, 0, (int)Math.Min(remaining, buffer.Length));
            if (read == 0) break;
            output.Write(buffer, 0, read); remaining -= read;
        }
    }
    private static bool AddFile(ZipArchive zip, string path, string name, List<string> warnings)
    {
        try
        {
            using var input = OpenShared(path);
            using var output = zip.CreateEntry(name, name.EndsWith(".zip", StringComparison.Ordinal)
                ? CompressionLevel.NoCompression : CompressionLevel.Fastest).Open();
            CopySnapshot(input, output);
            return true;
        }
        catch (Exception error) when (error is IOException || error is UnauthorizedAccessException)
        { warnings.Add("Could not fully include " + name + ": " + error.Message); return false; }
    }
    private static void WriteText(ZipArchive zip, string name, string text)
    { using var writer = new StreamWriter(zip.CreateEntry(name).Open()); writer.Write(text); }
}
