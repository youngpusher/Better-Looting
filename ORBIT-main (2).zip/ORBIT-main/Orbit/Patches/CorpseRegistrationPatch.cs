using System;
using System.Collections.Generic;
using System.Reflection;
using Comfort.Common;
using EFT;
using EFT.Interactive;
using HarmonyLib;
using Orbit.Core;
using Orbit.Helpers;
using Orbit.Navigation;
using SPT.Reflection.Patching;

namespace Orbit.Patches;

/// <summary>
/// When any Player (human / PMC bot / scav bot) dies, BSG instantiates a Corpse GameObject via
/// Player.CreateCorpse(). We register the fresh corpse as a runtime Corpse waypoint so other bots can be
/// dispatched to loot it. When the kill is attributable to an ORBIT-managed agent, we also tag the corpse as
/// "owned" by that agent's squad and force an immediate re-dispatch of the killer onto the body.
/// </summary>
public class CorpseRegistrationPatch : ModulePatch
{
    protected override MethodBase GetTargetMethod()
    {
        // Parameterless overload — Player.CreateCorpse() — which delegates to the generic
        // CreateCorpse<T>(Vector3 velocity). Capturing the result here is simpler than patching the generic.
        return typeof(Player).GetMethod(nameof(Player.CreateCorpse), Type.EmptyTypes);
    }

    [PatchPostfix]
    public static void Postfix(Player __instance, Corpse __result)
    {
        using var timing = GhostDeathDiagnostics.Measure(TransitionPhase.GhostCorpseRegistration);
        if (__result == null)
        {
            RememberBossKillWithoutBody(Singleton<OrbitManager>.Instance, __instance);
            Log.Debug($"CorpseRegistration: NULL __result for {__instance?.Profile?.Info?.Nickname ?? "?"} — no waypoint created");
            return;
        }

        var manager = Singleton<OrbitManager>.Instance;
        if (manager?.WaypointSystem == null)
        {
            Log.Debug($"CorpseRegistration: OrbitManager / WaypointSystem null for {__instance?.Profile?.Info?.Nickname ?? "?"} — no waypoint created");
            return;
        }

        try
        {
            var pos = __result.transform.position;

            // A corpse inside a minefield / border zone must not become a loot waypoint — it would lure
            // looters (ghosts included) straight into the mines. The loot is simply lost.
            if (Orbit.Navigation.DangerZones.IsInside(pos))
            {
                RememberBossKillWithoutBody(manager, __instance);
                Log.Info($"CorpseRegistration: {__result.name} died inside a border zone — no loot waypoint");
                return;
            }

            var loc = new Waypoint(
                manager.WaypointSystem.NewRuntimeWaypointId(),
                WaypointCategory.Corpse,
                __result.name,
                pos,
                radiusSqr: 3f * 3f, // tight enough to require same-room, loose enough to absorb BSG's 2-3m stopping inertia
                doors: new List<Door>(),
                coverPoints: new List<CoverPoint>(),
                target: __result
            );

            manager.WaypointSystem.AddRuntimeWaypoint(loc);
            var victimRole = __instance?.Profile?.Info?.Settings?.Role.ToString();
            manager.WaypointSystem.RegisterRushCorpse(loc, victimRole);
            var victimName = __instance?.Profile?.Info?.Nickname ?? "?";
            var victimProfileId = __instance?.Profile?.Id;
            Log.Debug($"CorpseRegistration: registered Corpse waypoint {loc} for victim {victimName} at ({pos.x:F2},{pos.y:F2},{pos.z:F2})");

            // Dead-member-loot recovery: if any active squad armed PendingDeadMemberRecoveryProfileId for
            // this victim (LootContainerAction.ReevaluateExtractOnDeath fired when the squad cancelled a
            // loot-threshold extract after losing this member), pin the squad's objective to the corpse
            // immediately. Survivors bee-line to recover the loot instead of returning to roam / mains.
            if (!string.IsNullOrEmpty(victimProfileId))
            {
                var squads = manager.SquadData.Entities.Values;
                for (var s = 0; s < squads.Count; s++)
                {
                    var squad = squads[s];
                    if (squad?.PendingDeadMemberRecoveryProfileId != victimProfileId) continue;
                    var recoveryValue = squad.PendingDeadMemberRecoveryValue;
                    squad.PendingDeadMemberRecoveryProfileId = null;
                    squad.PendingDeadMemberRecoveryValue = 0f;
                    squad.Objective.Location = loc;
                    squad.Objective.LocationPrevious = null;
                    squad.Objective.Duration = 0; // force re-dispatch onto the corpse next tick
                    squad.Objective.StartTime = UnityEngine.Time.time;
                    Log.Info($"{squad}: bee-lining to dead-member corpse {loc} for {victimName} ({recoveryValue:N0}₽ loot recovery)");
                }
            }

            // Attribute the kill to an ORBIT squad if possible. The victim's LastAggressor is set by BSG's
            // damage pipeline just before CreateCorpse fires, so by the time this postfix runs it points at
            // whoever landed the killing blow. The field is internal — Traverse keeps us from hand-rolling
            // the reflection.
            var aggressor = Traverse.Create(__instance).Field("LastAggressor").GetValue<IPlayer>();
            if (aggressor == null)
            {
                Log.Debug($"CorpseRegistration: {loc} has no LastAggressor on victim {victimName} — registered but no killer squad credited");
                return;
            }
            var aggressorProfileId = aggressor.ProfileId;
            if (string.IsNullOrEmpty(aggressorProfileId))
            {
                Log.Debug($"CorpseRegistration: {loc} aggressor has empty ProfileId — registered but no killer squad credited");
                return;
            }
            var agents = manager.AgentData.Entities.Values;
            for (var i = 0; i < agents.Count; i++)
            {
                var a = agents[i];
                if (a?.Player == null) continue;
                if (a.Player.ProfileId != aggressorProfileId) continue;
                if (a.Squad == null)
                {
                    Log.Debug($"CorpseRegistration: {a} matched aggressor for {loc} but has no Squad — registered but no squad credited");
                    return;
                }
                manager.WaypointSystem.TagCorpseKillerSquad(loc.Id, a.Squad.Id);
                manager.WaypointSystem.RememberRushBossKill(a.Squad, loc, victimRole);
                // Goons / bosses / raiders / cultists / bloodhounds run on either vanilla BSG brain or
                // ORBIT's basic roam-with-no-mains pipeline — they don't have a loot layer that knows what
                // to do with the corpse. Forcing the own-kill bee-line on them just pins the squad on a body
                // they'll never loot AND dispatches followers (Big Pipe / Birdeye) onto splinter loot POIs
                // around the corpse, which then loops on arrival-check failures. Skip the routing entirely
                // for non-PMC / non-PlayerScav squads — they keep the corpse-killer credit tag (so loot
                // dispatch from OTHER squads still respects it) but don't get the bee-line themselves.
                var role = a.Bot?.Profile?.Info?.Settings?.Role;
                var isPmc = role.HasValue && role.Value.IsPMC();
                var isPlayerScav = a.Bot?.Profile != null && a.Bot.Profile.WillBeAPlayerScav();
                var isBotScav = role.HasValue && role.Value.IsScav() && !isPlayerScav;
                if (!isPmc && !isPlayerScav && !isBotScav)
                {
                    Log.Info($"CorpseRegistration: {a} ({a.Squad}) credited with {loc} but role={role} is not PMC / PlayerScav / scav — skipping own-kill bee-line (Goons / bosses / cultists don't have a loot layer to consume the dispatch)");
                    return;
                }
                // Keep every kill in arrival order. The per-agent dispatch loop can resume these
                // after combat or an extraction detour without expiring the squad's current objective.
                if (!a.OwnKillCorpseIds.Contains(loc.Id)) a.OwnKillCorpseIds.Add(loc.Id);
                Log.Info($"CorpseRegistration: {a} ({a.Squad}) credited with {loc}, queued own-kill loot (pending={a.OwnKillCorpseIds.Count})");
                return;
            }
            Log.Debug($"CorpseRegistration: aggressor profileId={aggressorProfileId.Substring(0, 8)}… is not ORBIT-managed for {loc} — registered but no squad credited");
        }
        catch (Exception ex)
        {
            Log.Error($"CorpseRegistration failed for {__instance?.Profile?.Info?.Nickname}: {ex}");
        }
    }

    private static void RememberBossKillWithoutBody(OrbitManager manager, Player victim)
    {
        if (manager?.WaypointSystem == null || victim == null) return;
        try
        {
            var aggressor = Traverse.Create(victim).Field("LastAggressor").GetValue<IPlayer>();
            if (string.IsNullOrEmpty(aggressor?.ProfileId)) return;
            var agents = manager.AgentData.Entities.Values;
            for (var i = 0; i < agents.Count; i++)
                if (agents[i]?.Squad != null && agents[i].Player?.ProfileId == aggressor.ProfileId)
                {
                    // A missing or dangerous body cannot be looted, but it must not
                    // erase a boss kill the squad already witnessed through damage.
                    manager.WaypointSystem.RememberRushBossKill(agents[i].Squad, null,
                        victim.Profile?.Info?.Settings?.Role.ToString());
                    break;
                }
        }
        catch (Exception error) { Log.Warning($"Boss Rush kill attribution without corpse failed: {error}"); }
    }
}
