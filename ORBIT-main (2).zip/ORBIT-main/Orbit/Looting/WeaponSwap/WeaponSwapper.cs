using Diz.LanguageExtensions;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Comfort.Common;
using EFT;
using EFT.InventoryLogic;
using Orbit.Core;
using Orbit.Helpers;

namespace Orbit.Looting.WeaponSwap;

/// <summary>
/// Decides whether a Weapon being looted from a corpse / container / loose item should be equipped into one
/// of the bot's three weapon slots (FirstPrimary / SecondPrimary / Holster), displacing a worse weapon if
/// needed. Scavs are restricted to equipping into empty slots (no swap). PMCs and PlayerScavs use the full
/// score-and-displace path.
/// </summary>
public static class WeaponSwapper
{
    public enum Outcome
    {
        /// <summary>Caller should fall back to its default loot path.</summary>
        NotApplicable,
        /// <summary>Candidate moved into a weapon slot; caller must skip default placement.</summary>
        Swapped,
        /// <summary>Candidate explicitly rejected; caller must skip default placement (no stash).</summary>
        Skipped,
    }

    public readonly struct WouldSwapResult
    {
        public readonly bool WouldSwap;
        public readonly float CandidateScore;
        /// <summary>
        /// Weapon currently in the bot's loadout that would be thrown to the corpse by the swap (primary2 in
        /// full-rotate / primary2 swap, holster current in holster swap). Null when no weapon is displaced
        /// (promote into empty slot2, equip into empty slot, scav path). Callers can strip its mods before
        /// firing the swap so valuable attachments land in the bot's bag instead of being lost with the
        /// frame.
        /// </summary>
        public readonly Weapon DisplacedWeapon;
        public WouldSwapResult(bool would, float score, Weapon displaced = null) { WouldSwap = would; CandidateScore = score; DisplacedWeapon = displaced; }
        public static WouldSwapResult No => new(false, 0f, null);
    }

    /// <summary>
    /// Synchronous pre-check: would <paramref name="candidate"/> trigger a swap if fed to <see
    /// cref="TryHandleAsync"/>, or would it be rejected by margin / fit / no-downgrade rules? Lets callers
    /// strip mods off rejected weapons before the swap fires. Returns the candidate's score so callers can
    /// rank multiple would-swap weapons against each other.
    /// </summary>
    public static WouldSwapResult WouldSwap(BotOwner bot, Weapon candidate, Item rootSource)
    {
        // "Bots keep their spawn weapons": no looted weapon is ever a swap candidate. Rejected weapons still
        // go through the strip/bag path, and the post-swap loadout collapses to the current one so mags/ammo
        // for the bot's OWN weapons keep bypassing the value gate.
        if (ServerConfig.Loot.KeepSpawnWeapons) return WouldSwapResult.No;
        if (bot == null || candidate == null) return WouldSwapResult.No;
        var player = bot.GetPlayer;
        if (player?.InventoryController == null) return WouldSwapResult.No;
        var profile = bot.Profile;
        if (profile == null) return WouldSwapResult.No;
        var equipment = player.Inventory?.Equipment;
        if (equipment == null) return WouldSwapResult.No;

        var primary1Slot = equipment.GetSlot(EquipmentSlot.FirstPrimaryWeapon);
        var primary2Slot = equipment.GetSlot(EquipmentSlot.SecondPrimaryWeapon);
        var holsterSlot = equipment.GetSlot(EquipmentSlot.Holster);

        var candidateFitsHolster = holsterSlot != null && holsterSlot.CheckCompatibility(candidate);
        var candidateFitsPrimary = (primary1Slot != null && primary1Slot.CheckCompatibility(candidate))
                                || (primary2Slot != null && primary2Slot.CheckCompatibility(candidate));
        if (!candidateFitsPrimary && !candidateFitsHolster) return WouldSwapResult.No;

        var mapId = Singleton<OrbitManager>.Instance?.MapId;
        var weights = MapWeaponWeights.Resolve(mapId);
        var sourceItems = new List<Item>(WeaponScorer.Walk(rootSource));
        // Candidate ammo pool = bot inventory + corpse loot — post-swap the bot keeps their own rounds AND
        // inherits the corpse's via phase 1 drain. Without this union the candidate is scored against the
        // corpse's tiny carry (typically 1 mag worth) while the bot's current weapons are scored against the
        // full inventory (1000+ rounds when ammo boxes are involved), producing a structural ~+18
        // count_score bias against ANY candidate regardless of actual weapon quality. See WeaponScorer for
        // the formula.
        var inventoryItems = CollectBotInventoryAmmoPool(bot);
        var candidatePool = CombineAmmoPools(inventoryItems, sourceItems);
        var candidateScore = WeaponScorer.Score(candidate, candidatePool, weights);

        var isBotScav = profile.Side == EPlayerSide.Savage && !profile.WillBeAPlayerScav();
        if (isBotScav)
        {
            // Scavs only equip into empty slots. Iterate primary1 → primary2 → holster, return true on first
            // empty fitting slot.
            foreach (var sk in WeaponSlotsPrimaryFirst)
            {
                var s = equipment.GetSlot(sk);
                if (s == null || s.ContainedItem != null) continue;
                if (s.CheckCompatibility(candidate)) return new WouldSwapResult(true, candidateScore);
            }
            return WouldSwapResult.No;
        }

        const float margin = LootConfig.SwapMargin;

        var candidateAmmo = WeaponScorer.CollectUsableAmmo(candidate, candidatePool);
        if (candidateAmmo.BestPenetration < 20 && BotHasGoodPenWeapon(bot, inventoryItems))
            return WouldSwapResult.No;

        if (!candidateFitsPrimary && candidateFitsHolster)
        {
            var current = holsterSlot.ContainedItem as Weapon;
            if (current == null) return new WouldSwapResult(true, candidateScore);
            var currentScore = WeaponScorer.Score(current, inventoryItems, weights);
            var wouldSwap = candidateScore > currentScore * margin;
            return new WouldSwapResult(wouldSwap, candidateScore, wouldSwap ? current : null);
        }

        var current1 = primary1Slot?.ContainedItem as Weapon;
        var current2 = primary2Slot?.ContainedItem as Weapon;
        if (current1 == null) return new WouldSwapResult(true, candidateScore); // primary1 empty → equip, no displacement
        var score1 = WeaponScorer.Score(current1, inventoryItems, weights);
        if (current2 == null)
        {
            // Promote OR fill slot2 — slot2 was empty, so nothing displaced either way.
            return new WouldSwapResult(true, candidateScore);
        }
        var score2 = WeaponScorer.Score(current2, inventoryItems, weights);
        if (candidateScore > score1 * margin)
        {
            // Full rotate: swap1 throws current2 to the corpse, swap2 demotes current1 to slot2.
            return new WouldSwapResult(true, candidateScore, current2);
        }
        if (candidateScore > score2 * margin)
        {
            // Single swap into slot2: current2 goes to the corpse.
            return new WouldSwapResult(true, candidateScore, current2);
        }
        return new WouldSwapResult(false, candidateScore);
    }

    public static async Task<Outcome> TryHandleAsync(BotOwner bot, Weapon candidate, Item rootSource, CancellationToken ct, bool dormant = false)
    {
        LootActorGuard.RequireCurrent(bot, ct);
        if (ServerConfig.Loot.KeepSpawnWeapons) return Outcome.NotApplicable;
        if (bot == null || candidate == null) return Outcome.NotApplicable;
        var player = bot.GetPlayer;
        if (player?.InventoryController == null) return Outcome.NotApplicable;
        var profile = bot.Profile;
        if (profile == null) return Outcome.NotApplicable;

        var nick = profile.Nickname ?? "(no-nick)";
        var isBotScav = profile.Side == EPlayerSide.Savage && !profile.WillBeAPlayerScav();

        var outcome = isBotScav
            ? await TryEquipIntoFirstEmptySlotAsync(bot, candidate, nick, ct)
            : await EvaluateAndPerformAsync(bot, candidate, rootSource, nick, ct, dormant);
        LootActorGuard.RequireCurrent(bot, ct);
        if (outcome == Outcome.Swapped)
        {
            if (dormant) RegisterDormantEquip(bot, candidate, nick);
            else await FinalizeWeaponSwapAsync(bot, nick, ct);
        }
        return outcome;
    }

    // ── Ghost gear swaps ────────────────────────────────────────────────────────────────────────────
    // The policy above is already hands-safe in its first half: a candidate always lands in an EMPTY slot or
    // takes primary2's place, and only then is promoted by swapping slot1 and slot2. That promotion, and the
    // final redraw, are the only steps that move the weapon in hands, which needs a live body. A sleeper
    // therefore runs the first half as is and leaves two notes on its agent: redraw at wake, promote at the
    // next awake loot session (a calm moment, never the second a sleeper is woken by a fight).

    public static bool IsInHands(BotOwner bot, Item item)
    {
        try { return item != null && ReferenceEquals(bot?.GetPlayer?.HandsController?.Item, item); }
        catch { return false; }
    }

    private static void RegisterDormantEquip(BotOwner bot, Weapon candidate, string nick)
    {
        var agent = Singleton<BotRoster>.Instance?.GetAgent(bot);
        if (agent == null) return;
        agent.GhostHandsResync = true;
        // First primary was empty: the candidate IS the main weapon from now on.
        var primary1 = bot.GetPlayer?.Inventory?.Equipment?.GetSlot(EquipmentSlot.FirstPrimaryWeapon)?.ContainedItem;
        if (ReferenceEquals(primary1, candidate)) agent.GhostBestWeapon = candidate;
        Log.Info($"WeaponSwap({nick}): ghost equipped {candidate.LocalizedName()} without drawing it, hands resync queued for the wake");
    }

    private static void RegisterPendingPromotion(BotOwner bot, Weapon candidate, string nick)
    {
        var agent = Singleton<BotRoster>.Instance?.GetAgent(bot);
        if (agent == null) return;
        agent.GhostPendingPromotion = candidate;
        agent.GhostBestWeapon = candidate;
        Log.Info($"WeaponSwap({nick}): ghost parked {candidate.LocalizedName()} in primary2, promotion to primary1 deferred to its next awake loot session");
    }

    /// <summary>Wake resync: the weapon list changed while the body was inactive. Same refresh as the end of
    /// an awake swap, so BSG and SAIN see the new loadout and the main weapon is drawn.</summary>
    public static bool ResyncHandsAfterWake(BotOwner bot, string who)
    {
        try
        {
            var selector = bot?.WeaponManager?.Selector;
            if (selector == null) return false;
            selector.UpdateWeaponsList();
            if (!selector.ChangeToMain()) return false;
            try { bot.AIData?.CalcPower(); } catch { }
            Log.Debug($"GHOST HANDS: {who} main weapon redraw requested");
            return true;
        }
        catch (System.Exception e)
        {
            Log.Warning($"{who} hands resync after wake threw: {e.Message}");
            return false;
        }
    }

    /// <summary>Second half of a swap a sleeper could not finish: promote the parked weapon to primary1.
    /// Called from an awake loot session. The note is cleared whatever happens, the weapon stays a valid
    /// secondary if the swap is refused.</summary>
    public static async Task PromotePendingAsync(BotOwner bot, CancellationToken ct)
    {
        LootActorGuard.RequireCurrent(bot, ct);
        var agent = Singleton<BotRoster>.Instance?.GetAgent(bot);
        var candidate = agent?.GhostPendingPromotion;
        if (candidate == null || agent.IsDormant) return;
        agent.GhostPendingPromotion = null;
        agent.GhostBestWeapon = null;
        var nick = bot.Profile?.Nickname ?? "(no-nick)";
        try
        {
            var equipment = bot.GetPlayer?.Inventory?.Equipment;
            var current1 = equipment?.GetSlot(EquipmentSlot.FirstPrimaryWeapon)?.ContainedItem as Weapon;
            var current2 = equipment?.GetSlot(EquipmentSlot.SecondPrimaryWeapon)?.ContainedItem as Weapon;
            if (current1 == null || !ReferenceEquals(current2, candidate))
            {
                Log.Debug($"WeaponSwap({nick}): pending promotion dropped, {candidate.LocalizedName()} is no longer parked in primary2");
                return;
            }
            Log.Info($"WeaponSwap({nick}): promoting {candidate.LocalizedName()} to primary1 (parked there while asleep), demoting {current1.LocalizedName()}");
            if (await SwapInPlaceAsync(bot, candidate, current1, nick, ct))
                await FinalizeWeaponSwapAsync(bot, nick, ct);
        }
        catch (System.OperationCanceledException) { throw; }
        catch (System.Exception e)
        {
            Log.Warning($"WeaponSwap({nick}): pending promotion threw: {e.Message}");
        }
    }

    private static readonly EquipmentSlot[] WeaponSlotsPrimaryFirst =
    {
        EquipmentSlot.FirstPrimaryWeapon,
        EquipmentSlot.SecondPrimaryWeapon,
        EquipmentSlot.Holster,
    };

    /// <summary>
    /// Equip-only entry point: move <paramref name="candidate"/> into the first empty fitting weapon slot,
    /// never displace an already-equipped weapon. Used for container / loose-loot pickups where displacement
    /// is not appropriate — only corpse loot fires the full swap path.
    /// </summary>
    public static async Task<Outcome> TryEquipOnlyAsync(BotOwner bot, Weapon candidate, CancellationToken ct, bool dormant = false)
    {
        LootActorGuard.RequireCurrent(bot, ct);
        if (ServerConfig.Loot.KeepSpawnWeapons) return Outcome.NotApplicable;
        if (bot == null || candidate == null) return Outcome.NotApplicable;
        var nick = bot.Profile?.Nickname ?? "(no-nick)";
        var outcome = await TryEquipIntoFirstEmptySlotAsync(bot, candidate, nick, ct);
        LootActorGuard.RequireCurrent(bot, ct);
        if (outcome == Outcome.Swapped)
        {
            if (dormant) RegisterDormantEquip(bot, candidate, nick);
            else await FinalizeWeaponSwapAsync(bot, nick, ct);
        }
        return outcome;
    }

    private static async Task<Outcome> TryEquipIntoFirstEmptySlotAsync(BotOwner bot, Weapon candidate, string nick, CancellationToken ct)
    {
        LootActorGuard.RequireCurrent(bot, ct);
        var equipment = bot.GetPlayer.Inventory.Equipment;
        foreach (var slotKind in WeaponSlotsPrimaryFirst)
        {
            var slot = equipment.GetSlot(slotKind);
            if (slot == null || slot.ContainedItem != null) continue;
            if (!slot.CheckCompatibility(candidate)) continue;
            Log.Info($"WeaponSwap.Scav({nick}): equip {candidate.LocalizedName()} → {slotKind}");
            var moved = await MoveIntoSlotAsync(bot, candidate, slot, nick, ct);
            LootActorGuard.RequireCurrent(bot, ct);
            return moved ? Outcome.Swapped : Outcome.Skipped;
        }
        return Outcome.Skipped;
    }


    private static async Task<Outcome> EvaluateAndPerformAsync(BotOwner bot, Weapon candidate, Item rootSource, string nick, CancellationToken ct, bool dormant = false)
    {
        LootActorGuard.RequireCurrent(bot, ct);
        var equipment = bot.GetPlayer.Inventory.Equipment;
        var primary1Slot = equipment.GetSlot(EquipmentSlot.FirstPrimaryWeapon);
        var primary2Slot = equipment.GetSlot(EquipmentSlot.SecondPrimaryWeapon);
        var holsterSlot = equipment.GetSlot(EquipmentSlot.Holster);

        var mapId = Singleton<OrbitManager>.Instance?.MapId;
        var weights = MapWeaponWeights.Resolve(mapId);
        const float margin = LootConfig.SwapMargin;
        Log.Debug($"WeaponSwap({nick}): map={mapId ?? "?"} weights=ergo×{weights.Ergo:F2} recoil×{weights.Recoil:F2} dist×{weights.EffectiveDist:F2} ammoQ×{weights.AmmoQuality:F2}, margin={margin:F2}");

        var candidateFitsHolster = holsterSlot != null && holsterSlot.CheckCompatibility(candidate);
        var candidateFitsPrimary = (primary1Slot != null && primary1Slot.CheckCompatibility(candidate))
                                || (primary2Slot != null && primary2Slot.CheckCompatibility(candidate));

        if (!candidateFitsPrimary && !candidateFitsHolster)
            return Outcome.Skipped;

        var inventoryItems = CollectBotInventoryAmmoPool(bot);
        var sourceItems = new List<Item>(WeaponScorer.Walk(rootSource));
        var candidatePool = CombineAmmoPools(inventoryItems, sourceItems);
        var candidateScore = WeaponScorer.Score(candidate, candidatePool, weights, $"{nick}:CAND");

        // No-downgrade guard: if the candidate's ammo is sub-threshold and the bot already has a high-pen
        // weapon equipped, refuse the swap outright. Prevents cascade chains where SMGs / shotguns keep
        // displacing the bot's good rifle one slot at a time.
        var candidateAmmo = WeaponScorer.CollectUsableAmmo(candidate, candidatePool);
        if (candidateAmmo.BestPenetration < 20 && BotHasGoodPenWeapon(bot, inventoryItems))
        {
            Log.Info($"WeaponSwap({nick}): no-downgrade guard — candidate {candidate.LocalizedName()} (pen={candidateAmmo.BestPenetration}) rejected, bot already has a pen≥20 weapon");
            return Outcome.Skipped;
        }

        return !candidateFitsPrimary && candidateFitsHolster
            ? await HandleHolsterCandidateAsync(bot, candidate, holsterSlot, inventoryItems, weights, margin, candidateScore, rootSource, nick, ct, dormant)
            : await HandlePrimaryCandidateAsync(bot, candidate, primary1Slot, primary2Slot, inventoryItems, weights, margin, candidateScore, rootSource, nick, ct, dormant);
    }

    private static async Task<Outcome> HandleHolsterCandidateAsync(
        BotOwner bot, Weapon candidate, Slot holsterSlot,
        List<Item> inventoryItems, WeaponWeights weights, float margin,
        float candidateScore, Item rootSource, string nick, CancellationToken ct, bool dormant = false)
    {
        LootActorGuard.RequireCurrent(bot, ct);
        var current = holsterSlot.ContainedItem as Weapon;
        if (dormant && current != null && IsInHands(bot, current))
        {
            Log.Debug($"WeaponSwap({nick}): ghost keeps its holster weapon, it is the one in hands and a sleeper's hands cannot be touched");
            return Outcome.Skipped;
        }
        if (current == null)
        {
            Log.Info($"WeaponSwap({nick}): holster empty — equip {candidate.LocalizedName()} (score {candidateScore:F1})");
            var moved = await MoveIntoSlotAsync(bot, candidate, holsterSlot, nick, ct);
            LootActorGuard.RequireCurrent(bot, ct);
            return moved ? Outcome.Swapped : Outcome.Skipped;
        }
        var currentScore = WeaponScorer.Score(current, inventoryItems, weights, $"{nick}:HOLSTER");
        if (candidateScore > currentScore * margin)
        {
            // Atomic positional swap: candidate moves to the holster, the previous holster weapon takes the
            // candidate's source address.
            Log.Info($"WeaponSwap({nick}): holster SWAP {current.LocalizedName()}({currentScore:F1}) → {candidate.LocalizedName()}({candidateScore:F1}, margin {margin:F2})");
            // Phase 5 — strip valuable mods off the holster weapon before it leaves. Post-swap loadout will
            // be the bot's primaries (unchanged) + candidate in holster.
            await StripValuableModsBeforeDiscardAsync(bot, current, GatherPostSwapWeapons(bot, candidate, EquipmentSlot.Holster), nick, ct);
            LootActorGuard.RequireCurrent(bot, ct);
            var ok = await SwapInPlaceAsync(bot, candidate, current, nick, ct);
            LootActorGuard.RequireCurrent(bot, ct);
            return ok ? Outcome.Swapped : Outcome.Skipped;
        }
        Log.Debug($"WeaponSwap({nick}): holster keep {current.LocalizedName()}({currentScore:F1}) — candidate {candidate.LocalizedName()}({candidateScore:F1}) below margin {margin:F2}");
        return Outcome.Skipped;
    }

    private static async Task<Outcome> HandlePrimaryCandidateAsync(
        BotOwner bot, Weapon candidate, Slot primary1Slot, Slot primary2Slot,
        List<Item> inventoryItems, WeaponWeights weights, float margin,
        float candidateScore, Item rootSource, string nick, CancellationToken ct, bool dormant = false)
    {
        LootActorGuard.RequireCurrent(bot, ct);
        var current1 = primary1Slot?.ContainedItem as Weapon;
        var current2 = primary2Slot?.ContainedItem as Weapon;
        // Ghost: every branch below only ever displaces primary2 (primary1 is promoted through a slot swap), so
        // the single hands-affecting case to refuse is a sleeper holding its SECOND primary.
        if (dormant && current2 != null && IsInHands(bot, current2))
        {
            Log.Debug($"WeaponSwap({nick}): ghost holds its second primary in hands, no swap while asleep");
            return Outcome.Skipped;
        }

        // Primary1 empty: direct equip.
        if (current1 == null)
        {
            Log.Info($"WeaponSwap({nick}): primary1 empty — equip {candidate.LocalizedName()} (score {candidateScore:F1})");
            var moved = await MoveIntoSlotAsync(bot, candidate, primary1Slot, nick, ct);
            LootActorGuard.RequireCurrent(bot, ct);
            return moved ? Outcome.Swapped : Outcome.Skipped;
        }

        var score1 = WeaponScorer.Score(current1, inventoryItems, weights, $"{nick}:PRI1");

        // Primary2 empty: promote candidate into primary1 if it beats the current primary1 by the margin,
        // otherwise equip it as secondary. The promote path always equips into primary2 first then
        // atomic-swaps slot1↔slot2: primary1 never goes transiently empty, which the bot's hands controller
        // does not tolerate.
        if (current2 == null)
        {
            if (candidateScore > score1 * margin)
            {
                Log.Info($"WeaponSwap({nick}): promote candidate {candidate.LocalizedName()}({candidateScore:F1}) → primary1 (via temp slot2 + atomic swap, demote {current1.LocalizedName()}({score1:F1}))");
                if (!await MoveIntoSlotAsync(bot, candidate, primary2Slot, nick, ct)) return Outcome.Skipped;
                if (dormant)
                {
                    RegisterPendingPromotion(bot, candidate, nick);
                    return Outcome.Swapped;
                }
                if (!await SwapInPlaceAsync(bot, candidate, current1, nick, ct))
                {
                    Log.Info($"WeaponSwap({nick}): atomic swap fallback — candidate stays as secondary, primary1 unchanged");
                    return Outcome.Swapped; // candidate is in slot2, still a valid pickup
                }
                return Outcome.Swapped;
            }
            Log.Info($"WeaponSwap({nick}): primary2 empty — equip {candidate.LocalizedName()}({candidateScore:F1}) as secondary (slot1 {current1.LocalizedName()}={score1:F1})");
            var movedSecondary = await MoveIntoSlotAsync(bot, candidate, primary2Slot, nick, ct);
            LootActorGuard.RequireCurrent(bot, ct);
            return movedSecondary ? Outcome.Swapped : Outcome.Skipped;
        }

        // Both primary slots occupied.
        var score2 = WeaponScorer.Score(current2, inventoryItems, weights, $"{nick}:PRI2");

        // Candidate beats primary1: full rotate via two atomic swaps. swap1 places the candidate in primary2
        // (current2 displaced to the candidate's source address); swap2 promotes the candidate to primary1
        // and demotes the previous primary1 to primary2. The sync + IsChangingWeapon poll between the two
        // ensures the bot's weapon-manager view is consistent before swap2.
        if (candidateScore > score1 * margin)
        {
            Log.Info($"WeaponSwap({nick}): full rotate — atomic swap1 {candidate.LocalizedName()}({candidateScore:F1}) ↔ {current2.LocalizedName()}({score2:F1}), then atomic swap2 with {current1.LocalizedName()}({score1:F1})");
            // Phase 5 — strip mods off current2 (the weapon about to leave for the corpse) before the
            // atomic Swap moves it. After the full rotate, the bot will hold the candidate (PRI1) + the
            // demoted current1 (PRI2); current2 is gone, taking any un-stripped mods with it.
            await StripValuableModsBeforeDiscardAsync(bot, current2, new[] { candidate, current1 }, nick, ct);
            LootActorGuard.RequireCurrent(bot, ct);
            if (!await SwapInPlaceAsync(bot, candidate, current2, nick, ct)) return Outcome.Skipped;
            if (dormant)
            {
                RegisterPendingPromotion(bot, candidate, nick);
                return Outcome.Swapped;
            }
            SyncBotBetweenSwaps(bot, nick);
            await WaitForIsChangingWeaponAsync(bot, nick, ct);
            LootActorGuard.RequireCurrent(bot, ct);
            if (!await SwapInPlaceAsync(bot, candidate, current1, nick, ct))
            {
                Log.Info($"WeaponSwap({nick}): second atomic swap fallback — candidate stays as secondary, primary1 unchanged");
                return Outcome.Swapped;
            }
            return Outcome.Swapped;
        }

        // Candidate beats primary2 only: single atomic swap displaces primary2 to the candidate's source
        // address.
        if (candidateScore > score2 * margin)
        {
            Log.Info($"WeaponSwap({nick}): primary2 swap — atomic {candidate.LocalizedName()}({candidateScore:F1}) ↔ {current2.LocalizedName()}({score2:F1})");
            // Phase 5 — strip current2 before it leaves. Bot keeps current1 in PRI1 + candidate in PRI2.
            await StripValuableModsBeforeDiscardAsync(bot, current2, new[] { candidate, current1 }, nick, ct);
            LootActorGuard.RequireCurrent(bot, ct);
            var ok = await SwapInPlaceAsync(bot, candidate, current2, nick, ct);
            LootActorGuard.RequireCurrent(bot, ct);
            return ok ? Outcome.Swapped : Outcome.Skipped;
        }

        Log.Debug($"WeaponSwap({nick}): keep {current1.LocalizedName()}({score1:F1}) + {current2.LocalizedName()}({score2:F1}) — candidate {candidate.LocalizedName()}({candidateScore:F1}) below margin {margin:F2}");
        return Outcome.Skipped;
    }

    // BSG's TryRunNetworkTransaction can hang indefinitely on weapon ops; the await is raced against this
    // timeout and the hands controller is fast-forwarded on expiry to release any pending op.
    private const int NetworkTransactionTimeoutMs = 3000;

    // Settle window after a successful inventory transaction; chaining ops without this produces "Can not
    // execute" build failures and main-thread stalls.
    private const int PostTransactionSettleMs = 2500;

    internal static async Task<bool> RunGuardedTransactionAsync<T>(BotOwner bot, OperationResult<T> op, string label, string nick, CancellationToken ct)
        where T : IOperationResult
    {
        LootActorGuard.RequireCurrent(bot, ct);
        var ic = bot.GetPlayer.InventoryController;
        Log.Debug($"WeaponSwap.{label}({nick}): tx STARTED (awaiting TryRunNetworkTransaction)");
        using var timeoutCts = new CancellationTokenSource(NetworkTransactionTimeoutMs);
        using var waitCts = CancellationTokenSource.CreateLinkedTokenSource(ct, timeoutCts.Token);
        try
        {
            var transaction = LootActorGuard.TrackTransaction(bot, ic.TryRunNetworkTransaction(op, null));
            var result = await LootActorGuard.AwaitTransaction(transaction, waitCts.Token);
            LootActorGuard.RequireCurrent(bot, ct);
            if (!result.Succeed)
            {
                Log.Warning($"WeaponSwap.{label}({nick}): tx FAILED, {result.Error}");
                if (result.Error == "Can not execute")
                    Log.Warning($"WeaponSwap.{label}({nick}): refusal detail: {DescribeRefusal(bot, op.Value)}");
                return false;
            }
            Log.Debug($"WeaponSwap.{label}({nick}): tx DONE (succeeded), settling {PostTransactionSettleMs}ms");
            Singleton<BotRoster>.Instance?.GetAgent(bot)?.LootHandler?.ReportInventoryProgress(ct);
            await Task.Delay(PostTransactionSettleMs, ct);
            LootActorGuard.RequireCurrent(bot, ct);
            return true;
        }
        catch (System.OperationCanceledException) when (!ct.IsCancellationRequested && timeoutCts.IsCancellationRequested)
        {
            LootActorGuard.RequireCurrent(bot, ct);
            Log.Warning($"WeaponSwap.{label}({nick}): tx TIMEOUT after {NetworkTransactionTimeoutMs}ms, fast-forwarding hands controller");
            try { bot.GetPlayer.FastForwardCurrentOperations(); }
            catch (System.Exception ffEx) { Log.Warning($"WeaponSwap.{label}({nick}): FastForward THREW {ffEx.Message}"); }
            return false;
        }
        catch (System.OperationCanceledException) { throw; }
        catch (System.Exception e)
        {
            LootActorGuard.RequireCurrent(bot, ct);
            Log.Warning($"WeaponSwap.{label}({nick}): tx THREW {e}");
            return false;
        }
    }

    /// <summary>
    /// Atomic positional swap of two items in their current addresses. Uses <see
    /// cref="ItemManipulator.Swap"/>, the same op the vanilla UI dispatches when dragging an item
    /// onto an already-occupied slot. Neither slot is transiently empty during the exchange.
    /// </summary>
    /// <summary>
    /// Dry run of <see cref="SwapInPlaceAsync"/>: builds the same simulated operation and throws it away. The
    /// rig and backpack swappers move the bot's carry INTO the candidate before swapping, so a swap BSG refuses
    /// must be known before anything is moved. Customs raid, AlienShooter: a TV-110 armored rig could not go to
    /// a corpse that wore an armor vest (BSG slot conflict), the build failed AFTER the magazines had been
    /// moved into the corpse's rig, and the bot walked away without them.
    /// </summary>
    internal static bool CanSwapInPlace(BotOwner bot, Item itemA, Item itemB, out string error)
    {
        error = null;
        try
        {
            var ic = bot.GetPlayer?.InventoryController;
            var addrA = itemA?.CurrentAddress;
            var addrB = itemB?.CurrentAddress;
            if (ic == null || addrA == null || addrB == null)
            {
                error = "missing inventory controller or item address";
                return false;
            }
            var op = ItemManipulator.Swap(itemA, addrB, itemB, addrA, ic, true);
            if (op.Succeeded) return true;
            error = op.Error?.ToString() ?? "refused";
            return false;
        }
        catch (System.Exception e)
        {
            error = e.Message;
            return false;
        }
    }

    internal static async Task<bool> SwapInPlaceAsync(BotOwner bot, Item itemA, Item itemB, string nick, CancellationToken ct)
    {
        LootActorGuard.RequireCurrent(bot, ct);
        var ic = bot.GetPlayer?.InventoryController;
        if (ic == null || itemA == null || itemB == null) return false;
        var addrA = itemA.CurrentAddress;
        var addrB = itemB.CurrentAddress;
        if (addrA == null || addrB == null)
        {
            Log.Warning($"WeaponSwap.Swap({nick}, {itemA.LocalizedName()} ↔ {itemB.LocalizedName()}): missing CurrentAddress on one of the items — aborting");
            return false;
        }
        var descA = DescribeAddress(addrA, bot);
        var descB = DescribeAddress(addrB, bot);
        var op = ItemManipulator.Swap(itemA, addrB, itemB, addrA, ic, true);
        if (!op.Succeeded)
        {
            Log.Warning($"WeaponSwap.Swap({nick}, {itemA.LocalizedName()}@{descA} ↔ {itemB.LocalizedName()}@{descB}): build FAILED — {op.Error}");
            return false;
        }
        return await RunGuardedTransactionAsync(bot, op, $"Swap({itemA.LocalizedName()}@{descA} ↔ {itemB.LocalizedName()}@{descB})", nick, ct);
    }

    /// <summary>Dry run of <see cref="MoveIntoSlotAsync"/>: same simulated operation, thrown away.</summary>
    internal static bool CanMoveIntoSlot(BotOwner bot, Item item, Slot slot, out string error)
    {
        error = null;
        try
        {
            var ic = bot.GetPlayer?.InventoryController;
            if (ic == null || item == null || slot == null)
            {
                error = "missing inventory controller, item or slot";
                return false;
            }
            var op = ItemManipulator.Move(item, slot.CreateItemAddress(), ic, true);
            if (op.Succeeded) return true;
            error = op.Error?.ToString() ?? "refused";
            return false;
        }
        catch (System.Exception e)
        {
            error = e.Message;
            return false;
        }
    }

    /// <summary>
    /// Dry run of the equip a gear swapper is about to do: the move into an empty slot, or the positional swap
    /// with what the slot holds. Null when BSG accepts it, its reason otherwise. Slot.CheckCompatibility only
    /// looks at the slot filter; the refusals caught here are the cross-slot ones it cannot see: a helmet that
    /// blocks the Earpiece slot, a headset and a hat that conflict with each other (on the bot, or on the
    /// corpse that would receive the displaced item), an armor vest against an armored rig.
    /// </summary>
    internal static string EquipRefusal(BotOwner bot, Item candidate, Slot slot)
    {
        string error;
        var current = slot?.ContainedItem;
        var accepted = current == null
            ? CanMoveIntoSlot(bot, candidate, slot, out error)
            : CanSwapInPlace(bot, candidate, current, out error);
        if (accepted) return null;
        // BSG names every item with its 24-character id, which triples the length of the message.
        return System.Text.RegularExpressions.Regex.Replace(error ?? "refused", @" \(id: [0-9a-f]{24}\)", string.Empty);
    }

    /// <summary>
    /// What stands behind BSG's bare "Can not execute". ItemController.TryRunNetworkTransaction answers it when
    /// the operation's CanExecute fails, which for a move is Item.CheckAction(To): the inventory is blocked, or
    /// the item, its target container or the target cells are held by an operation still registered as ACTIVE
    /// on one of the two owners (ItemController.CheckItemAction). An operation stays active until its hands
    /// animation ends, which never happens on a body that fell asleep in the middle of it. Log-only.
    /// </summary>
    internal static string DescribeRefusal(BotOwner bot, object operation)
    {
        try
        {
            var ic = bot?.GetPlayer?.InventoryController;
            if (ic == null) return "no inventory controller";
            var sb = new System.Text.StringBuilder();
            sb.Append(operation?.GetType().Name ?? "?");
            IItemOwner sourceOwner = null;
            if (operation is MoveResult move && move._item != null)
            {
                var to = move._to;
                sb.Append($" {move._item.LocalizedName()} {DescribeAddress(move._item.CurrentAddress, bot)} -> {DescribeAddress(to, bot)} in {to?.Container?.ParentItem?.LocalizedName() ?? "?"} [{to}]");
                var check = move._item.CheckAction(to);
                sb.Append(check.Failed ? $", CheckAction: {check.Error?.GetType().Name} {check.Error}" : ", CheckAction passes now");
                sourceOwner = move._item.Parent?.GetOwner();
            }
            sb.Append($", inventory blocked: {ic.IsInventoryBlocked()}");
            sb.Append($", hands: {bot.GetPlayer.HandsController?.GetType().Name ?? "none"} holding {bot.GetPlayer.HandsController?.Item?.LocalizedName() ?? "nothing"}");
            AppendActiveEvents(sb, "bot", ic, bot);
            if (sourceOwner != null && !ReferenceEquals(sourceOwner, ic)) AppendActiveEvents(sb, "source", sourceOwner, bot);
            return sb.ToString();
        }
        catch (System.Exception e)
        {
            return $"refusal diagnostic threw: {e.Message}";
        }
    }

    private static void AppendActiveEvents(System.Text.StringBuilder sb, string label, IItemOwner owner, BotOwner bot)
    {
        var events = owner.SelectEvents((Item)null).ToList();
        sb.Append($", active operations on {label}: {events.Count}");
        for (var i = 0; i < events.Count && i < 6; i++)
        {
            var e = events[i];
            sb.Append($" | {e.GetType().Name} {e.Item?.LocalizedName() ?? "?"} ({e.Status}) at {DescribeAddress(e.Location, bot)} [{e.Location}]");
        }
    }

    internal static async Task<bool> MoveIntoSlotAsync(BotOwner bot, Item item, Slot slot, string nick, CancellationToken ct)
    {
        LootActorGuard.RequireCurrent(bot, ct);
        var ic = bot.GetPlayer?.InventoryController;
        if (ic == null || item == null || slot == null) return false;
        var destSlotId = slot.ID ?? "?";
        var fromDesc = DescribeAddress(item.CurrentAddress, bot);
        if (!slot.CheckCompatibility(item))
        {
            Log.Warning($"WeaponSwap.Move({nick}, {item.LocalizedName()} from {fromDesc} → {destSlotId}): slot rejects item");
            return false;
        }
        var address = slot.CreateItemAddress();
        var op = ItemManipulator.Move(item, address, ic, true);
        if (!op.Succeeded)
        {
            Log.Warning($"WeaponSwap.Move({nick}, {item.LocalizedName()} from {fromDesc} → {destSlotId}): build FAILED — {op.Error}");
            return false;
        }
        return await RunGuardedTransactionAsync(bot, op, $"Move({item.LocalizedName()}: {fromDesc}→{destSlotId})", nick, ct);
    }

    private static string DescribeAddress(ItemAddress address, BotOwner bot = null)
    {
        if (address == null) return "(no-addr)";
        try
        {
            var container = address.Container;
            if (container == null) return "(no-container)";
            var containerKind = container is Slot s ? $"slot:{s.ID}" : "grid";
            var ownerLabel = ResolveOwnerLabel(address, bot);
            return $"{containerKind}@{ownerLabel}";
        }
        catch (System.Exception ex)
        {
            Log.Debug($"DescribeAddress threw (cosmetic, fallback label used): {ex.Message}");
            return "(addr-error)";
        }
    }

    private static string ResolveOwnerLabel(ItemAddress address, BotOwner bot)
    {
        try
        {
            var addressOwner = address?.GetOwnerOrNull();
            var botOwner = bot?.GetPlayer?.InventoryController;
            if (addressOwner != null && botOwner != null && ReferenceEquals(addressOwner, botOwner))
                return "bot";
            return "corpse/external";
        }
        catch
        {
            return "(owner-error)";
        }
    }

    // Refresh BSG's internal weapon-manager view between two atomic swaps of a full rotate. Without it, swap2
    // frequently lands on stale slot data and the BSG Swap op fails ("can not execute") even though the
    // inventory state is valid.
    private static void SyncBotBetweenSwaps(BotOwner bot, string nick)
    {
        try { bot.WeaponManager?.Selector?.UpdateWeaponsList(); }
        catch (System.Exception e) { Log.Warning($"WeaponSwap.SyncBetween({nick}): UpdateWeaponsList THREW {e.Message}"); }
        try { bot.AIData?.CalcPower(); }
        catch (System.Exception e) { Log.Warning($"WeaponSwap.SyncBetween({nick}): CalcPower THREW {e.Message}"); }
    }

    // Wait for the hands controller's IsChangingWeapon flag to clear before the next op. Polled instead of
    // blind-delayed so the typical sub-1s case doesn't hold up the bot.
    private static async Task WaitForIsChangingWeaponAsync(BotOwner bot, string nick, CancellationToken ct)
    {
        LootActorGuard.RequireCurrent(bot, ct);
        const int maxWaitMs = 5000;
        const int pollIntervalMs = 100;
        var ic = bot?.GetPlayer?.InventoryController;
        if (ic == null) return;
        var elapsed = 0;
        while (elapsed < maxWaitMs)
        {
            bool changing;
            try { changing = ic.IsChangingWeapon; }
            catch { changing = false; }
            if (!changing) return;
            await Task.Delay(pollIntervalMs, ct);
            LootActorGuard.RequireCurrent(bot, ct);
            elapsed += pollIntervalMs;
        }
        Log.Warning($"WeaponSwap.WaitForIsChangingWeapon({nick}): hit {maxWaitMs}ms cap — proceeding");
    }

    // UpdateWeaponsList alone only rebuilds the selector's list while the hands controller still holds the
    // discarded gun, so the bot "fires" a dead reference until BSG re-selects; ChangeToMain forces the re-draw.
    private static async Task FinalizeWeaponSwapAsync(BotOwner bot, string nick, CancellationToken ct)
    {
        LootActorGuard.RequireCurrent(bot, ct);
        try
        {
            await WaitForIsChangingWeaponAsync(bot, nick, ct);
            LootActorGuard.RequireCurrent(bot, ct);
            var selector = bot?.WeaponManager?.Selector;
            if (selector == null) return;
            selector.UpdateWeaponsList();
            selector.ChangeToMain();
            try { bot.AIData?.CalcPower(); } catch { }
            Log.Debug($"WeaponSwap.Finalize({nick}): refreshed weapon list + re-drew main weapon so SAIN fires the new gun");
        }
        catch (System.OperationCanceledException) { throw; }
        catch (System.Exception e)
        {
            Log.Warning($"WeaponSwap.Finalize({nick}): THREW {e.Message}");
        }
    }

    private static bool BotHasGoodPenWeapon(BotOwner bot, List<Item> inventoryItems)
    {
        var equipment = bot.GetPlayer?.Inventory?.Equipment;
        if (equipment == null) return false;
        foreach (var slotKind in new[] { EquipmentSlot.FirstPrimaryWeapon, EquipmentSlot.SecondPrimaryWeapon, EquipmentSlot.Holster })
        {
            var slot = equipment.GetSlot(slotKind);
            if (slot?.ContainedItem is not Weapon w) continue;
            var ammo = WeaponScorer.CollectUsableAmmo(w, inventoryItems);
            if (ammo.BestPenetration >= 20) return true;
        }
        return false;
    }

    // Bot's full ammo pool: every item across equipment slots, including the secure container (part of
    // Inventory.Equipment).
    /// <summary>
    /// Strip valuable mods off a weapon about to be discarded. A mod is stripped when its per-slot price clears
    /// the bot's mini-loot threshold, or it's a magazine whose caliber matches a weapon kept post-swap.
    /// </summary>
    private static async Task StripValuableModsBeforeDiscardAsync(
        BotOwner bot, Weapon weaponToDiscard, IList<Weapon> postSwapWeapons, string nick, CancellationToken ct)
    {
        LootActorGuard.RequireCurrent(bot, ct);
        if (weaponToDiscard?.Slots == null || weaponToDiscard.Slots.Length == 0) return;
        var ic = bot.GetPlayer?.InventoryController;
        if (ic == null) return;
        // Reuse the bot's mini-loot threshold: a mod worth picking off the floor is worth saving off a discard.
        var agent = Singleton<BotRoster>.Instance?.GetAgent(bot);
        var resolved = agent != null
            ? Orbit.Tasks.Actions.LootContainerAction.GetOrResolveAgentMiniLootThreshold(agent)
            : OrbitLootHandler.DefaultMinPickupPrice;
        var threshold = resolved > 0f ? resolved : OrbitLootHandler.DefaultMinPickupPrice;

        // Build the set of weapon mag-slots the post-swap loadout will have. A mag whose template fits any
        // of these is worth keeping (we can extract its rounds for the matching weapon later).
        var postSwapMagSlots = new List<Slot>(postSwapWeapons?.Count ?? 0);
        if (postSwapWeapons != null)
            foreach (var w in postSwapWeapons)
            {
                if (w == null) continue;
                var ms = w.GetMagazineSlot();
                if (ms != null) postSwapMagSlots.Add(ms);
            }

        // Sort by price/slot desc so the most valuable mods get stripped first; if the bot's bag runs out
        // mid-strip, the cheap mods stay on the discarded weapon (the right tradeoff).
        var candidates = new List<(Slot slot, Item mod, float pricePerSlot, string reason)>();
        for (var i = 0; i < weaponToDiscard.Slots.Length; i++)
        {
            var slot = weaponToDiscard.Slots[i];
            var mod = slot?.ContainedItem;
            if (mod == null) continue;
            // Non-raid-moddable parts (barrel, receiver) can't be detached in-raid; moving one via a raw tx
            // desyncs FIKA, so skip them.
            if (mod is Mod nonRaidMod && !nonRaidMod.RaidModdable) continue;
            var pricePerSlot = ItemPriceLookup.GetPricePerSlot(mod);
            string reason = null;
            if (pricePerSlot >= threshold) reason = $"price/slot={pricePerSlot:N0}₽ ≥ {threshold:N0}₽";
            else if (mod is Magazine mag && postSwapMagSlots.Count > 0)
            {
                foreach (var pms in postSwapMagSlots)
                {
                    try { if (pms.CheckCompatibility(mag)) { reason = $"mag fits post-swap weapon ({pms.ParentItem?.LocalizedName()})"; break; } }
                    catch { /* slot probe can throw — treat as no-fit */ }
                }
            }
            if (reason != null) candidates.Add((slot, mod, pricePerSlot, reason));
        }
        if (candidates.Count == 0)
        {
            Log.Debug($"WeaponStrip({nick}): no valuable mods on {weaponToDiscard.LocalizedName()} (threshold {threshold:N0}₽/slot) — full discard");
            return;
        }
        candidates.Sort((a, b) => b.pricePerSlot.CompareTo(a.pricePerSlot));

        Log.Info($"WeaponStrip({nick}): {candidates.Count} mod(s) to strip off {weaponToDiscard.LocalizedName()} before discard");
        var emptyGrids = new List<CompoundItem>(0); // QFAP scans the full inventory by default; null = use bot's grids
        foreach (var (slot, mod, pricePerSlot, reason) in candidates)
        {
            ct.ThrowIfCancellationRequested();
            try
            {
                var place = ItemManipulator.QuickFindAppropriatePlace(
                    mod, ic, emptyGrids,
                    ItemManipulator.EMoveItemOrder.PickUp, true);
                if (!place.Succeeded)
                {
                    Log.Debug($"WeaponStrip({nick}): QFAP failed for {mod.LocalizedName()} — no room, leaving on weapon");
                    continue;
                }
                Log.Info($"WeaponStrip({nick}): strip {slot.ID}={mod.LocalizedName()} → bot grids ({reason})");
                var ok = await RunGuardedTransactionAsync(bot, place, $"WeaponStrip({mod.LocalizedName()})", nick, ct);
                LootActorGuard.RequireCurrent(bot, ct);
                if (!ok) Log.Debug($"WeaponStrip({nick}): network tx failed for {mod.LocalizedName()} — leaving on weapon");
            }
            catch (System.OperationCanceledException) { throw; }
            catch (System.Exception ex)
            {
                Log.Debug($"WeaponStrip({nick}): strip {mod.LocalizedName()} threw — {ex.Message}");
            }
        }
    }

    /// <summary>
    /// Compose the post-swap weapon set for Phase 5's mag-compat check from inside the swap path. The
    /// bot keeps every weapon currently in their slots EXCEPT the one being discarded, plus the candidate
    /// going into the named slot. Used by the holster-swap path; the primary-rotate paths pass the post
    /// loadout explicitly.
    /// </summary>
    private static IList<Weapon> GatherPostSwapWeapons(BotOwner bot, Weapon candidate, EquipmentSlot equippingSlot)
    {
        var list = new List<Weapon>();
        if (candidate != null) list.Add(candidate);
        var equipment = bot.GetPlayer?.Inventory?.Equipment;
        if (equipment == null) return list;
        foreach (var sk in new[] { EquipmentSlot.FirstPrimaryWeapon, EquipmentSlot.SecondPrimaryWeapon, EquipmentSlot.Holster })
        {
            if (sk == equippingSlot) continue; // the slot being filled by the candidate
            if (equipment.GetSlot(sk)?.ContainedItem is Weapon w) list.Add(w);
        }
        return list;
    }

    /// <summary>
    /// Concatenate the bot's inventory ammo pool with the corpse / container source tree to get the
    /// post-swap ammo pool a CANDIDATE weapon will be able to feed from. No de-duplication needed —
    /// `WeaponScorer.CollectUsableAmmo` filters by mag-slot compatibility and caliber, so an item showing
    /// up twice would still only contribute its stack once on the bot side. The two sources are physically
    /// distinct (bot vs. corpse) so they shouldn't share item references anyway.
    /// </summary>
    private static List<Item> CombineAmmoPools(List<Item> inventoryItems, List<Item> sourceItems)
    {
        var combined = new List<Item>((inventoryItems?.Count ?? 0) + (sourceItems?.Count ?? 0));
        if (inventoryItems != null) combined.AddRange(inventoryItems);
        if (sourceItems != null) combined.AddRange(sourceItems);
        return combined;
    }

    private static List<Item> CollectBotInventoryAmmoPool(BotOwner bot)
    {
        var list = new List<Item>();
        var equipment = bot.GetPlayer?.Inventory?.Equipment;
        if (equipment == null) return list;
        foreach (var item in equipment.GetAllItems())
            if (item != null) list.Add(item);
        return list;
    }
}
