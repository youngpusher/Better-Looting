using System.Collections.Generic;
using Comfort.Common;
using Orbit.Core;
using Orbit.Entities;

namespace Orbit.Api;

/// <summary>
/// Stable public read-only telemetry surface. External consumers (e.g. raid-review) reference ORBIT.dll
/// directly and call these methods rather than reflecting against internal types. DTO types in this namespace
/// are the API contract — internal renames or restructuring inside <c>Orbit.*</c> must not change them
/// without a major version bump.
/// </summary>
public static class OrbitTelemetry
{
    /// <summary>
    /// True when an OrbitManager singleton has been created (raid in progress). Cheap call — safe to invoke
    /// every tick.
    /// </summary>
    public static bool IsAvailable => Singleton<OrbitManager>.Instance != null;

    /// <summary>
    /// Bumped whenever a squad main objective flips to Completed, so a slow poller can detect completions via
    /// deltas without waiting for its next interval. Not reset between raids.
    /// </summary>
    public static int MainObjectivesRevision;

    /// <summary>
    /// True while Ghost Mode has this bot dormant (body asleep, ORBIT still driving it). Static-set
    /// lookup, no OrbitManager needed — safe and cheap to call per position sample.
    /// </summary>
    public static bool IsBotDormant(string profileId)
        => Orbit.Systems.DormancySystem.IsDormantProfile(profileId);

    /// <summary>Current hearing coverage at the squad listener, independent of sound events.</summary>
    public static OrbitGhostHearingState GetGhostHearingState(string profileId)
    {
        var manager = Singleton<OrbitManager>.Instance;
        if (manager?.DormancySystem == null || manager.AgentData == null || string.IsNullOrEmpty(profileId))
            return null;
        var agent = manager.AgentData.GetByProfileId(profileId);
        if (agent != null) return manager.DormancySystem.GetGhostHearingState(agent);
        return manager.DormancySystem.GetNativeGhostHearingState(profileId);
    }

    // ── Simulated ghost fights (Ghost Mode) ─────────────────────────────

    private static readonly List<OrbitGhostFight> PendingGhostFights = new();

    /// <summary>Called by the limiter each time a simulated fight window opens.</summary>
    internal static void PushGhostFight(OrbitGhostFight fight)
    {
        lock (PendingGhostFights)
        {
            // A poller that died mid-raid must not leak unbounded memory.
            if (PendingGhostFights.Count < 256) PendingGhostFights.Add(fight);
        }
    }

    internal static void ClearGhostFights()
    {
        lock (PendingGhostFights) PendingGhostFights.Clear();
        lock (PendingGhostHearing) PendingGhostHearing.Clear();
        lock (PendingGhostWakes) PendingGhostWakes.Clear();
    }

    private static readonly Queue<OrbitGhostWake> PendingGhostWakes = new();

    internal static void PushGhostWake(OrbitGhostWake wake)
    {
        lock (PendingGhostWakes)
        {
            if (PendingGhostWakes.Count >= 1024) PendingGhostWakes.Dequeue();
            PendingGhostWakes.Enqueue(wake);
        }
        Helpers.DiagnosticCapture.Wake(wake);
    }

    /// <summary>Actual wakes since the previous poll; bounded to the latest 1024 if no consumer polls.</summary>
    public static List<OrbitGhostWake> DrainGhostWakes()
    {
        lock (PendingGhostWakes)
        {
            if (PendingGhostWakes.Count == 0) return null;
            var result = new List<OrbitGhostWake>(PendingGhostWakes);
            PendingGhostWakes.Clear();
            return result;
        }
    }

    private static readonly List<OrbitGhostHearing> PendingGhostHearing = new();

    /// <summary>Records the outcome of an actual hearing roll, without rolling again for telemetry.</summary>
    internal static void PushGhostHearing(OrbitGhostHearing hearing)
    {
        lock (PendingGhostHearing)
        {
            // Bounded even when RaidReview is absent or stops polling.
            if (PendingGhostHearing.Count < 512) PendingGhostHearing.Add(hearing);
        }
    }

    /// <summary>Drains hearing decisions since the last poll. Null means no new decisions.</summary>
    public static List<OrbitGhostHearing> DrainGhostHearing()
    {
        lock (PendingGhostHearing)
        {
            if (PendingGhostHearing.Count == 0) return null;
            var drained = new List<OrbitGhostHearing>(PendingGhostHearing);
            PendingGhostHearing.Clear();
            return drained;
        }
    }

    /// <summary>
    /// Drains the simulated ghost fights resolved since the last call (null when none). Poll-friendly:
    /// raid-review calls this from its tracking loop and renders the fight windows in the replay.
    /// </summary>
    public static List<OrbitGhostFight> DrainGhostFights()
    {
        lock (PendingGhostFights)
        {
            if (PendingGhostFights.Count == 0) return null;
            var drained = new List<OrbitGhostFight>(PendingGhostFights);
            PendingGhostFights.Clear();
            return drained;
        }
    }

    /// <summary>
    /// Resolve a bot's current objective by profile id. Returns null when no ORBIT-managed agent matches, the
    /// agent is inactive, or it has no objective. Lookup uses the live dataset profile index in O(1).
    /// </summary>
    public static OrbitBotObjective GetBotObjective(string profileId)
    {
        if (string.IsNullOrEmpty(profileId)) return null;
        var manager = Singleton<OrbitManager>.Instance;
        if (manager?.AgentData == null) return null;

        var agent = manager.AgentData.GetByProfileId(profileId);
        if (agent == null || !agent.IsActive) return null;

        var obj = agent.Objective;
        if (obj == null) return null;

        var loc = obj.Location;
        var category = loc != null ? loc.Category.ToString() : "";
        if (loc?.IsAirdrop == true) category = "AirdropLoot";
        if (agent.Squad?.Camp.Approach?.Owns(agent) == true) category = "AirdropApproach";
        if (agent.Squad?.Camp.Owns(agent) == true)
            category = agent.Squad.Camp.Looter == agent ? "AirdropLoot" : "Ambush" + agent.Squad.Camp.Site.Kind;
        else if (agent.Squad != null)
            category = Orbit.Systems.ExtractCampApproach.Category(agent.Squad, agent) ?? category;
        if (agent.Squad?.Rush?.Owns(agent) == true)
        {
            var rush = agent.Squad.Rush;
            category = $"{rush.Name}: {rush.Step} ({rush.Status})";
        }
        else if (agent.Squad?.Operation?.Owns(agent) == true)
        {
            var operation = agent.Squad.Operation;
            category = $"MultiStep: {operation.Definition.Name} ({operation.Index + 1}/{operation.Count}) {operation.Current.Label}";
        }
        if (agent.Squad?.CorpseEscort.IsWaitingInCover(agent) == true) category = "SquadCover";
        var x = loc?.Position.x ?? 0f;
        var y = loc?.Position.y ?? 0f;
        var z = loc?.Position.z ?? 0f;

        // A member's own solo/emergency extract takes precedence over the squad-wide reason for display.
        var extractReason = "";
        var squad = agent.Squad;
        if (agent.SoloExtractRequested)
        {
            extractReason = agent.SoloExtractIsEmergency
                ? "emergency extract"
                : (string.IsNullOrEmpty(agent.SoloExtractReason) ? "loot threshold reached" : agent.SoloExtractReason);
        }
        else if (squad != null && squad.ExtractRequested)
        {
            extractReason = squad.ExtractRequestedReason ?? "";
        }

        return new OrbitBotObjective
        {
            Status = obj.Status.ToString(),
            Category = category,
            IsLeader = agent.IsLeader,
            ObjectiveX = x,
            ObjectiveY = y,
            ObjectiveZ = z,
            ExtractReason = extractReason,
        };
    }

    /// <summary>
    /// Snapshot of the advection field + hot zones. Returns null when the WaypointSystem isn't ready yet OR
    /// the snapshot would be empty (no non-zero advection cells AND no zones).
    /// </summary>
    public static OrbitFieldSnapshot GetFieldSnapshot()
    {
        var manager = Singleton<OrbitManager>.Instance;
        var ws = manager?.WaypointSystem;
        if (ws == null) return null;

        var advectionField = ws.AdvectionField;
        var gridSize = ws.GridSize;
        var advection = new List<OrbitFieldCell>();
        if (advectionField != null)
        {
            for (var x = 0; x < gridSize.x; x++)
            {
                for (var y = 0; y < gridSize.y; y++)
                {
                    var v = advectionField[x, y];
                    if (v.x * v.x + v.y * v.y < 0.0001f) continue;
                    advection.Add(new OrbitFieldCell { X = x, Y = y, Fx = v.x, Fz = v.y });
                }
            }
        }

        var zones = new List<OrbitFieldZone>();
        var zonesList = ws.Zones;
        if (zonesList != null)
        {
            for (var i = 0; i < zonesList.Count; i++)
            {
                var z = zonesList[i];
                zones.Add(new OrbitFieldZone
                {
                    X = z.Coords.x,
                    Y = z.Coords.y,
                    Radius = z.Radius,
                    Force = z.Force,
                    Decay = z.Decay,
                });
            }
        }

        if (advection.Count == 0 && zones.Count == 0) return null;

        return new OrbitFieldSnapshot
        {
            GridCols = gridSize.x,
            GridRows = gridSize.y,
            WorldMinX = ws.WorldMin.x,
            WorldMinZ = ws.WorldMin.y,
            CellSize = ws.CellSize,
            Advection = advection,
            Zones = zones,
        };
    }

    /// <summary>
    /// Per-squad main-objective list snapshot. Empty list when no squad carries any mains (e.g. raid hasn't
    /// started, or only boss/raider squads exist which skip the system entirely).
    /// </summary>
    public static List<OrbitSquadMainObjectives> GetMainObjectivesSnapshot()
    {
        var result = new List<OrbitSquadMainObjectives>();
        var manager = Singleton<OrbitManager>.Instance;
        if (manager?.SquadData == null) return result;

        var squads = manager.SquadData.Entities.Values;
        for (var i = 0; i < squads.Count; i++)
        {
            var squad = squads[i];
            if (squad == null) continue;
            var airdrop = squad.Camp.GetAirdropObjective();
            var mainCount = squad.MainObjectives?.Count ?? 0;
            if (mainCount == 0 && airdrop == null) continue;

            var memberIds = new List<string>(squad.Members.Count);
            for (var m = 0; m < squad.Members.Count; m++)
            {
                var pid = squad.Members[m]?.Player?.ProfileId;
                if (!string.IsNullOrEmpty(pid)) memberIds.Add(pid);
            }

            var mains = new List<OrbitMainObjective>(mainCount + (airdrop == null ? 0 : 1));
            for (var mi = 0; mi < mainCount; mi++)
            {
                var m = squad.MainObjectives[mi];
                mains.Add(new OrbitMainObjective
                {
                    Type = m.Type.ToString(),
                    CellX = m.CellCoords.x,
                    CellY = m.CellCoords.y,
                    X = m.Position.x,
                    Y = m.Position.y,
                    Z = m.Position.z,
                    Completed = m.Completed,
                    OperationId = m.Operation?.Definition.Id ?? m.Rush?.Kind,
                    OperationName = m.Operation?.Definition.Name ?? m.Rush?.Name,
                    OperationStep = m.Operation?.Current.Label ?? m.Rush?.Step,
                    OperationStepIndex = m.Operation != null ? m.Operation.Index + 1 : m.Rush != null ? System.Math.Min(m.Rush.Index + 1, m.Rush.Count) : 0,
                    OperationStepCount = m.Operation?.Count ?? m.Rush?.Count ?? 0,
                    OperationState = m.Operation?.Status ?? m.Rush?.Status,
                    RushPoints = m.Rush?.Snapshot(),
                    KillAmbush = m.KillAmbush,
                    CampStartedAt = m.CampStartedAt,
                    CampElapsed = m.CampElapsed,
                    CampTargetDuration = m.KillAmbush ? m.KillsRoamTargetDuration : m.CampTargetDuration,
                    CampUntilTimeExtract = m.Type == MainObjectiveType.ExtractCamp,
                    CampExtractRemainingSeconds = m.Type == MainObjectiveType.ExtractCamp && !m.Completed
                        ? Orbit.Tasks.RaidTimeExtraction.SecondsUntilDeparture(squad) : null,
                    CampState = m.CampState,
                    CampFailure = m.CampFailure,
                    CampSearchAttempt = m.CampSearchAttempt,
                    CampSearchRadius = m.CampSearchRadius,
                    CampHolding = squad.Camp.Main == m && squad.Camp.Holding || m.Rush?.Kind == "Sniper" && m.Rush.Status == "holding",
                    KillsRoamStartedAt = m.KillsRoamStartedAt,
                    KillsRoamTargetDuration = m.KillsRoamTargetDuration,
                    LootValueEnteredAt = m.LootValueEnteredAt,
                    LootValueTotal = m.LootValueTotal,
                    LootValueInterrupted = m.LootValueInterrupted,
                    QuestTriggerId = m.QuestTriggerId,
                    QuestTitle = m.QuestTitle,
                });
            }

            // Display-only detour, never inserted into the squad's strategic goals or completion checks.
            if (airdrop != null) mains.Add(airdrop);

            result.Add(new OrbitSquadMainObjectives
            {
                SquadId = squad.Id,
                MemberProfileIds = memberIds,
                MainObjectives = mains,
            });
        }
        return result;
    }
}

public class OrbitBotObjective
{
    public string Status;
    public string Category;
    public bool IsLeader;
    public float ObjectiveX;
    public float ObjectiveY;
    public float ObjectiveZ;
    /// <summary>Non-empty only when the squad has flipped ExtractRequested.</summary>
    public string ExtractReason;
}

public class OrbitFieldSnapshot
{
    public int GridCols;
    public int GridRows;
    public float WorldMinX;
    public float WorldMinZ;
    public float CellSize;
    public List<OrbitFieldCell> Advection;
    public List<OrbitFieldZone> Zones;
}

public class OrbitFieldCell
{
    public int X;
    public int Y;
    public float Fx;
    public float Fz;
}

public class OrbitFieldZone
{
    public float X;
    public float Y;
    public float Radius;
    public float Force;
    public float Decay;
}

public class OrbitSquadMainObjectives
{
    public int SquadId;
    public List<string> MemberProfileIds;
    public List<OrbitMainObjective> MainObjectives;
}

public class OrbitMainObjective
{
    public string AirdropStage;
    public string AirdropId;
    public bool AirdropLanded;
    public OrbitRushPoint[] RushPoints;
    public string OperationId;
    public string OperationName;
    public string OperationStep;
    public int OperationStepIndex;
    public int OperationStepCount;
    public string OperationState;
    /// <summary>"Kills" | "LootValue" | "Quest" | "ExtractCamp" | "MultiStep" | "Rush".</summary>
    public string Type;
    public int CellX;
    public int CellY;
    public float X;
    public float Y;
    public float Z;
    public bool Completed;
    public bool KillAmbush;
    public float CampStartedAt;
    public float CampElapsed;
    public float CampTargetDuration;
    public bool CampUntilTimeExtract;
    public float? CampExtractRemainingSeconds;
    public bool CampHolding;
    public string CampState;
    public string CampFailure;
    public int CampSearchAttempt;
    public float CampSearchRadius;
    public float KillsRoamStartedAt;
    public float KillsRoamTargetDuration;
    public float LootValueEnteredAt;
    public float LootValueTotal;
    public bool LootValueInterrupted;
    public string QuestTriggerId;
    public string QuestTitle;
}

/// <summary>One simulated ghost fight (Ghost Mode): two dormant units exchanged fire between PosA and
/// PosB for Duration seconds, producing Casualties deaths (0 = a bloodless exchange).</summary>
public class OrbitGhostFight
{
    public float AX;
    public float AY;
    public float AZ;
    public float BX;
    public float BY;
    public float BZ;
    public float Duration;
    public int Casualties;
}

/// <summary>An eligible dormant group heard a noise and chose whether to investigate it.
/// Positions and membership are captured at the decision, not at the consumer's next poll.</summary>
public class OrbitGhostHearing
{
    public float RecordedAt;
    public int NoiseId;
    public int SquadId;
    public string ProfileId;
    public string[] MemberProfileIds;
    public float SourceX;
    public float SourceY;
    public float SourceZ;
    public float ListenerX;
    public float ListenerY;
    public float ListenerZ;
    public float Range;
    public float MinimumDistance;
    public float Distance;
    public float Chance;
    public bool Simulated;
    public int Shots;
    public bool Investigate;
    public string Personality;
}

public class OrbitGhostHearingState
{
    public float Range;
    public float SuppressedRange;
    public float MinimumDistance;
    public string State;
}

public sealed class OrbitRushPoint
{
    public string Id, Name, State;
    public float X, Y, Z, Radius;
    public int Sequence;
}
