using System.Collections.Generic;
using EFT;
using EFT.Interactive;
using Orbit.Entities;
using Orbit.Helpers;
using Orbit.Navigation;
using UnityEngine;
using UnityEngine.AI;

namespace Orbit.Systems;

public partial class WaypointSystem
{
    private MultiStepCatalog _operations;
    private readonly NavMeshPath _operationPath = new();
    private float _nextOperationPlan;

    private void InitializeOperations()
    {
        var exits = new List<Waypoint>();
        foreach (var cell in _cells)
            foreach (var point in cell.Waypoints)
                if (point.Category == WaypointCategory.Exfil) exits.Add(point);
        _operations = new MultiStepCatalog(_mapId, exits, _zoneKey);
    }

    internal MainObjective RollOperationMain(Squad squad)
    {
        var definition = PickOperation(squad, false);
        if (definition == null) return null;
        var plan = new OperationPlan(definition, UnityEngine.Random.value < OperationStyle(squad).DisableAlarmChance);
        var main = new MainObjective { Type = MainObjectiveType.MultiStep, Operation = plan,
            Position = plan.Current.Position, CellCoords = WorldToCell(plan.Current.Position) };
        plan.Main = main;
        return main;
    }

    internal static Orbit.Settings.MultiStepStyle OperationStyle(Squad squad)
        => ServerConfig.MultiStep.Style(squad.Personality?.Archetype.ToString(), squad.Leader?.BotCategory == "PlayerScav");

    private OperationDefinition PickOperation(Squad squad, bool extraction)
    {
        if (_operations == null || !ServerConfig.MultiStep.Allows(squad.Leader?.BotCategory)) return null;
        var sum = 0f;
        OperationDefinition chosen = null;
        foreach (var definition in _operations.Operations)
        {
            if (definition.Extraction != extraction || !definition.AllowsCategory(squad.Leader?.BotCategory)) continue;
            if (extraction && squad.FailedOperationExits.Contains(definition.Id)) continue;
            var used = false;
            if (!extraction && squad.MainObjectives != null)
                foreach (var main in squad.MainObjectives)
                    if (main.Operation?.Definition == definition) { used = true; break; }
            if (used) continue;
            if (extraction && !OperationExitEligible(squad, definition.Steps[definition.Steps.Count - 1].Exit)) continue;
            var weight = ServerConfig.MultiStep.Weight(definition.Id);
            if (weight <= 0) continue;
            sum += weight;
            if (UnityEngine.Random.value * sum < weight) chosen = definition;
        }
        return chosen;
    }

    private bool OperationExitEligible(Squad squad, Waypoint target)
    {
        if (target?.Target is not ExfiltrationPoint exit || exit.Settings == null
            || exit.Status is EExfiltrationStatus.NotPresent or EExfiltrationStatus.Hidden) return false;
        var bot = squad.Leader.Bot;
        if (bot.Profile.WillBeAPlayerScav() || !bot.Profile.Info.Settings.Role.IsPMC()) return false;
        return ServerConfig.Loot.ExtractAllowedFor.IsBotEnabled(bot.Profile.Info.Settings.Role)
               && MatchesBotSpawnEntry(squad, exit);
    }

    internal bool TickOperation(Squad squad, bool combat)
    {
        // Shared world prerequisites can change while another operation owns
        // the squad. Keep pending targets current for selection and telemetry.
        if (squad.MainObjectives != null)
            foreach (var main in squad.MainObjectives)
                main.Operation?.RefreshPending(this);
        if (squad.Operation != null)
        {
            if (squad.Operation.Tick(squad, this, combat)) return true;
            if (squad.Operation.Active) return false;
            squad.Operation = null;
        }
        if (combat || squad.SainResolutionPending || squad.Camp.Active || squad.CorpseEscort.Active
            || Time.time < _nextOperationPlan || !ServerConfig.MultiStep.Allows(squad.Leader?.BotCategory)) return false;
        if (squad.ExtractRequested)
        {
            if (!squad.OperationExtractRolled)
            {
                var chance = OperationStyle(squad).ExtractionChance;
                if (!TryPreparedExtractionChance(squad, chance, out chance)) return true;
                squad.OperationExtractRolled = true;
                squad.OperationExtractCommitted = UnityEngine.Random.value < chance;
            }
            var reserveFallback = string.Equals(_mapId, "RezervBase", System.StringComparison.OrdinalIgnoreCase)
                && squad.Leader?.BotCategory == "PMC";
            // Reserve has no unconditional PMC exit. A failed personality roll must not
            // strand a departing squad when no active exit or no-backpack route is usable.
            if (!squad.OperationExtractCommitted
                && (!reserveFallback || Time.time < squad.OperationExtractRetryAt
                    || FindNearestEligibleExfil(squad) != null || ExfilSearchPending(squad))) return false;
            var forced = !squad.OperationExtractCommitted;
            var definition = PickOperation(squad, true);
            if (definition != null)
            {
                squad.OperationExtractCommitted = true;
                if (forced)
                    Log.Info($"MULTISTEP EXTRACT: {squad} Reserve fallback operation={definition.Id} reason=no usable exit; personality roll overridden");
                squad.Operation = new OperationPlan(definition, false);
                var marker = new MainObjective { Type = MainObjectiveType.MultiStep, Operation = squad.Operation,
                    Position = squad.Operation.Current.Position, CellCoords = WorldToCell(squad.Operation.Current.Position) };
                squad.Operation.Main = marker;
                squad.MainObjectives ??= new List<MainObjective>();
                squad.MainObjectives.Add(marker);
            }
            else
            {
                squad.OperationExtractCommitted = false;
                if (reserveFallback)
                {
                    // Try the other exit first. After exhausting both, allow a later attempt
                    // from a new position/world state instead of blacklisting them forever.
                    squad.OperationExtractRetryAt = Time.time + 30f;
                    var retry = squad.FailedOperationExits.Remove("d2");
                    retry |= squad.FailedOperationExits.Remove("hermetic");
                    if (retry)
                        Log.Info($"MULTISTEP EXTRACT: {squad} Reserve routes exhausted; retry in 30s");
                }
            }
        }
        else if (squad.MainObjectives != null)
        {
            var nearest = squad.MainApproach.Select(squad);
            if (nearest?.Operation != null) squad.Operation = nearest.Operation;
        }
        if (squad.Operation == null) return false;
        _nextOperationPlan = Time.time + .5f;
        squad.Operation.Begin(squad);
        return squad.Operation.Tick(squad, this, combat);
    }

    private bool TryPreparedExtractionChance(Squad squad, float personalityChance, out float chance)
    {
        chance = personalityChance;
        if (!string.Equals(_mapId, "bigmap", System.StringComparison.OrdinalIgnoreCase) || personalityChance <= 0)
            return true;
        chance *= ServerConfig.MultiStep.CustomsExtractionMultiplier;
        if (chance <= 0) return true;
        OperationDefinition prepared = null;
        if (_operations != null)
            foreach (var definition in _operations.Operations)
                if (definition.Id == "zb013" && ServerConfig.MultiStep.Weight(definition.Id) > 0
                    && !squad.FailedOperationExits.Contains(definition.Id) && definition.AllowsCategory(squad.Leader?.BotCategory)
                    && OperationExitEligible(squad, definition.Steps[definition.Steps.Count - 1].Exit))
                { prepared = definition; break; }
        if (prepared == null) { chance = 0; return true; }

        // Reuse the normal bounded, cached exfil search. Pending is not evidence of no exit.
        var ordinary = FindNearestEligibleExfil(squad);
        if (ExfilSearchPending(squad)) return false;
        var ordinaryRoute = CompleteExfilRouteLength(squad, ordinary);
        var preparedEstimate = OperationPlan.RemainingDistance(prepared, squad.Leader.Position);
        chance = PreparedExtractionChoice.Chance(personalityChance, ServerConfig.MultiStep.CustomsExtractionMultiplier,
            ServerConfig.MultiStep.CustomsNearbyExitDistance, ordinaryRoute, preparedEstimate);
        Log.Info($"MULTISTEP EXTRACT CHOICE: {squad} map={_mapId} ordinary={ordinary?.Name ?? "none"} route={ordinaryRoute:F1}m preparedEstimate={preparedEstimate:F1}m baseChance={personalityChance:F3} chance={chance:F3}");
        return true;
    }

    internal bool TryOperationPoint(Agent actor, OperationStep step, OperationRouteSearch search,
        out Vector3 point, out bool final, int expansion, IReadOnlyList<Vector3> history)
    {
        var target = step.Position;
        if (step.Kind == OperationStepKind.Access)
        {
            var interaction = step.Object.GetInteractionParameters(actor.Position);
            target = interaction.InteractionPosition;
            // Native door/reader standing points inherit the caller's height. Keep the
            // selected side, but search at the actual handle/reader elevation so stairs
            // remain eligible. Ground sampling and final interaction checks stay separate.
            target.y = interaction.ViewTarget.y;
        }
        else if (step.Kind == OperationStepKind.Switch)
            target = step.SwitchApproach ?? OperationSwitchReach.TargetPosition(step.Object);
        // If another squad already powered D2, approach the bunker entry before restricting travel.
        // Reaching this anchor must never activate the distant gate button.
        var entering = step.Underground && !OperationRoutePolicy.InD2Bunker(actor.Position);
        if (entering) target = step.Entry;
        var found = search.Find(actor.Position, target, out point, out final, expansion, history, floorAware: true,
            allowedPoint: step.Underground && !entering ? OperationRoutePolicy.D2 : null,
            finalPoint: step.Kind is OperationStepKind.Switch or OperationStepKind.Access && !entering ? step.InteractionCheck : null,
            localAccess: step.Kind is OperationStepKind.Switch or OperationStepKind.Access && !entering,
            groundedTarget: step.Kind == OperationStepKind.Switch && step.SwitchApproach.HasValue && !entering);
        if (entering) final = false;
        return found;
    }

    internal Door OperationAccessDoor(Agent actor, OperationStep step, ISet<Door> attempted = null)
    {
        if (step.Kind != OperationStepKind.Switch || _rushDoors == null) return null;
        Door nearest = null;
        var gap = 16f;
        foreach (var door in _rushDoors.Values)
        {
            if (door == null || attempted?.Contains(door) == true || door.GetType() != typeof(Door) || !door.Operatable
                || door.DoorState != EDoorState.Shut || door.InteractingPlayer != null
                || !MultiStepAccess.CanForceUnlock(door)
                || (door.transform.position - step.Position).sqrMagnitude > 144f) continue;
            var distance = (actor.Position - door.transform.position).sqrMagnitude;
            if (distance >= gap || !OperationSwitchReach.CanReach(actor.Position, door)) continue;
            nearest = door; gap = distance;
        }
        return nearest;
    }

    internal Waypoint OperationLoot(Agent agent, Vector3 center, HashSet<int> attempted, out bool exhausted, float radius = 15f,
        MarkedRoomScope room = null)
    {
        exhausted = true;
        var coords = WorldToCell(center);
        var paths = 0;
        var cellRadius = Mathf.Max(1, Mathf.CeilToInt(radius / _cellSize));
        for (var x = Mathf.Max(0, coords.x - cellRadius); x <= Mathf.Min(_gridSize.x - 1, coords.x + cellRadius); x++)
        for (var y = Mathf.Max(0, coords.y - cellRadius); y <= Mathf.Min(_gridSize.y - 1, coords.y + cellRadius); y++)
            foreach (var point in _cells[x, y].Waypoints)
            {
                if (point.Category is not (WaypointCategory.ContainerLoot or WaypointCategory.LooseLoot)
                    || (point.Position - center).sqrMagnitude > radius * radius || Mathf.Abs(point.Position.y - center.y) > 2.5f
                    || room != null && !room.Contains(point.Position)
                    || room != null && !MarkedLootRemains(point)
                    || attempted.Contains(point.Id) || room == null && agent.Squad.CompletedPoiIds.Contains(point.Id)
                    || !Orbit.Tasks.Actions.GotoObjectiveAction.IsLootableForAgent(agent, point)) continue;
                // A competing looter is not evidence that the room has been emptied.
                if (IsClaimedByOther(point.Id, agent.Id)) { if (room != null) exhausted = false; continue; }
                if (++paths > 3) { exhausted = false; return null; }
                if (NavMesh.CalculatePath(agent.Position, point.Position, NavMesh.AllAreas, _operationPath)
                    && _operationPath.status == NavMeshPathStatus.PathComplete
                    && (room == null || room.ContainsPath(_operationPath.corners)) && TryClaim(point.Id, agent.Id)) return point;
                attempted.Add(point.Id);
            }
        return null;
    }

    private bool MarkedLootRemains(Waypoint point)
    {
        if (point.Category == WaypointCategory.LooseLoot) return !IsUnavailableLooseLoot(point);
        if (point.Target is not LootableContainer container) return false;
        if (container.ItemOwner?.RootItem is not EFT.InventoryLogic.CompoundItem root) return false;
        if (root.Slots != null)
            foreach (var slot in root.Slots)
                if (slot?.ContainedItem != null) return true;
        if (root.Grids != null)
            foreach (var grid in root.Grids)
                if (grid?.Items != null)
                    foreach (var item in grid.Items)
                        if (item != null) return true;
        return false;
    }

    internal int RemainingMarkedLoot(MarkedRoomScope room)
    {
        var count = 0;
        var coords = WorldToCell(room.Center);
        var radius = Mathf.Max(1, Mathf.CeilToInt(room.Radius / _cellSize));
        for (var x = Mathf.Max(0, coords.x - radius); x <= Mathf.Min(_gridSize.x - 1, coords.x + radius); x++)
        for (var y = Mathf.Max(0, coords.y - radius); y <= Mathf.Min(_gridSize.y - 1, coords.y + radius); y++)
            foreach (var point in _cells[x, y].Waypoints)
                if (room.Contains(point.Position) && MarkedLootRemains(point)) count++;
        return count;
    }
}
