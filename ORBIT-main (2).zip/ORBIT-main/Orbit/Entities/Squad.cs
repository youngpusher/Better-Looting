using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Orbit.Helpers;
using Orbit.Navigation;
using Orbit.Sain;
using UnityEngine;

namespace Orbit.Entities;

/// <summary>
/// A coordinated bot group. Holds its member list, the current shared objective, per-squad caches
/// (blacklists, cooldowns, door-roll history) and the long-term goals rolled at squad creation.
/// </summary>
public class Squad(int id, float[] taskScores, int targetMembersCount) : Entity(id, taskScores)
{
    public readonly List<Agent> Members = new(6);
    public readonly SquadObjective Objective = new();
    internal bool PendingDispatchCompletedCurrent;
    internal readonly Orbit.Systems.TravelHold TravelHold = new();
    internal readonly Orbit.Systems.CorpseEscort CorpseEscort = new();
    internal readonly Orbit.Systems.BossRushLoot BossLoot = new();
    internal readonly Orbit.Systems.CampPlan Camp = new();
    internal Orbit.Systems.OperationPlan Operation;
    internal Orbit.Systems.RushPlan Rush;
    internal readonly Orbit.Systems.MainObjectiveApproach MainApproach = new();
    internal bool OperationExtractRolled;
    internal bool OperationExtractCommitted;
    internal float OperationExtractRetryAt;
    internal readonly HashSet<string> FailedOperationExits = new();
    public readonly int TargetMembersCount = targetMembersCount;

    /// <summary>
    /// POIs this squad considers permanently done. Populated when:
    ///   - LootContainerAction successfully loots a ContainerLoot or Corpse.
    ///   - A LooseLoot pickup attempt yielded nothing (filtered by value
    /// threshold etc) and the item is still in the world.
    ///   - The squad reaches a Quest POI (the trigger was hit).
    /// LooseLoot actually picked up goes through RemoveWaypoint globally instead; it never lands here.
    /// Filtered out in PickFromCell — a hard constraint that survives the fallback re-pick relaxations.
    /// </summary>
    public readonly HashSet<int> CompletedPoiIds = new();

    /// <summary>
    /// PMC-only loot cooldown: cell coords → expiry time. Armed when a PMC squad *leaves* a cell where it
    /// picked loot. For the next 10 min, loot POIs in that cell are skipped for this squad. The squad CAN
    /// still enter the cell for Quest / Synthetic / Exfil POIs, and a runtime loot POI (fresh kill) lifts the
    /// cooldown for that cell automatically. Scavs are exempt — they wander, revisiting is fine.
    /// </summary>
    public readonly Dictionary<Vector2Int, float> LootCellCooldowns = new();

    /// <summary>
    /// For cells whose POIs span multiple floors, the Y coordinate of the floor this squad has currently
    /// committed to cleaning. PickFromCell filters candidates to that floor (within SameFloorLootYTolerance)
    /// so the squad finishes one floor before moving to the next instead of yo-yoing between them. Initialised
    /// to a random floor on first entry so the cleaning order varies between bots / raids.
    /// </summary>
    public readonly Dictionary<Vector2Int, float> CellFloorAssignments = new();

    /// <summary>
    /// Cell where this squad most recently picked a loot POI. Used to detect "left the cell" — when the
    /// squad's next pick lands in a different cell, the previous one is armed in LootCellCooldowns.
    /// </summary>
    public Vector2Int? LastLootCell;

    /// <summary>
    /// Cell the leader occupied at the previous strategy tick. Drives the rolling unreachability-cache
    /// refresh: when this changes, the strategy re-evaluates per-squad unreachable verdicts in the 3x3 cell
    /// window around the new cell (stale verdicts cached from spawn become wrong once the leader has moved).
    /// </summary>
    public Vector2Int? LastKnownCell;

    /// <summary>
    /// Per-cell timestamp of the most recent unreachability refresh for this squad. Skips cells already
    /// refreshed within the configured cooldown — without this dedup, a leader oscillating between two
    /// adjacent cells would re-clear every POI in their shared 3x3 neighbours on every transition.
    /// </summary>
    public readonly Dictionary<Vector2Int, float> RecentlyRefreshedCells = new();

    /// <summary>
    /// Cell coordinates where this squad's leader spawned. Used by supported non-PMC factions that fail
    /// their roaming roll — biases prefDirection back toward home so they stay in their spawn quartier
    /// even when chained loot neighbour-hops would otherwise drift them across the map. Lazy init: null
    /// until the first RequestNear call, then frozen for the rest of the raid.
    /// </summary>
    public Vector2Int? SpawnCell;

    /// <summary>
    /// Per-raid roll controlling whether this supported non-PMC squad may leave its spawn area and
    /// use the map-wide waypoint fallback. Null until first dispatch; does not control ORBIT
    /// enrollment. (Community PR #18 by Andrewgdewar.)
    /// </summary>
    public bool? AreaRoamingAllowed;

    /// <summary>
    /// True once any member has crossed their faction's extract-at-loot- value threshold. From then on the
    /// dispatcher bypasses normal POI selection and routes the squad straight to the nearest eligible exfil.
    /// One-way flag — stays true for the rest of the raid.
    /// </summary>
    public bool ExtractRequested;
    internal Orbit.Tasks.LootExtractSweep LootExtractSweep;

    /// <summary>
    /// Earliest next sleep after a wake, and last sleep entry. Stored on the squad because ids
    /// are recycled; a replacement squad must not inherit its predecessor's cooldown.
    /// </summary>
    public float DormancySleepAllowedAt = -999f;
    public float DormancySleptAt = -999f;

    /// <summary>Time.time until which this squad is pinned in a simulated ghost fight — ghost movement
    /// holds position for the window (you don't walk your route mid-firefight).</summary>
    public float GhostFightUntil = -999f;

    /// <summary>Ghost hearing: where the sleeping squad decided to go and look after hearing a firefight.
    /// Set by DormancySystem, consumed (and cleared) by GotoObjectiveStrategy on its next tick.</summary>
    public Vector3? InvestigateNoisePosition;
    internal float InvestigateNoiseExpiresAt;

    /// <summary>Time.time of the last noise this squad reacted to, paces the next reaction.</summary>
    public float LastNoiseReactionAt = -999f;

    /// <summary>
    /// Short human-readable string describing WHY this squad flipped
    /// <see cref="ExtractRequested"/>. Set at the same moment the flag
    /// goes true; null/empty until then. Surfaced to raid-review.
    /// </summary>
    public string ExtractRequestedReason;

    /// <summary>
    /// Per-squad randomization factor (0.75 - 1.25, set at squad creation) applied to the
    /// extract-at-loot-value threshold so two same-faction squads in the same raid don't both flip at the
    /// exact same rouble count.
    /// </summary>
    public float ExtractValueRandomization = 1f;

    /// <summary>
    /// How many consecutive times AssignNewObjective came back null (no eligible POI anywhere reachable from
    /// this squad). Reset whenever a member actually reaches an objective. Past a small threshold the squad
    /// is treated as 'islanded' and pinned to its current cell so it stops ping-ponging unreachable
    /// objectives.
    /// </summary>
    public int ConsecutiveDispatchFailures;
    public float NextDispatchAttemptAt;
    public bool FailedDispatchWasExtract;
    public Vector3 FailedDispatchPosition;

    /// <summary>
    /// How many consecutive times every squad member arrived at the "all members failed their objective
    /// en-route" branch. Distinct from
    /// <see cref="ConsecutiveDispatchFailures"/> which counts null returns
    /// from RequestNear. Past the blacklist threshold the squad blacklists the POI for itself and
    /// re-dispatches normally — no teleport rescue.
    /// </summary>
    public int ConsecutiveFailedDispatches;

    /// <summary>
    /// Per-Synthetic-POI short-term visit cooldown (loc.Id → expiry time). Synthetic POIs are patrol fillers
    /// with no natural "done" semantics; without this guard a squad whose own cell only contained one
    /// Synthetic could ping-pong on it forever between wait timers.
    /// </summary>
    public readonly Dictionary<int, float> RecentlyVisitedPoiCooldowns = new();

    /// <summary>
    /// Time-left-in-raid (in seconds) at which this squad will flip ExtractRequested even without hitting the
    /// loot-value trigger. Rolled lazily on first check; faction- and map-dependent.
    /// <see cref="float.NaN"/> = not yet rolled. Other factions never roll
    /// one (they're not allowed to extract).
    /// </summary>
    public float TimeExtractThresholdSeconds = float.NaN;

    /// <summary>
    /// Long-term goals assigned at squad creation, 1-5 entries (or 0 if the squad is a boss/raider — they
    /// skip the system entirely). Execution is opportunistic: the force-attraction sums inverse- distance
    /// pulls toward every pending main, closest naturally dominating. When every main is Completed, the squad
    /// flips
    /// <see cref="ExtractRequested"/>.
    /// </summary>
    public List<MainObjective> MainObjectives;

    // ── Combat convergence (active during Kills roam / LootValue) ──
    /// <summary>Index in <see cref="Members"/> of the squad member who
    /// most recently triggered combat detection. -1 = no caller active.</summary>
    public int CombatCallerMemberIdx = -1;

    /// <summary><see cref="Time.time"/> of the last combat detection.
    /// Used for the 5-second grace before clearing the caller state.</summary>
    public float CombatCallerLastSeenAt;

    /// <summary>Position captured when the combat caller was detected.
    /// Stable anchor — even if the caller moves, others converge on where they first saw the
    /// threat.</summary>
    public Vector3 CombatCallerPosition;

    /// <summary>
    /// Objective the squad was on when an opportunistic corpse loot interrupted it. Null when no interrupt is
    /// in progress. Restored to
    /// <see cref="SquadObjective.Location"/> when the interrupting loot
    /// finishes, then cleared.
    /// </summary>
    public Waypoint PreInterruptObjectiveLocation;

    /// <summary>
    /// Time.time of the last opportunistic-corpse scan run for this squad. Paces the scan (it's an O(members
    /// × nearby corpses) raycast loop, so we don't want to fire every frame). 0 = never run.
    /// </summary>
    public float LastOpportunisticCorpseScanTime;

    /// <summary>
    /// Corpse-stuck watchdog: if the same corpse stays the objective past the timeout without completing, the
    /// strategy blacklists it and re-dispatches so the squad doesn't sit on it forever. (-1 = no corpse.)
    /// </summary>
    public int CorpseWatchdogLocId = -1;
    public float CorpseWatchdogSince;

    /// <summary>
    /// World position where this squad's leader spawned (captured once at squad creation). Used by the
    /// waypoint system to derive an Infiltration name from the closest SpawnPointMarker when the bot's
    /// <c>Profile.Info.EntryPoint</c> is empty — covers PMC bots spawned
    /// by faction mods (Legion / UNTAR / RUAF) and special-spawn vanilla bots that BSG never assigns an entry
    /// to.
    /// </summary>
    public Vector3 SpawnPosition;

    /// <summary>
    /// Set once the spawn-island rescue relocates a member off a disconnected spawn chunk. Squad-level state
    /// (unreachable cache, mains, current objective, SpawnPosition) is refreshed a single time even though
    /// every member teleports within the same frame.
    /// </summary>
    public bool SpawnIslandRelocated;

    /// <summary>
    /// Derived (or BSG-native) Infiltration name used for the spawn-side exfil filter. Computed lazily on
    /// first call when the bot's EntryPoint is empty. <see langword="null"/> = not yet resolved; empty string
    /// = resolved but no marker found.
    /// </summary>
    public string DerivedEntryPoint;
    public bool ExfilEligibilityLogged;

    // Short-TTL cache for FindNearestEligibleExfil: that scan now path-checks every candidate and the
    // extract-interrupt gate polls it each tick, so the verdict is cached. Null = no reachable exfil last eval.
    public Waypoint NearestExfilCached;
    public float NearestExfilCachedAt = float.NegativeInfinity;

    /// <summary>
    /// SAIN-resolved personality archetype for this squad's leader, captured once at squad registration.
    /// Unused for non-PMC squads. Defaults to Average when SAIN is missing or the brain doesn't resolve.
    /// </summary>
    public PersonalityArchetype Archetype;

    /// <summary>
    /// Per-squad rolled values from the archetype's F12 table — extract threshold, loot coverage %, sweep /
    /// splinter radii, etc. Null for scavs / PlayerScavs (they always use the global Orbit knobs even when
    /// SAIN personality is enabled).
    /// </summary>
    public PersonalityProfile Personality;

    /// <summary>
    /// True until SAIN has attached its BotComponent for this leader and we've resolved the personality +
    /// rolled the PersonalityProfile. SAIN attaches asynchronously after spawn (typical 1-2s), so the initial
    /// registration usually returns null on the brain lookup. After <see cref="SainResolveDeadline"/> we lock
    /// to Average and stop polling.
    /// </summary>
    public bool SainResolutionPending;

    /// <summary>
    /// <see cref="Time.time"/> by which the SAIN personality must be
    /// resolved or the squad locks to Average. Defaults to the squad's first-tick time + the configured retry
    /// window (5 s — empirically enough for SAIN to attach).
    /// </summary>
    public float SainResolveDeadline;

    /// <summary>
    /// Persistent virtual rally waypoint for the current combat caller. Recreated only once the caller has
    /// moved >8m from it — a fresh instance per tick broke reference alignment and re-dispatched every
    /// supporter every tick for the whole fight.
    /// </summary>
    public Waypoint CombatCallerWaypoint;

    /// <summary>
    /// ProfileId of a squad member who just died WITH meaningful loot — the surviving members should
    /// bee-line to their corpse to recover the goods (their kit dropped with them). Set in
    /// LootContainerAction.ReevaluateExtractOnDeath when a loot-threshold extract gets cancelled by the
    /// death. Consumed by CorpseRegistrationPatch when the matching Corpse waypoint registers (timing:
    /// BSG instantiates the corpse a few frames AFTER the agent is removed from the squad). Null = no
    /// pending recovery.
    /// </summary>
    public string PendingDeadMemberRecoveryProfileId;

    /// <summary>
    /// The dead member's <see cref="OrbitLootHandler.Stats.TotalGained"/> at the moment of death — logged
    /// when the corpse-recovery dispatch fires so the rationale is visible in the raid log. 0 when no
    /// recovery is pending.
    /// </summary>
    public float PendingDeadMemberRecoveryValue;

    /// <summary>
    /// Door instance IDs this squad is authorised to force-unlock on arrival, bypassing the BSG key-inventory
    /// check. Populated when a picked POI has locked doors on its path: each door is rolled against an unlock
    /// probability (100% if the POI is the squad's current Main anchor, F12-config probability otherwise).
    /// </summary>
    public readonly HashSet<int> ForceUnlockDoorIds = new();

    /// <summary>
    /// Doors this squad opened a navmesh carver on that are still Locked. The carver is re-closed (navmesh cut
    /// restored, so bots route AROUND instead of phasing through) once the squad stops actively heading behind
    /// the door — combat retreat or re-dispatch elsewhere. A door is dropped from here once it's actually
    /// unlocked/opened (BSG then owns its navmesh).
    /// </summary>
    public readonly List<EFT.Interactive.Door> OpenCarverDoors = new();

    /// <summary>
    /// Door instance IDs the squad has previously rolled <em>and lost</em> the force-unlock dice on. Persists
    /// for the rest of the raid. Read by PickFromCell to filter POIs whose path crosses a failed door.
    /// Entries become inert if another squad unlocks the door world-wide (door state flips to Shut for
    /// everyone → filter no-ops).
    /// </summary>
    public readonly HashSet<int> FailedDoorUnlockIds = new();

    public Agent Leader;

    public int Size
    {
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        get => Members.Count;
    }

    public void AddAgent(Agent member) => Members.Add(member);

    public void RemoveAgent(Agent member) => Members.SwapRemove(member);

    public override string ToString() => $"Squad(id: {Id})";
}
