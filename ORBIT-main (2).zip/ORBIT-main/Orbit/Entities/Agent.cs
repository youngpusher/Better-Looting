using System.Collections.Generic;
using System.Runtime.CompilerServices;
using EFT;
using EFT.InventoryLogic;
using Orbit.Navigation;
using UnityEngine;

namespace Orbit.Entities;

/// <summary>
/// One bot. Holds the BotOwner / Player handles, the cached body transform for cheap <see cref="Position"/>
/// reads, and one instance of every per-agent component (Movement, Stuck, Look, Objective, Guard) — those
/// live on the Agent rather than in side arrays because every agent has exactly one of each. <see
/// cref="Squad"/> is set after squad assignment;
/// <see cref="IsLeader"/> is mirrored from the squad's first-member position
/// for fast lookups inside per-tick loops.
/// </summary>
public class Agent(int id, BotOwner bot, float[] taskScores) : Entity(id, taskScores)
{
    public bool IsActive;
    public bool IsLeader;
    public Squad Squad;

    /// <summary>
    /// AI-limiter dormancy: the bot's GameObject is disabled (no BSG/SAIN cost) while ORBIT keeps thinking
    /// for it. Set exclusively by DormancySystem, squad-atomically. Dormant agents keep IsActive=true —
    /// dispatch and strategies continue; only the body-level systems (mover, look, doors, loot animations)
    /// branch on this flag.
    /// </summary>
    public bool IsDormant;
    internal Orbit.Looting.OrbitLootHandler LootHandler;

    /// <summary>Ghost gear swaps. A sleeper changes its equipment through inventory transactions only: the
    /// hands controller cannot run on an inactive body, so the weapon in hands is never touched while asleep.
    /// <see cref="GhostHandsResync"/> asks the wake resync to refresh the weapon selector and redraw the main
    /// weapon. <see cref="GhostPendingPromotion"/> is a better weapon parked in the second primary slot,
    /// waiting for the slot1/slot2 swap, which moves the weapon in hands and is done at the next AWAKE loot
    /// session. <see cref="GhostBestWeapon"/> is what the sleeper fights with in simulated fights meanwhile.</summary>
    public bool GhostHandsResync;
    internal bool GhostHandsDrawPending;
    internal float GhostHandsRetryAt;

    /// <summary>Diagnostic timer for inventory operations preventing sleep, -1 when none.
    /// An expired timer never releases an operation that is still pending.</summary>
    public float InventoryBusySince = -1f;
    public Weapon GhostPendingPromotion;
    public Weapon GhostBestWeapon;

    /// <summary>Total HP captured at sleep entry. The dormancy poll wakes the squad the moment current HP
    /// drops below this (mines and other position-based damage still land on inactive bodies, and a
    /// sleeper can't heal — observed bleeding out over 10 minutes in the limiter test raid).</summary>
    public float DormantHpBaseline;

    /// <summary>Awake-side HP drop tracker (DormancySystem): last polled total HP and the Time.time of the
    /// last observed drop. A squad with a recent drop (active bleed, fresh wound) never sleeps — re-sleeping
    /// a bleeder before SAIN finished healing created a lethal wake/sleep loop in the second test raid.</summary>
    public float LastPollHp;
    public float LastHpDropTime = -999f;

    /// <summary>Time.time of the last simulated patch-up (DormancySystem): a far, out-of-combat bot whose HP
    /// keeps dropping gets its negative effects stripped so the bleed gate can clear and it can sleep.</summary>
    public float LastGhostPatchUpAt = -999f;

    public readonly string BotCategory = Orbit.Helpers.ZoneBotType.For(bot);
    public readonly BotOwner Bot = bot;
    public readonly Player Player = bot.Mover._player;

    public readonly Movement Movement = new();
    public readonly Stuck Stuck = new();
    public readonly Look Look = new();

    public readonly Objective Objective = new();
    internal float NextAirdropScanAt;
    public readonly Guard Guard = new();

    public readonly ArrivalFailureHistory ArrivalFailures = new();
    internal readonly Systems.QuestArrival QuestArrival = new();
    internal Systems.SniperReturnRecovery SniperReturn;
    internal float NextSniperRelocationDiagnosticAt;

    /// <summary>
    /// Corpses credited to this agent, kept across combat and normal extraction detours.
    /// Dispatch removes definitive skips/completions and retries temporary claims or path failures.
    /// </summary>
    public readonly List<int> OwnKillCorpseIds = new(4);

    /// <summary>
    /// POI id this agent is currently failing arrival on because Physics.Raycast LoS is blocked (within the
    /// arrival radius but a wall sits between bot and target). -1 = not tracking. Together with <see
    /// cref="LoSBlockedSinceTime"/> this drives a time-based blacklist for Quest waypoints whose target
    /// position sits inside a wall — the standard TrackArrivalFailure counter never fires there because the
    /// bot keeps "moving" instead of stopping.
    /// </summary>
    public int LoSBlockedPoiId = -1;

    /// <summary>Time.time at which the current LoS-blocked tracking window started. -1 = not tracking.</summary>
    public float LoSBlockedSinceTime = -1f;

    /// <summary>
    /// Time.time at which the agent entered GuardAction with a loot POI as their objective but WITHOUT
    /// transitioning through Looting status first. -1 = not tracking. Drives the scavenge-sweep stuck
    /// watchdog: a scavenge sweep chains to a nearby POI but the arrival check (1m radius + LoS raycast)
    /// fails — the agent falls into GuardAction by default, status stays None, and the squad's alignment
    /// check sees the objective already matches → no re-dispatch ever. The watchdog times out after
    /// <c>GuardOnLootPoiTimeoutSeconds</c> and blacklists the chain target so the next dispatch picks a
    /// different POI. Cleared when the agent leaves GuardAction or actually starts Looting.
    /// </summary>
    public float GuardOnLootPoiSinceTime = -1f;

    /// <summary>
    /// Doors this agent has opened recently. Capped at the most recent N entries. Consulted by the
    /// "close doors behind me" remediation when the agent gets hard-stuck or starts churning across
    /// multiple POIs — open doors swinging into corridors can wedge a bot's nav off the mesh, and
    /// closing them gives the next path recalc a clean cross-section to work with. Closing fires only
    /// on those remediation signals, never on a timer; an agent that's making progress never closes
    /// anything.
    /// </summary>
    public readonly List<EFT.Interactive.Door> RecentOpenedDoors = new();

    /// <summary>
    /// Time.time of the last few per-agent POI blacklist firings (3-fail arrival blacklist or
    /// guard-on-loot-POI watchdog). Used by the close-doors-behind remediation to detect "rapid
    /// switching across MULTIPLE different POIs" — the per-POI 3-fail counter resets between POIs, so
    /// the rapid cross-POI pattern (blacklist POI A, switch to POI B, blacklist B, etc.) never piles up
    /// on any one counter and the door-close never triggers. This timestamp ring lets us see the
    /// across-POI churn explicitly.
    /// </summary>
    public readonly List<float> RecentPoiBlacklistTimes = new();

    /// <summary>
    /// This agent's own extract-loot threshold, rolled from their OWN SAIN brain's archetype range (for PMCs)
    /// or set to the faction-default global knob (PlayerScavs). 0 = not yet resolved (SAIN async attach still
    /// pending, or just never tried). Resolved lazily inside the loot routine the first time the squad's loot
    /// crosses the relevant threshold. The squad-wide extract trigger sums alive members' resolved thresholds
    /// — a mixed Rat+Chad squad needs Rat-range + Chad-range total, not 2× the leader's range. Death of a
    /// member drops their contribution; the surviving members' summed threshold becomes the new bar.
    /// </summary>
    public float OwnExtractLootThreshold;

    /// <summary>
    /// Solo extract: this member peels off to extract on its own while the squad keeps playing. Two triggers: an
    /// emergency (wounded with no usable meds left) and the per-member loot threshold (gated by a one-time roll).
    /// </summary>
    public bool SoloExtractRequested;
    public string SoloExtractReason;
    public Orbit.Navigation.Waypoint SoloExtractTarget;
    public bool SoloLootThresholdRolled;
    internal Orbit.Tasks.LootExtractSweep LootExtractSweep;

    /// <summary>
    /// HP-trend emergency-extract state. An HP-triggered solo extract can be cancelled if HP recovers (unlike a
    /// loot-threshold one): once HP stops hitting new lows (tracked by EmergencyHpLow/EmergencyHpLowTime) and is
    /// back above the danger floor, the bleed is over and the member rejoins.
    /// </summary>
    public bool SoloExtractIsEmergency;
    public float EmergencyHpLow;
    public float EmergencyHpLowTime;
    /// <summary>Time.time HP first dropped below the stagnant-low floor and stayed there (-1 = above floor),
    /// driving the "stuck below the floor for too long" emergency trigger.</summary>
    public float EmergencyLowSince = -1f;
    /// <summary>Rolling HpFraction samples (ring buffer indexed <c>EmergencyHpHistCount % Length</c>) with their
    /// Time.time, used by the trend test to tell an ongoing bleed from a single hit that then stabilised.</summary>
    public readonly float[] EmergencyHpHist = new float[32];
    public readonly float[] EmergencyHpHistTime = new float[32];
    public int EmergencyHpHistCount;
    /// <summary>Emergency-extract watchdog: force-extract fires when the bot sits stuck at the exfil (not
    /// extracting, not in combat) past the timeout.</summary>
    public float EmergencyExtractStillSince;
    public UnityEngine.Vector3 EmergencyExtractLastPos;

    /// <summary>
    /// Per-archetype mini-loot value threshold, lazily resolved from the agent's own SAIN brain. 0 until
    /// resolved; falls back to the squad personality (or <see
    /// cref="OrbitLootHandler.DefaultMinPickupPrice"/>) when SAIN attach is pending.
    /// </summary>
    public float OwnMiniLootValueThreshold;

    /// <summary>
    /// POIs this agent has personally value-rejected. Filtered against in dispatch and sweep so the agent
    /// isn't sent back, while softer-gated squad members can still be dispatched (squad-level
    /// <see cref="Squad.CompletedPoiIds"/> is untouched).
    /// </summary>
    public readonly HashSet<int> ValueSkippedPoiIds = new();

    private readonly BifacialTransform _bodyTransform = bot.Mover._player.PlayerBones.BodyTransform;

    public Vector3 Position
    {
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        get => _bodyTransform.position;
    }

    public override string ToString()
    {
        return $"Agent(Id: {Id}, BsgId: {Bot.Id}, Name: {Bot.Profile.Nickname})";
    }
}
