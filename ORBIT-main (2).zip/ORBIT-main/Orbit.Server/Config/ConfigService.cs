using System.Text.Json;
using System.Text.Json.Serialization;
using SPTarkov.Common.Models.Logging;
using SPTarkov.DI.Annotations;

namespace Orbit.Server.Config;

/// <summary>
/// Editable global settings and their saved baseline. PresetService selects detached copies and
/// persists settings together with zones. Legacy config.json loading remains the fallback if the
/// preset library cannot load. Unknown fields are ignored; absent settings use compiled defaults.
/// </summary>
[Injectable(InjectionType.Singleton)]
public class ConfigService(ISptLogger<ConfigService> logger)
{
    private static readonly JsonSerializerOptions _jsonOptions = new()
    {
        WriteIndented = true,
        PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower,
        DefaultIgnoreCondition = JsonIgnoreCondition.Never,
    };

    public OrbitServerConfig Config { get; private set; } = new();

    public string ModDirectory { get; init; } = Path.GetDirectoryName(typeof(ConfigService).Assembly.Location)!;

    // Serialized snapshot of the config as last loaded/saved — the baseline the web UI diffs against
    // to surface unsaved changes. Normalized through the same serializer options as ToJson().
    private string? _savedJson;

    private string ConfigPath
    {
        get
        {
            return Path.Combine(ModDirectory, "config.json");
        }
    }

    public void Load()
    {
        try
        {
            if (File.Exists(ConfigPath))
            {
                var parsed = JsonSerializer.Deserialize<OrbitServerConfig>(NormalizeJson(File.ReadAllText(ConfigPath)), _jsonOptions);
                if (parsed != null)
                {
                    Config = parsed;
                    _savedJson = ToJson();
                    logger.Info($"[ORBIT] Server config loaded ({ConfigPath})");
                    return;
                }
            }
            Save();
            logger.Info($"[ORBIT] Server config created with defaults ({ConfigPath})");
        }
        catch (Exception ex)
        {
            logger.Error($"[ORBIT] Failed to load server config, using defaults: {ex.Message}");
            Config = new OrbitServerConfig();
            _savedJson = ToJson();
        }
    }

    public void Save()
    {
        BehaviorValidation.Validate(Config);
        var json = JsonSerializer.Serialize(Config, _jsonOptions);
        File.WriteAllText(ConfigPath, json);
        _savedJson = json;
        logger.Info("[ORBIT] Server config saved");
    }

    public string ToJson() => JsonSerializer.Serialize(Config, _jsonOptions);

    public string SavedJson => _savedJson ?? ToJson();
    public static string DefaultJson => JsonSerializer.Serialize(new OrbitServerConfig(), _jsonOptions);

    // Old exports can omit settings introduced later. Merge them with the current defaults, while
    // rejecting null sections and incompatible types before replacing a working configuration.
    public static string NormalizeJson(string json)
    {
        var defaults = System.Text.Json.Nodes.JsonNode.Parse(DefaultJson)!;
        var supplied = System.Text.Json.Nodes.JsonNode.Parse(json) as System.Text.Json.Nodes.JsonObject
            ?? throw new InvalidDataException("The config must be a JSON object.");
        if (supplied["config_version"] is { } version && version.GetValue<int>() > new OrbitServerConfig().ConfigVersion)
            throw new InvalidDataException("This config requires a newer ORBIT version.");
        // Map ids are dynamic keys; their nullable leaves explicitly mean inheritance.
        if (supplied.TryGetPropertyValue("map_overrides", out var maps))
        {
            if (maps is not System.Text.Json.Nodes.JsonObject)
                throw new InvalidDataException("Map overrides must be an object.");
            defaults["map_overrides"] = maps.DeepClone();
            supplied.Remove("map_overrides");
        }
        // Rush catalogues contain authored map/variant keys and complete point lists.
        // Do not drop new variants or restore deleted points through the fixed-setting merge.
        if (supplied["rush"] is System.Text.Json.Nodes.JsonObject rush
            && rush.TryGetPropertyValue("maps", out var rushMaps))
        {
            if (rushMaps is not System.Text.Json.Nodes.JsonObject)
                throw new InvalidDataException("Rush maps must be an object.");
            defaults["rush"]!["maps"] = rushMaps.DeepClone();
            rush.Remove("maps");
        }
        Merge(defaults, supplied);
        var upgradeSniper = supplied["rush"] is System.Text.Json.Nodes.JsonObject savedRush
            && savedRush["sniper_catalogue_version"] == null;
        var parsed = JsonSerializer.Deserialize<OrbitServerConfig>(defaults.ToJsonString(), _jsonOptions)
            ?? throw new InvalidDataException("Empty config.");
        if (upgradeSniper) Orbit.Settings.SniperDefaults.AddTo(parsed.Rush.Maps);
        parsed.Rush.SniperCatalogueVersion = 1;
        BehaviorValidation.Validate(parsed);
        parsed.ConfigVersion = new OrbitServerConfig().ConfigVersion;
        return JsonSerializer.Serialize(parsed, _jsonOptions);

        static void Merge(System.Text.Json.Nodes.JsonNode target, System.Text.Json.Nodes.JsonObject source)
        {
            foreach (var (key, value) in source)
            {
                if (target is not System.Text.Json.Nodes.JsonObject obj || !obj.ContainsKey(key)) continue;
                if (value == null) throw new InvalidDataException($"Config setting '{key}' cannot be null.");
                if (obj[key] is System.Text.Json.Nodes.JsonObject nested)
                {
                    if (value is not System.Text.Json.Nodes.JsonObject child)
                        throw new InvalidDataException($"Config section '{key}' must be an object.");
                    Merge(nested, child);
                }
                else obj[key] = value.DeepClone();
            }
        }
    }

    public void SelectSnapshot(string json)
    {
        var normalized = NormalizeJson(json);
        Config = JsonSerializer.Deserialize<OrbitServerConfig>(normalized, _jsonOptions)!;
        _savedJson = normalized;
        ConfigReplaced?.Invoke();
    }

    public void AcceptSnapshot(string json) => _savedJson = NormalizeJson(json);

    /// <summary>Raised when the config OBJECT is swapped out from under the pages (Discard all): their
    /// bindings point at the old instance, so they must re-render. Subscribed by OrbitConfigPage.</summary>
    public event Action? ConfigReplaced;

    /// <summary>
    /// Replaces the in-memory config with an imported JSON payload (the web UI's config import).
    /// Unknown fields are dropped, missing fields fall back to compiled defaults. The result lands as
    /// UNSAVED changes — it is diffed against the last saved snapshot so the user reviews then Saves.
    /// Throws on malformed JSON; returns false when the payload deserializes to nothing.
    /// </summary>
    public bool ImportJson(string json)
    {
        var parsed = JsonSerializer.Deserialize<OrbitServerConfig>(NormalizeJson(json), _jsonOptions);
        if (parsed == null) return false;
        Config = parsed;
        ConfigReplaced?.Invoke();
        return true;
    }

    /// <summary>Puts the in-memory config back to a previous state (undo / redo). No-op when it already is
    /// in that state, so a zone-only undo does not re-bind every config page.</summary>
    public void RestoreJson(string json)
    {
        if (json == ToJson()) return;
        var restored = JsonSerializer.Deserialize<OrbitServerConfig>(json, _jsonOptions);
        if (restored == null) return;
        Config = restored;
        ConfigReplaced?.Invoke();
    }

    /// <summary>Reverts the in-memory config to the last loaded/saved state (the web UI's "Discard all").</summary>
    public void DiscardChanges()
    {
        if (_savedJson == null) return;
        var restored = JsonSerializer.Deserialize<OrbitServerConfig>(_savedJson, _jsonOptions);
        if (restored == null) return;
        Config = restored;
        ConfigReplaced?.Invoke();
    }

    /// <summary>
    /// Leaf-level diff between the current config and the last saved snapshot, as (path, from, to)
    /// tuples with snake_case JSON paths. Empty when everything is saved. Drives the AppBar's
    /// "unsaved changes" button.
    /// </summary>
    public List<(string Path, string From, string To)> GetPendingChanges()
    {
        var result = new List<(string, string, string)>();
        if (_savedJson == null) return result;
        var current = ToJson();
        if (current == _savedJson) return result;

        using var oldDoc = JsonDocument.Parse(_savedJson);
        using var newDoc = JsonDocument.Parse(current);
        DiffElement(oldDoc.RootElement, newDoc.RootElement, "", result);
        return result;
    }

    private static void DiffElement(JsonElement a, JsonElement b, string path, List<(string, string, string)> result)
    {
        if (a.ValueKind == JsonValueKind.Object && b.ValueKind == JsonValueKind.Object)
        {
            foreach (var prop in b.EnumerateObject())
            {
                var childPath = path.Length == 0 ? prop.Name : $"{path}.{prop.Name}";
                if (a.TryGetProperty(prop.Name, out var oldValue))
                    DiffElement(oldValue, prop.Value, childPath, result);
                else
                    result.Add((childPath, "", Render(prop.Value)));
            }
            foreach (var prop in a.EnumerateObject())
                if (!b.TryGetProperty(prop.Name, out _))
                    result.Add((path.Length == 0 ? prop.Name : $"{path}.{prop.Name}", Render(prop.Value), "inherited"));
            return;
        }
        if (a.GetRawText() != b.GetRawText())
            result.Add((path, Render(a), Render(b)));
    }

    private static string Render(JsonElement el)
    {
        var s = el.ValueKind == JsonValueKind.String ? el.GetString() ?? "" : el.GetRawText();
        return s.Length > 28 ? s[..25] + "..." : s;
    }
}
