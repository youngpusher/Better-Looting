using System.Reflection;
using System.Text.Json;
using Orbit.Settings;
using SPTarkov.Common.Models.Logging;
using SPTarkov.DI.Annotations;

namespace Orbit.Server.Zones;

/// <summary>
/// Per-map editor working copies, native metadata and legacy zone-file migration. PresetService
/// supplies saved snapshots after initialization; zones/*.json remain compatibility copies.
/// Embedded defaults mirror the client's compiled-in zones. The client fetches the active preset's
/// maps via /orbit/zones at boot and raid start.
/// </summary>
[Injectable(InjectionType.Singleton)]
public partial class ZoneStoreService(ISptLogger<ZoneStoreService> logger)
{
    public string ModDirectory { get; init; } = Path.GetDirectoryName(typeof(ZoneStoreService).Assembly.Location)!;
    // ORBIT map ids (BSG location ids as the client sees them).
    public static readonly string[] MapIds =
    [
        "bigmap", "factory4_day", "factory4_night", "Interchange", "Interchange@rework", "laboratory", "Labyrinth",
        "Lighthouse", "Lighthouse@rework", "RezervBase", "Sandbox", "Sandbox_high", "Shoreline", "TarkovStreets", "Woods",
    ];

    public static readonly Dictionary<string, string> MapLabels = new()
    {
        ["bigmap"] = "Customs",
        ["factory4_day"] = "Factory (day)",
        ["factory4_night"] = "Factory (night)",
        ["Interchange"] = "Interchange",
        ["Interchange@rework"] = "Interchange (1.0 rework)",
        ["laboratory"] = "The Lab",
        ["Labyrinth"] = "Labyrinth",
        ["Lighthouse"] = "Lighthouse",
        ["Lighthouse@rework"] = "Lighthouse (1.0 rework)",
        ["RezervBase"] = "Reserve",
        ["Sandbox"] = "Ground Zero",
        ["Sandbox_high"] = "Ground Zero (21+)",
        ["Shoreline"] = "Shoreline",
        ["TarkovStreets"] = "Streets of Tarkov",
        ["Woods"] = "Woods",
    };

    /// <summary>"Interchange@rework" -> "Interchange": map reworks that keep BSG's location id are keyed
    /// "{id}@{variant}" (detected per raid by the client); the base id serves display-only data such as
    /// the baked BotZone positions.</summary>
    public static string BaseMapId(string mapId)
    {
        var at = mapId.IndexOf('@');
        return at < 0 ? mapId : mapId[..at];
    }

    // Client-contract serialization: exact member names (see ZoneModels.cs).
    private static readonly JsonSerializerOptions _json = new()
    {
        WriteIndented = true,
        PropertyNamingPolicy = null,
    };

    private string ZonesDir
    {
        get
        {
            return Path.Combine(ModDirectory, "zones");
        }
    }

    private string PathFor(string mapId) => Path.Combine(ZonesDir, mapId + ".json");

    /// <summary>Zones for one map: the saved file, seeded from the embedded default on first access.</summary>
    public MapZoneModel GetZones(string mapId)
    {
        lock (_working) return GetZonesLocked(mapId);
    }

    private MapZoneModel GetZonesLocked(string mapId)
    {
        if (_presetSaved != null) return NormalizeSnapshot(mapId, _presetSaved[mapId]);
        try
        {
            var path = PathFor(mapId);
            if (!File.Exists(path))
            {
                var seed = ReadEmbeddedDefault(mapId);
                NormalizeNativeFloors(mapId, seed);
                Directory.CreateDirectory(ZonesDir);
                File.WriteAllText(path, JsonSerializer.Serialize(seed, _json));
                return seed;
            }
            var loaded = JsonSerializer.Deserialize<MapZoneModel>(File.ReadAllText(path), _json) ?? new MapZoneModel();
            if (NormalizeNativeFloors(mapId, loaded))
            {
                try
                {
                    BackupBeforeNativeMigration(path);
                    Save(mapId, loaded);
                    logger.Info($"[ORBIT] ZONE MIGRATION: map={mapId} native floors updated; original retained in .pre-native-floors.bak");
                }
                catch (Exception ex)
                {
                    // A read-only install must not replace valid personal tuning with shipped defaults.
                    logger.Error($"[ORBIT] ZONE MIGRATION: map={mapId} save failed: {ex.Message}; migrated settings kept in memory");
                }
            }
            return loaded;
        }
        catch (Exception ex)
        {
            logger.Error($"[ORBIT] Zone load failed for {mapId}: {ex.Message}");
            return ReadEmbeddedDefault(mapId);
        }
    }

    public void Save(string mapId, MapZoneModel zones)
    {
        lock (_working)
        {
            NormalizeNativeFloors(mapId, zones);
            Directory.CreateDirectory(ZonesDir);
            var path = PathFor(mapId);
            File.WriteAllText(path + ".tmp", JsonSerializer.Serialize(zones, _json));
            File.Move(path + ".tmp", path, overwrite: true);
            logger.Info($"[ORBIT] Zones saved for {mapId}");
        }
    }

    /// <summary>Rewrites the map's file from the embedded default and returns the fresh model.</summary>
    public MapZoneModel ResetToDefault(string mapId)
    {
        var seed = ReadEmbeddedDefault(mapId);
        Save(mapId, seed);
        return seed;
    }

    /// <summary>The whole set as one JSON object keyed by map id — the /orbit/zones client payload.</summary>
    public string ToJsonAll()
    {
        var all = new Dictionary<string, MapZoneModel>();
        foreach (var mapId in MapIds)
            all[mapId] = GetZones(mapId);
        return JsonSerializer.Serialize(all, _json);
    }

    // ── Working set (web UI zone editor) ───────────────────────────────
    // The editor binds to these cached instances; the AppBar's global Save/Discard picks them up like
    // ConfigService changes, so the zone editor behaves exactly like every other config page.

    private readonly Dictionary<string, MapZoneModel> _working = new();
    private readonly Dictionary<string, string> _workingSavedJson = new();

    /// <summary>Raised when working copies are replaced from disk (Discard all / Reset) — the editor
    /// page re-binds. Mirrors ConfigService.ConfigReplaced.</summary>
    public event Action? ZonesReplaced;

    public MapZoneModel GetWorking(string mapId)
    {
        lock (_working)
        {
            if (_working.TryGetValue(mapId, out var working))
            {
                NormalizeNativeFloors(mapId, working);
                return working;
            }
            var loaded = GetZones(mapId);
            _working[mapId] = loaded;
            _workingSavedJson[mapId] = JsonSerializer.Serialize(loaded, _json);
            return loaded;
        }
    }

    /// <summary>Map ids whose working copy differs from the last save (for the unsaved-changes UI).</summary>
    public List<string> GetPendingMaps()
    {
        lock (_working)
        {
            var pending = new List<string>();
            foreach (var kv in _working)
            {
                if (_workingSavedJson.TryGetValue(kv.Key, out var saved)
                    && saved != JsonSerializer.Serialize(kv.Value, _json))
                    pending.Add(kv.Key);
            }
            pending.Sort(StringComparer.OrdinalIgnoreCase);
            return pending;
        }
    }

    public void SaveAllPending()
    {
        lock (_working)
        {
            foreach (var mapId in GetPendingMaps())
            {
                Save(mapId, _working[mapId]);
                _workingSavedJson[mapId] = JsonSerializer.Serialize(_working[mapId], _json);
            }
        }
    }

    public void DiscardAllPending()
    {
        lock (_working)
        {
            foreach (var mapId in GetPendingMaps())
            {
                var reloaded = GetZones(mapId);
                _working[mapId] = reloaded;
                _workingSavedJson[mapId] = JsonSerializer.Serialize(reloaded, _json);
            }
        }
        ZonesReplaced?.Invoke();
    }

    /// <summary>Reset is an ordinary unsaved edit, including while editing a protected preset.</summary>
    public MapZoneModel ResetWorkingToDefault(string mapId)
    {
        MapZoneModel seed;
        lock (_working)
        {
            GetWorking(mapId);
            seed = ReadEmbeddedDefault(mapId);
            _working[mapId] = seed;
        }
        ZonesReplaced?.Invoke();
        return seed;
    }

    // ── Sibling maps (same layout, separate zone file) ─────────────────

    /// <summary>Maps that share a layout with another one and are tuned in a separate file: Ground Zero and
    /// its 21+ twin, a vanilla map and its 1.0 rework. Both directions.</summary>
    private static readonly Dictionary<string, string> _siblings = new()
    {
        ["Sandbox"] = "Sandbox_high",
        ["Sandbox_high"] = "Sandbox",
        ["Interchange"] = "Interchange@rework",
        ["Interchange@rework"] = "Interchange",
        ["Lighthouse"] = "Lighthouse@rework",
        ["Lighthouse@rework"] = "Lighthouse",
    };

    public static string? SiblingOf(string mapId) => _siblings.TryGetValue(mapId, out var sibling) ? sibling : null;

    /// <summary>Overwrites the target map's WORKING copy with a deep copy of the source's (unsaved: it rides
    /// the unsaved-changes button and the undo history like any other edit). Built-in zone names the target
    /// layout does not have are kept in the file and ignored by the game.</summary>
    public void CopyWorking(string fromMapId, string toMapId)
    {
        var source = GetWorking(fromMapId);
        GetWorking(toMapId); // seeds the target's saved-state snapshot so the copy shows as pending
        var clone = JsonSerializer.Deserialize<MapZoneModel>(JsonSerializer.Serialize(source, _json), _json) ?? new MapZoneModel();
        NormalizeNativeFloors(toMapId, clone);
        lock (_working)
        {
            _working[toMapId] = clone;
        }
        ZonesReplaced?.Invoke();
    }

    // ── Edit history support (EditHistoryService) ──────────────────────

    /// <summary>Current and last-saved JSON of every working copy. The saved one is the baseline the history
    /// adopts for a map it sees for the first time: a map can enter the working set already modified (pack
    /// import), and that modification must stay undoable.</summary>
    public Dictionary<string, (string Current, string Saved)> SnapshotWorking()
    {
        lock (_working)
        {
            var result = new Dictionary<string, (string, string)>();
            foreach (var kv in _working)
            {
                var current = JsonSerializer.Serialize(kv.Value, _json);
                result[kv.Key] = (current, _workingSavedJson.TryGetValue(kv.Key, out var saved) ? saved : current);
            }
            return result;
        }
    }

    /// <summary>Puts working copies back to the given JSON (undo / redo). Only the maps that actually differ
    /// are replaced, so the editor keeps its instances, and its selection, everywhere else.</summary>
    public void RestoreWorking(IReadOnlyDictionary<string, string> jsonByMap)
    {
        var replaced = false;
        lock (_working)
        {
            foreach (var kv in jsonByMap)
            {
                if (_working.TryGetValue(kv.Key, out var current) && JsonSerializer.Serialize(current, _json) == kv.Value) continue;
                var restored = JsonSerializer.Deserialize<MapZoneModel>(kv.Value, _json);
                if (restored == null) continue;
                NormalizeNativeFloors(kv.Key, restored);
                _working[kv.Key] = restored;
                replaced = true;
            }
        }
        if (replaced) ZonesReplaced?.Invoke();
    }

    // ── Zone packs (export / import, "ORBIT addons" on the Forge) ──────

    /// <summary>Builds the shareable pack JSON from the CURRENT working copies of the given maps.</summary>
    public string ExportPack(IEnumerable<string> mapIds, string name, string author, string description,
        RushSettings? rush = null)
    {
        var pack = new ZonePackModel
        {
            Name = name?.Trim() ?? "",
            Author = author?.Trim() ?? "",
            Description = description?.Trim() ?? "",
            OrbitVersion = typeof(ZoneStoreService).Assembly.GetName().Version?.ToString(3) ?? "",
            RushPoints = rush == null ? null : new(),
        };
        foreach (var mapId in mapIds)
        {
            if (Array.IndexOf(MapIds, mapId) < 0) continue;
            pack.Maps[mapId] = GetWorking(mapId);
            if (rush != null) pack.RushPoints![mapId] = rush.Points(mapId).Select(point => point.Copy()).ToList();
        }
        return JsonSerializer.Serialize(pack, _json);
    }

    /// <summary>
    /// Imports a pack into the WORKING copies (not saved: the edits ride the unsaved-changes button so
    /// the user reviews them on the map first). Returns applied map ids and skipped entries.
    /// </summary>
    public (List<string> Applied, List<string> Skipped) ImportPack(string json, RushSettings? rush = null)
    {
        var applied = new List<string>();
        var skipped = new List<string>();
        var pack = JsonSerializer.Deserialize<ZonePackModel>(json, _json);
        if (pack?.Maps == null || pack.Maps.Count == 0)
            throw new InvalidDataException("Not a zone pack (no maps inside)");
        if (!string.IsNullOrEmpty(pack.Format) && !pack.Format.StartsWith("orbit-zones/"))
            throw new InvalidDataException($"Unknown pack format '{pack.Format}'");
        pack.ValidateRushPoints();
        if (pack.RushPoints is { Count: > 0 } && rush == null)
            throw new InvalidDataException("This pack contains rush points; import it with the current rush settings.");

        // Prepare every map before changing any working copy, including when a later entry is invalid.
        foreach (var kv in pack.Maps)
        {
            if (Array.IndexOf(MapIds, kv.Key) < 0 || kv.Value == null)
            {
                skipped.Add(kv.Key);
                continue;
            }
            Sanitize(kv.Value);
            NormalizeNativeFloors(kv.Key, kv.Value);
            applied.Add(kv.Key);
        }
        foreach (var mapId in applied)
            GetWorking(mapId); // seed saved baselines before replacing any map
        lock (_working)
        {
            foreach (var mapId in applied) _working[mapId] = pack.Maps[mapId];
            if (rush != null && pack.RushPoints != null)
                foreach (var (mapId, points) in pack.RushPoints) rush.Maps[mapId] = points;
        }
        if (applied.Count > 0) ZonesReplaced?.Invoke();
        return (applied, skipped);
    }

    /// <summary>Clamp imported values into the ranges the client accepts (radius < 1 throws in-game).</summary>
    private static void Sanitize(MapZoneModel zones)
    {
        static void ClampRange(ZoneRange range, float lo, float hi)
        {
            range.Min = Math.Clamp(range.Min, lo, hi);
            range.Max = Math.Clamp(range.Max, range.Min, hi);
        }

        foreach (var bz in zones.BuiltinZones.Values)
        {
            ClampRange(bz.Radius, 10f, 2000f);
            ClampRange(bz.Force, -10f, 10f);
            bz.Decay = Math.Clamp(bz.Decay, 0.05f, 20f);
        }
        foreach (var cz in zones.CustomZones)
        {
            ClampRange(cz.Radius, 10f, 2000f);
            ClampRange(cz.Force, -10f, 10f);
            cz.Decay = Math.Clamp(cz.Decay, 0.05f, 20f);
            cz.Name = string.IsNullOrWhiteSpace(cz.Name) ? null : cz.Name.Trim()[..Math.Min(cz.Name.Trim().Length, 40)];
        }
        if (zones.Convergence != null)
        {
            ClampRange(zones.Convergence.Radius, 0f, 5000f);
            ClampRange(zones.Convergence.Force, 0f, 10f);
        }
    }

    private MapZoneModel ReadEmbeddedDefault(string mapId)
    {
        try
        {
            var asm = Assembly.GetExecutingAssembly();
            using var stream = asm.GetManifestResourceStream($"Orbit.Server.Resources.Zones.{mapId}.json");
            if (stream != null)
            {
                using var reader = new StreamReader(stream);
                var parsed = JsonSerializer.Deserialize<MapZoneModel>(reader.ReadToEnd(), _json);
                if (parsed != null)
                {
                    NormalizeNativeFloors(mapId, parsed);
                    return parsed;
                }
            }
        }
        catch (Exception ex)
        {
            logger.Error($"[ORBIT] Embedded zone default missing for {mapId}: {ex.Message}");
        }
        return new MapZoneModel();
    }
}
